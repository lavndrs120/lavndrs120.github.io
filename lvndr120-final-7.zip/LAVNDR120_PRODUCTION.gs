
function testSession() {
  const email = Session.getActiveUser().getEmail();
  const effective = Session.getEffectiveUser().getEmail();
  Logger.log('Active: ' + email);
  Logger.log('Effective: ' + effective);
  return {active: email, effective: effective};
}
const CONFIG = {
  BUSINESS_COUNT: 120,
  MAX_ORDERS_PER_BUSINESS: 1000,
  ORDER_VALUE: 4.275,
  ORDERS_PER_UNIT: 120,
  INDEX_TICKER: 'LAVNDR120',
  // ✅ جديد: رقم نسخة شروط الاستخدام — ارفعه لو غيّرت النص جوهريًا، وأي مستخدم وافق
  // على نسخة أقدم هيُطلب منه يوافق على الجديدة قبل أي عملية شراء/اشتراك تالية
  TERMS_VERSION: 3,   // 2 = شروط مخصّصة لكل باقة (تُسجَّل الموافقة لكل باقة على حدة)
  // ✅ جديد: نسبة ضمان الشيك اللي البزنس لازم يقدّمها قبل استلام أي استحقاق فعلي —
  // حماية ضد إغراق النظام بطلبات وهمية لتضخيم الوزن. القيمة = GUARANTEE_RATE ×
  // عدد الطلبات المرتبطة بالاستحقاق × ORDER_VALUE.
  GUARANTEE_RATE: 0.36,
  // ✅ جديد: حافز الـAP — نسبة رمزية (مش ربحية) من "النمو" (الـ36%) بتتحسب لما استحقاق
  // بزنس يكتمل (completed) — تعويض تشغيلي بسيط لمين قايم بدور تسهيل إنشاء/استرداد
  // السلة (AP)، مش نصيب من رأس مال الصندوق نفسه. راجع creditApIncentive.
  AP_INCENTIVE_RATE: 0.05,
  MAX_COMPONENT_WEIGHT: 0.20,
  SETTLEMENT_DAYS: 2,
  // ⚠️ هذا المفتاح تدوّر (rotate) — كان القديم مكشوف بالكامل داخل كود الفرونت اند (View Source)
  // فما كان يوفر أي حماية فعلية. المفتاح الجديد ده لازم يتخزن فقط داخل الـ Cloudflare Worker
  // (كـ secret binding)، وما ينكتبش أبداً في أي كود client-side. راجع دليل النشر.
  // هو خط دفاع إضافي بسيط (يفلتر السكانرز العشوائية) — خط الدفاع الحقيقي هو GSI + verifyToken.
  API_KEY: 'd1a93abda8560e0899ba564a8fdc3763424f117a',
  // Client ID من Google Cloud Console (OAuth consent screen → Credentials → Web application)
  // لازم يتحدد قبل النشر، وإلا verifyGoogleIdToken هترفض كل تسجيلات الدخول.
  OAUTH_CLIENT_ID: '776097955989-go2bsq8e7c1umei4vj984jtabve49m32.apps.googleusercontent.com',
  MASTER_SHEET_ID: '1dYVcqBBU1IKxMqGeoVCZEKtk7E0pEuOJQvfPH4OtzPE',
  TIMEZONE: 'Africa/Khartoum',
  MAX_TABLE_ROWS: 120,
  CACHE_TTL: 300000,
  SHEET_TIMEOUT_MS: 2000,
  SNAPSHOT_DAY: 21,
  SHARE_PRICE: 513,
  OTP_MAX_ATTEMPTS: 5, // بعد كذا محاولة رمز خاطئ، الطلب يتقفل ويحتاج طلب شراء جديد
  // ✅ جديد: طبقة "المشاهدين/العامة" — اشتراك مطالعة بيانات السوق (بدون حصة ولا سوق داخلي)
  LAVA_PRICE_USD: 1.4,      // اشتراك يومي (24 ساعة)
  ANNUAL_PRICE_USD: 249,    // اشتراك سنوي (365 يوم)
  // ✅ جديد: سقف طاقة استيعابية مقصود لكل باقة (مش قيد تقني — قرار عمل). لما باقة
  // توصل السقف، طلبات الاشتراك الجديدة (بس مش تجديد/استكمال طلب قائم) تترفض برسالة
  // واضحة بدل ما تتقبل بلا حدود. راجع countActiveSubscribers/getSubscriberCapacity.
  MAX_LAVA_SUBSCRIBERS: 120000,
  MAX_ANNUAL_SUBSCRIBERS: 675,

  // ✅ جديد: باقة "ڤندكس" (Lavenders Oracle) — عضوية سنوية حصرية (12 شهر بس، ما
  // فيهاش نسخة يومية). كل مشترك ڤندكس نشط بيقلّل السقف *المتاح* لباقتي لافا (يومي
  // وسنوي) — مش بيلغي مشتركين لافا موجودين فعلاً، بس بيقلل عدد الأماكن الجديدة
  // المتاحة للانضمام. راجع getEffectiveTierMax.
  FENDEX_PRICE_USD: 1287,
  MAX_FENDEX_SUBSCRIBERS: 120,
  FENDEX_LAVA_DAILY_RESERVE: 1000,   // كل مشترك ڤندكس نشط يقلل سقف لافا اليومي بـ1000
  FENDEX_LAVA_ANNUAL_RESERVE: 6,     // وسقف لافا السنوي بـ6

  // ✅ جديد: باقة "ماقما" — عضوية سنوية (12 شهر) بتديك دليل الـ120 نشاط مرتبين
  // حسب وزنهم الاستهلاكي الحقيقي بالمؤشر، كل واحد فيهم بلينك يوديك لصفحته (اللينك
  // بيدخله الأدمن يدويًا لكل بزنس — راجع BusinessSheets عمود ExternalLink).
  MAGMA_PRICE_USD: 100,
  MAX_MAGMA_SUBSCRIBERS: 500,

  // ✅ جديد: جدول موحّد لكل باقات الاشتراك — بديل عن انتشار `tier === 'lava' ? أ : ب`
  // في كذا مكان مختلف بالكود (كان بيصعّب إضافة باقة تالتة/رابعة بأمان). أي باقة
  // جديدة مستقبلاً تتضاف هنا بس، من غير ما تحتاج تلمس subscribeLava/decideAdminSubscription.
  // ✅ جديد: باقات "الحركة الاقتصادية" (Join the Economic Movement) + OMS
  OMS_SERVICES_PRICE_USD: 429,
  OMS_PRODUCTS_PRICE_USD: 492,
  OMS_VIP_APP_VALUE_USD: 429,        // جزء قيمة التطبيق من سعر VIP
  OMS_VIP_SEAT_VALUE_USD: 513,       // جزء مقعد الدخول لسوق التداول الداخلي
  OMS_VIP_PRICE_USD: 942,            // 429 + 513
  MAX_OMS_MEMBERS: 120,              // الباقات الثلاث (خدمات/منتجات/VIP) مجتمعة لا تتجاوز 120
  RESELLER_APP_VALUE_USD: 169.35,
  RESELLER_APPS_COUNT: 8,
  RESELLER_PRICE_USD: 1354.8,        // 8 × 169.35
  MAX_RESELLER_MEMBERS: 38,
  FRANCHISE_TOTAL_USD: 2709,         // 120 × 22.58
  FRANCHISE_TOTAL_SEATS: 120,
  FRANCHISE_PER_SEAT_USD: 22.58,
  FRANCHISE_RESERVATION_USD: 90,     // دفعة الحجز الأولى
  FRANCHISE_SEATS_PER_INSTALLMENT: 4,// الحجز يخصم 4 مقاعد من الـ120
  MAX_FRANCHISE_MEMBERS: 19,
  TYCOON_PRICE_USD: 51480,           // تايكون واحد لكل دولة
  REFUND_WINDOW_DAYS: 21,            // سياسة الاسترداد النقدي: 3 أسابيع
  WHATSAPP_NUMBER: '249914985264',   // واتساب التسليم (ما قبل الاشتراك) + مساعدة ثانوية

  // category: 'lavenders' = Join Up LAVENDERS (لافا، ڤندكس، ماقما) | 'movement' = مسار البناء والحركة الاقتصادية (OMS، ريسيلر، فرانشايز، تايكون)
  // capacityGroup: باقات تشترك في سقف واحد | perCountry: عضو واحد لكل دولة
  // progressive: دفع على مراحل | grantsParticipantSeat: يمنح مقعد مشارك فعلي
  TIER_CONFIG: {
    lava:   { nameAr: 'لافا (يومي)',     priceProp: 'LAVA_PRICE_USD',   maxProp: 'MAX_LAVA_SUBSCRIBERS',   durationMs: 24*3600000,      category: 'lavenders' },
    annual: { nameAr: 'الباقة السنوية',   priceProp: 'ANNUAL_PRICE_USD', maxProp: 'MAX_ANNUAL_SUBSCRIBERS', durationMs: 365*24*3600000, category: 'lavenders' },
    fendex: { nameAr: 'ڤندكس',           priceProp: 'FENDEX_PRICE_USD', maxProp: 'MAX_FENDEX_SUBSCRIBERS', durationMs: 365*24*3600000, category: 'lavenders' },
    magma:  { nameAr: 'ماقما',           priceProp: 'MAGMA_PRICE_USD',  maxProp: 'MAX_MAGMA_SUBSCRIBERS',  durationMs: 365*24*3600000, category: 'lavenders' },
    oms_services: { nameAr: 'OMS خدمات',  priceProp: 'OMS_SERVICES_PRICE_USD', maxProp: 'MAX_OMS_MEMBERS', durationMs: 365*24*3600000, category: 'movement', capacityGroup: 'oms' },
    oms_products: { nameAr: 'OMS منتجات', priceProp: 'OMS_PRODUCTS_PRICE_USD', maxProp: 'MAX_OMS_MEMBERS', durationMs: 365*24*3600000, category: 'movement', capacityGroup: 'oms' },
    oms_vip:      { nameAr: 'OMS VIP',    priceProp: 'OMS_VIP_PRICE_USD',      maxProp: 'MAX_OMS_MEMBERS', durationMs: 365*24*3600000, category: 'movement', capacityGroup: 'oms', grantsParticipantSeat: true },
    reseller: { nameAr: 'ريسيلر',   priceProp: 'RESELLER_PRICE_USD',  maxProp: 'MAX_RESELLER_MEMBERS',  durationMs: 365*24*3600000, category: 'movement' },
    franchise:{ nameAr: 'فرانشايز', priceProp: 'FRANCHISE_TOTAL_USD', maxProp: 'MAX_FRANCHISE_MEMBERS', durationMs: 5*365*24*3600000, category: 'movement', progressive: true },
    // داخلي فقط (لا يظهر للمستخدم): دفعة تقسيط لفرانشايز مفعّل — يستخدم نفس مسار الدفع/الرمز/المراجعة
    franchise_installment: { nameAr: 'دفعة فرانشايز', priceProp: 'FRANCHISE_RESERVATION_USD', maxProp: null, durationMs: 0, category: 'movement', internal: true },
    tycoon:   { nameAr: 'تايكون',   priceProp: 'TYCOON_PRICE_USD',    maxProp: null,                    durationMs: 365*24*3600000, category: 'movement', perCountry: true }
  },

  // ── إعدادات التحقق من الدفع (جديد) ──
  ADMIN_EMAIL: 'imspractice9@gmail.com',  // وين توصل إشعارات "دفعة بانتظار المراجعة"
  // ✅ جديد: الإيميلات المسموح لها تفتح لوحة تحكم الأدمن (admin.html) فقط. منفصل عمداً
  // عن ADMIN_EMAIL اللي فوق (ده بس بريد إشعارات، مش صلاحية دخول).
  ADMIN_PANEL_EMAILS: ['imspractice9@gmail.com'],
  OTP_EXPIRY_HOURS: 48,                    // مهلة إدخال الرمز بعد التحويل البنكي
  // ✅ جديد: عنوان "من" لإيميلات الإرسال الخارجي (Resend) — لازم يكون من دومين موثّق
  // بحسابك على Resend. لو ما فعّلتش Resend، القيمة دي مالها استخدام (MailApp بيستخدم
  // إيميل حسابك تلقائياً). راجع دليل النشر لتفعيل Resend لما تقرب من حد الـ100 إيميل/يوم.
  EMAIL_FROM: 'LAVNDR120 <noreply@REPLACE_WITH_YOUR_DOMAIN.com>',
  BANK_DETAILS: {
    BANK_NAME: 'بنك الخرطوم',
    SWIFT: 'BAKHSDKH',
    ACCOUNT_NUMBER: '2467362',
    IBAN: 'SD6804024673620001',
    BBAN: '04024673620001',
    ACCOUNT_HOLDER: 'عمر سيداحمد محمدالحسن محمد',
    BRANCH: 'صابرين',
    CURRENCY: 'الجنيه السوداني SDG'
  }
};

// ملاحظة: هذه القوائم fallback فقط تُستخدم إذا كانت شيتات
// 'BusinessSheets' و 'AllowedEmails' في الـ Master Sheet فارغة أو غير موجودة.
// الطريقة الموصى بها لإدخال الـ120 شيت والـ120 إيميل هي عبر الشيتات نفسها
// (راجع initializeSystem) وليس عبر تعديل الكود.
const BUSINESS_SHEETS = ['ID-1', 'ID-2'];
const ALLOWED_EMAILS = ['imspractice69@gmail.com'];
const AUTHORIZED_PARTICIPANTS = {'AP001': 'OMS Solution'};
// ✅ جديد: كل AP code لازم يكون مربوط بإيميل واحد محدد يقدر ينفذ باسمه.
// بدون هذا، أي مشارك عادي عنده token صالح كان يقدر يستدعي processAPOrder بأي apCode.
const AP_AUTHORIZED_EMAILS = {'AP001': 'imspractice69@gmail.com'};

// ✅ أمان للتوسّع: حد Apps Script لقيمة Property الواحدة ≈ 9KB. عدّادات مثل LAST_COUNTS
// (لكل منتج) وBUSINESS_ORDER_COUNTS (لكل بزنس) وAP_ACTIVITY قد تكبر بنمو الـ120 بزنس وحركة
// الطلبات، وتجاوز الحد كان سيرمي خطأ ويضيّع نتيجة التحليل. هذا الغلاف يقسّم القيمة الكبيرة
// تلقائيًا على مفاتيح متتالية ويجمّعها عند القراءة — بنفس واجهة getProperty/setProperty،
// فلا يتغيّر أي استدعاء آخر في الكود. القيم الصغيرة تُخزَّن كما هي (متوافق مع البيانات الحالية).
const props = (function() {
  const raw = PropertiesService.getScriptProperties();
  const CHUNK = 8000, MARK = '__CHUNKED__:';
  function clearChunks(key) {
    const head = raw.getProperty(key);
    if (head && String(head).indexOf(MARK) === 0) {
      const n = parseInt(String(head).slice(MARK.length), 10) || 0;
      for (let i = 0; i < n; i++) raw.deleteProperty(key + '__' + i);
    }
  }
  return {
    getProperty: function(key) {
      const v = raw.getProperty(key);
      if (v && String(v).indexOf(MARK) === 0) {
        const n = parseInt(String(v).slice(MARK.length), 10) || 0;
        let out = '';
        for (let i = 0; i < n; i++) out += (raw.getProperty(key + '__' + i) || '');
        return out;
      }
      return v;
    },
    setProperty: function(key, value) {
      const str = String(value);
      clearChunks(key);
      if (str.length <= CHUNK) { raw.setProperty(key, str); return; }
      const n = Math.ceil(str.length / CHUNK);
      for (let i = 0; i < n; i++) raw.setProperty(key + '__' + i, str.slice(i * CHUNK, (i + 1) * CHUNK));
      raw.setProperty(key, MARK + n);
    },
    deleteProperty: function(key) { clearChunks(key); raw.deleteProperty(key); }
  };
})();
const cache = CacheService.getScriptCache();

// ✅ جديد: حافز الـAP التراكمي — قيمة رمزية بتتجمّع في Properties (مش شيت، رقم واحد
// بسيط بيتراكم)، من نسبة AP_INCENTIVE_RATE على "النمو" (الـ36%) بس، مش على المساهمة
// الأصلية ولا رأس مال الصندوق. تحفيزية لتشغيل النظام (إنشاء/استرداد السلة)، مش نصيب
// ربحي من الصندوق — بالضبط زي ما هو موصوف: "قيمة رمزية تراكمية".
// ⚠️ حاليًا فيه AP واحد بس مسجّل (AP001) — فالحافز كله بيروح له تلقائيًا. لو انضاف
// أكتر من AP لاحقًا، هنا المكان اللي يحتاج تعديل (توزيع الحافز على الـAP الفعلي
// المرتبط بأوردرات البزنس ده تحديدًا، مش دايمًا الأول).
function creditApIncentive(apCode, amount) {
  if (!amount || amount <= 0) return;
  const earnings = JSON.parse(props.getProperty('AP_EARNINGS') || '{}');
  earnings[apCode] = parseFloat(((earnings[apCode]||0) + amount).toFixed(2));
  props.setProperty('AP_EARNINGS', JSON.stringify(earnings));
}

function getApEarnings() {
  const earnings = JSON.parse(props.getProperty('AP_EARNINGS') || '{}');
  return Object.keys(AUTHORIZED_PARTICIPANTS).map(code => ({
    code: code, name: AUTHORIZED_PARTICIPANTS[code], earnings: earnings[code] || 0
  }));
}

// ─────────────────────────────────────────────
// مصادر الإعداد: 120 شيت + 120 إيميل (تُقرأ من الشيتات نفسها، لا حاجة لتعديل الكود)
// ─────────────────────────────────────────────
function getBusinessSheetIds() {
  const cached = cache.get('lavndr_business_sheets');
  if (cached) return JSON.parse(cached);
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
    if (sheet && sheet.getLastRow() > 1) {
      // ✅ جديد: عمود F = Closed — بزنس مقفول بيتستبعد من هنا خالص، يعني بيختفي من
      // كل حساب وزن/NAV تلقائيًا (منطقياً: باقي الـ119 بيمتصوا نسبته تدريجيًا)، وكمان
      // النظام يبطّل يفتح شيته أصلاً كل مرة getData() تشتغل (توفير وقت تنفيذ حقيقي).
      const rows = sheet.getRange(2, 1, sheet.getLastRow() - 1, 6).getValues();
      const ids = rows
        .filter(r => String(r[5]||'').trim().toLowerCase() !== 'true')
        .map(r => String(r[0]).trim()).filter(Boolean);
      if (ids.length > 0) {
        cache.put('lavndr_business_sheets', JSON.stringify(ids), 600);
        return ids;
      }
    }
  } catch (e) { Logger.log('getBusinessSheetIds error: ' + e); }
  return BUSINESS_SHEETS; // fallback للقائمة الثابتة في الكود
}

// ─────────────────────────────────────────────
// ✅ جديد: حماية المشتركين — منع الاشتراك المدفوع قبل اكتمال السوق فعليًا
// ─────────────────────────────────────────────
// السوق (المؤشر) نفسه معناه الحقيقي مبني على وجود الـ120 نشاط فعليًا — قبل كده
// أي اشتراك مدفوع (لافا/سنوي/ڤندكس/ماقما) بيبيع وعد لمنتج مش موجود فعليًا بعد:
// بيانات مؤشر لسوق ناقص، تقرير أوراكل عن سوق غير مكتمل، دليل بزنسات ناقص. حماية
// مباشرة لحق المشترك: ما يدفعش ولا يدخل بياناته البنكية قبل ما يكون المنتج جاهز.
function getReadyBusinessCount() {
  return getBusinessSheetIds().length;
}
function isMarketComplete() {
  return getReadyBusinessCount() >= CONFIG.BUSINESS_COUNT;
}

// ✅ يتنادى تلقائيًا من linkBusinessToEmail بعد أي إضافة بزنس جديد — بيفحص لو
// السوق بقى مكتمل فعليًا (120 بزنس)، ولو كده يحوّل تلقائيًا كل طلبات قائمة
// الانتظار لمرحلة الدفع الحقيقية (OTP + تفاصيل بنكية) بإيميل حقيقي لكل واحد
// فيهم. آمنة تتنادى في أي وقت — لو السوق لسه ناقص أو مفيش حد في القائمة، ما
// بتعملش حاجة خالص.
function processSubscriptionWaitlistIfMarketReady() {
  if (!isMarketComplete()) return { processed: 0, reason: 'market_not_ready' };
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return { processed: 0 };
  const data = sheet.getDataRange().getValues();
  let processed = 0;
  const failedEmails = [];
  for (let i = 1; i < data.length; i++) {
    if (data[i][4] !== 'waitlisted') continue;
    const email = data[i][0], tier = data[i][1];
    const amount = tierInitialAmount(tier);
    const otp = generateOTP();
    const mail = buildSubscriptionOTPEmail(email, otp, tier, amount);
    const introLine = '🎉 اكتمل سوق ' + CONFIG.INDEX_TICKER + ' بالكامل بـ' + CONFIG.BUSINESS_COUNT + ' نشاط! جهّزنالك التفاصيل تكمّل بيها اشتراكك:\n\n';
    const sendResult = sendTransactionalEmail(mail.to, mail.subject, introLine + mail.body);
    if (sendResult.success) {
      sheet.getRange(i+1, 3).setValue(otp);            // OTP
      sheet.getRange(i+1, 4).setValue(amount);          // AmountUSD
      sheet.getRange(i+1, 5).setValue('awaiting_otp');  // Status
      sheet.getRange(i+1, 6).setValue(new Date());      // RequestedAt (نجدّدها عشان مهلة الـ48 ساعة تبدأ من هنا)
      processed++;
      logAudit('system_auto', 'waitlist_converted_to_otp', {email: email, tier: tier});
      pushToEmail(email, 'اكتمل السوق 🎉', 'أكمل اشتراكك في ' + tierNameAr(tier) + ' الآن — أرسلنا لك التفاصيل على بريدك.', 'market_update');
    } else {
      failedEmails.push(email);
    }
  }
  if (processed > 0 || failedEmails.length > 0) {
    try {
      sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - اكتمل السوق! تفعيل قائمة الانتظار',
        'وصل عدد البزنسات المسجّلة لـ' + CONFIG.BUSINESS_COUNT + ' فعليًا.\n\n' +
        'تم تلقائيًا إرسال دعوات إكمال الدفع لـ' + processed + ' مشترك كانوا في قائمة الانتظار.' +
        (failedEmails.length > 0 ? '\n\nفشل الإرسال لـ' + failedEmails.length + ' مشترك (وصلنا لحد MailApp اليومي على الأغلب):\n' + failedEmails.join('\n') : ''));
    } catch(e) {}
  }
  return { processed: processed, failed: failedEmails.length };
}

// ✅ جديد: أسماء البزنسات (عمود B بتاب BusinessSheets) — مفتاحها SheetID عشان ما تتعارض أسماء متشابهة
function getBusinessNames() {
  const cached = cache.get('lavndr_business_names');
  if (cached) return JSON.parse(cached);
  const map = {};
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
    if (sheet && sheet.getLastRow() > 1) {
      sheet.getRange(2, 1, sheet.getLastRow() - 1, 2).getValues().forEach(r => {
        const id = String(r[0]).trim();
        if (id) map[id] = String(r[1]||'').trim();
      });
      cache.put('lavndr_business_names', JSON.stringify(map), 600);
    }
  } catch (e) { Logger.log('getBusinessNames error: ' + e); }
  return map;
}

// ✅ جديد: يرجّع إيميل صاحب بزنس معيّن (SheetID) — الربط اللي كان مفقود بين
// البزنسات (SheetID) والمستثمرين (Email)، بما إن كل بزنس هو نفسه صاحبه كمستثمر.
function getBusinessOwnerEmail(sheetId) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  if (!sheet || sheet.getLastRow() < 2) return '';
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 3).getValues();
  for (let i = 0; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(sheetId).trim()) {
      return String(data[i][2] || '').trim();
    }
  }
  return '';
}

// ✅ جديد: عكس الدالة اللي فوق — كل البزنسات (SheetID) المرتبطة بإيميل معيّن.
// array مش قيمة واحدة، احتياطاً لو شخص عنده أكتر من بزنس نظرياً مستقبلاً.
function getBusinessesByEmail(email) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  if (!sheet || sheet.getLastRow() < 2) return [];
  const lower = String(email).trim().toLowerCase();
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 3).getValues();
  const result = [];
  for (let i = 0; i < data.length; i++) {
    if (String(data[i][2] || '').trim().toLowerCase() === lower) {
      result.push({ sheetId: String(data[i][0]).trim(), name: String(data[i][1] || '').trim() });
    }
  }
  return result;
}

// ✅ جديد: الأدمن يربط بزنس بإيميل صاحبه — يتنادى لما بزنس يسجّل دخول لأول مرة
// والأدمن يضيف بياناته يدوياً (اسمه وإيميله) زي ما طلب.
function linkBusinessToEmail(sheetId, email, businessName, adminEmail) {
  if (!sheetId || !email) return { error: 'sheetId و email مطلوبين' };
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(sheetId).trim()) {
      sheet.getRange(i+1, 3).setValue(email.trim());
      if (businessName) sheet.getRange(i+1, 2).setValue(businessName.trim());
      cache.remove('lavndr_business_names'); // ✅ لازم نمسح الكاش القديم بعد أي تعديل
      logAudit(adminEmail || 'unknown_admin', 'business_linked_to_email', {sheetId: sheetId, email: email});
      addToAllowedEmails(email.trim(), 'linked business');
      pushToEmail(email.trim(), 'تم ربط حسابك ببزنسك ✅', 'مؤشرك جاهز لاستقبال بيانات طلبات بزنسك. افتح بوابة البزنس لمتابعة طلباتك.', 'business_linked');
      return { status: 'linked' };
    }
  }
  // البزنس مش مسجّل أصلاً بالشيت — نضيفه صف جديد. AutoAccept افتراضياً 'false' (يدوي)
  sheet.appendRow([sheetId, businessName || '', email.trim(), 'false', '']);
  // ✅ إصلاح: cache.remove('lavndr_business_sheets') كان ناقص هنا — الكاش ده بيتحدد
  // بـ10 دقايق (راجع getBusinessSheetIds)، يعني لو الأدمن ضاف بزنس جديد (حتى الـ120
  // بالظبط اللي بيكمّل السوق)، getBusinessSheetIds كانت هترجع العدد القديم لحد 10
  // دقايق كاملة قبل ما تعكس الإضافة — أي فحص لحظي لاكتمال السوق (زي
  // processSubscriptionWaitlistIfMarketReady تحت) كان ممكن يتأخر بلا داعي.
  cache.remove('lavndr_business_sheets');
  cache.remove('lavndr_business_names');
  logAudit(adminEmail || 'unknown_admin', 'business_added_and_linked', {sheetId: sheetId, email: email, name: businessName || ''});
  addToAllowedEmails(email.trim(), 'linked business');
  pushToEmail(email.trim(), 'تم ربط حسابك ببزنسك ✅', 'مؤشرك جاهز لاستقبال بيانات طلبات بزنسك. افتح بوابة البزنس لمتابعة طلباتك.', 'business_linked');
  // ✅ جديد: بمجرد ما بزنس جديد يتضاف، نفحص فورًا هل السوق بقى مكتمل (120 نشاط)
  // — لو كده نحوّل تلقائيًا كل طلبات قائمة الانتظار لمرحلة الدفع الحقيقية.
  processSubscriptionWaitlistIfMarketReady();
  return { status: 'added_and_linked' };
}

// ✅ جديد: تحديث فئة/تصنيف البزنس ورابطه الخارجي — أساس "دليل الـ120 نشاط" اللي
// بيشوفه مشترك باقة ماقما (راجع getMagmaDirectory). الرابط ده بيدخله الأدمن يدويًا
// (مفيش أي طريقة تلقائية نجيبه بيها — كل بزنس له نظامه/صفحته الخاصة برّه LAVNDR120).
function setBusinessCategoryAndLink(sheetId, category, link, adminEmail) {
  if (!sheetId) return { error: 'sheetId مطلوب' };
  if (link && !/^https?:\/\//i.test(String(link).trim())) {
    return { error: 'الرابط لازم يبدأ بـ http:// أو https://' };
  }
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(sheetId).trim()) {
      sheet.getRange(i+1, 7).setValue(String(category || '').trim());
      sheet.getRange(i+1, 8).setValue(String(link || '').trim());
      cache.remove('lavndr_business_category_links');
      logAudit(adminEmail || 'unknown_admin', 'business_category_link_updated', {sheetId: sheetId, category: category, link: link});
      return { status: 'updated' };
    }
  }
  return { error: 'البزنس ده مش مسجّل — لازم يترابط بإيميل الأول من قسم ربط البزنسات' };
}

// ✅ جديد: هل البزنس ده مفعّل عنده "قبول تلقائي" للاستحقاقات؟ إعداد شخصي قابل
// للتغيير في أي وقت (كما اتفقنا) — تلقائي = يوافق على أي استحقاق جديد من غير
// انتظار ضغطة، يدوي = لازم يوافق بنفسه (أو الأدمن نيابة عنه بعد تواصل فعلي).
function isAutoAcceptEnabled(sheetId) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  if (!sheet || sheet.getLastRow() < 2) return false;
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 4).getValues();
  for (let i = 0; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(sheetId).trim()) {
      return String(data[i][3]).trim().toLowerCase() === 'true';
    }
  }
  return false;
}

// ✅ جديد: تغيير إعداد القبول التلقائي — متاحة في أي وقت زي ما اتفقنا. بتتنادى
// من لوحة الأدمن حالياً (البزنس نفسه مالوش نظام دخول منفصل لسه).
function setAutoAcceptPreference(sheetId, enabled, adminEmail) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(sheetId).trim()) {
      sheet.getRange(i+1, 4).setValue(enabled ? 'true' : 'false');
      logAudit(adminEmail || 'unknown_admin', 'auto_accept_preference_changed', {sheetId: sheetId, enabled: !!enabled});
      return { status: 'updated', autoAccept: !!enabled };
    }
  }
  return { error: 'البزنس ده مش مسجّل — لازم يترابط بإيميل الأول' };
}

// ✅ إغلاق بزنس منطقيًا — لما بزنس حقيقي يقفل فعليًا. النتيجة: بيختفي فورًا من
// كل حساب وزن/NAV (getBusinessSheetIds بيستبعده)، الباقي 119 بيمتصوا نسبته تلقائيًا
// بمرور الوقت. أي استحقاق "available"/"accepted_awaiting_guarantee" قديم ليه بيفضل
// قابل للتسوية عادي من admin.html (الإغلاق ما بيمسحش سجل Distributions، بس بيوقف
// أي طلبات/وزن جديد ليه من دلوقتي).
function closeBusinessAccount(sheetId, adminEmail) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  if (!sheet) return { error: 'شيت BusinessSheets غير موجود' };
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(sheetId).trim()) {
      sheet.getRange(i + 2, 6).setValue('TRUE');
      cache.remove('lavndr_business_sheets'); // ✅ لازم نمسح الكاش عشان يختفي فورًا مش بعد 10 دقايق
      logAudit(adminEmail || 'unknown_admin', 'business_closed', { sheetId: sheetId });
      return { status: 'closed' };
    }
  }
  return { error: 'البزنس ده مش مسجّل' };
}

// ✅ جديد: عكس الإغلاق لو حصل بالغلط — البزنس يرجع يُحتسب في الوزن/NAV من تاني
function reopenBusinessAccount(sheetId, adminEmail) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  if (!sheet) return { error: 'شيت BusinessSheets غير موجود' };
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < data.length; i++) {
    if (String(data[i][0]).trim() === String(sheetId).trim()) {
      sheet.getRange(i + 2, 6).setValue('FALSE');
      cache.remove('lavndr_business_sheets');
      logAudit(adminEmail || 'unknown_admin', 'business_reopened', { sheetId: sheetId });
      return { status: 'reopened' };
    }
  }
  return { error: 'البزنس ده مش مسجّل' };
}

// ✅ جديد: مصدر واحد موحّد لنشاط كل بزنس — [{sheetId, name, count}] مرتبة تنازلياً
// كل الأماكن اللي كانت تحسب على أساس اسم المنتج (ممكن يتكرر بين بزنسين ويخلط بياناتهم)
// بقت تستخدم هذي بدلاً منها.
function getBusinessCountsArray() {
  const counts = JSON.parse(props.getProperty('BUSINESS_ORDER_COUNTS')||'{}');
  const names = getBusinessNames();
  return getBusinessSheetIds()
    .map(id => ({ sheetId: id, name: names[id] || ('بزنس-' + id.substring(0,6)), count: counts[id]||0 }))
    .sort((a,b) => b.count - a.count);
}

function getAllowedEmailsFromSheet() {
  const cached = cache.get('lavndr_allowed_emails');
  if (cached) return JSON.parse(cached);
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('AllowedEmails');
    if (sheet && sheet.getLastRow() > 1) {
      const emails = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues()
        .flat().map(v => String(v).trim().toLowerCase()).filter(Boolean);
      cache.put('lavndr_allowed_emails', JSON.stringify(emails), 600);
      return emails;
    }
  } catch (e) { Logger.log('getAllowedEmailsFromSheet error: ' + e); }
  return [];
}

// ─────────────────────────────────────────────
// التهيئة
// ─────────────────────────────────────────────
function initializeSystem() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  if (!master.getSheetByName('History')) {
    master.insertSheet('History').appendRow(['Timestamp','NAV','IIV','Premium%','NetOrders','NetUnits','GrossOrders','Redemptions']);
  }
  if (!master.getSheetByName('AP_Orders')) {
    master.insertSheet('AP_Orders').appendRow(['Timestamp','AP_Code','Type','Units','CashInLieu','SettlementDate','Status']);
  }
  if (!master.getSheetByName('Monthly_Snapshots')) {
    master.insertSheet('Monthly_Snapshots').appendRow(['Month','Date','NAV','IIV','Premium%','NetOrders','NetUnits','Components','Top5']);
  }
  // ✅ جديد: شيت المشاركين
  if (!master.getSheetByName('Participants')) {
    master.insertSheet('Participants').appendRow(['Email','Status','EntryNAV','EntryDate','SharePrice','CurrentValue','PnL','Allocation']);
  }
  // ✅ جديد: شيت السوق الداخلي
  if (!master.getSheetByName('Market')) {
    master.insertSheet('Market').appendRow(['SellerEmail','ShareValue','ListDate','Status','BuyerEmail','CloseDate']);
  }
  // ✅ جديد: شيت الـ120 بزنس (بدل تعديل الكود، تضيف Sheet ID + اسم في كل صف)
  // ✅ جديد: عمود Location اختياري — موقع/مدينة البزنس، أساس شارت "توزيع الطلبات
  // حسب الموقع" بالداشبورد. فاضي افتراضيًا لحد ما الأدمن يعبّيه من admin.html.
  // ✅ جديد: عمودي Category وExternalLink (باقة ماقما) — تصنيف البزنس ورابط خارجي
  // يدخله الأدمن يدويًا لكل بزنس، أساس "دليل الـ120 نشاط" اللي بيشوفه مشترك ماقما.
  if (!master.getSheetByName('BusinessSheets')) {
    master.insertSheet('BusinessSheets').appendRow(['SheetID','BusinessName','Email','AutoAccept','Reserved','Closed','Category','ExternalLink']);
  }
  // ✅ جديد: شيت الإيميلات المصرح لها بالدخول (بدل تعديل الكود، تضيف إيميل في كل صف)
  if (!master.getSheetByName('AllowedEmails')) {
    master.insertSheet('AllowedEmails').appendRow(['Email','Note']);
  }
  // ✅ جديد: شيت طلبات الدفع بانتظار OTP/مراجعة الأدمن
  // ✅ إصلاح: كان الرأس هنا معرّف بـ9 أعمدة بس، لكن buyShare/submitPaymentVerification
  // بيكتبوا ويقروا عمود عاشر (FailedAttempts) فعلياً عبر getRange(i+1, 10) — العمود
  // كان يظهر بدون عنوان لو فتحت الشيت مباشرة بجوجل شيتس. ضفنا العنوان الناقص.
  if (!master.getSheetByName('PendingPayments')) {
    master.insertSheet('PendingPayments').appendRow(['Email','OTP','Amount','SellerEmail','MarketRow','Status','RequestedAt','TxnRef','SubmittedAt','FailedAttempts']);
  }
  // ✅ جديد: شيت اشتراكات "المشاهدين" (لافا اليومي / السنوي) — منفصل تماماً عن Participants
  // (اشتراك مطالعة بيانات، مش حصة حقيقية بالصندوق)
  if (!master.getSheetByName('Subscribers')) {
    master.insertSheet('Subscribers').appendRow(
      ['Email','Tier','OTP','AmountUSD','Status','RequestedAt','TxnRef','SubmittedAt','StartDate','EndDate','FailedAttempts','Country']
    );
  }
  ensureFranchiseSheet(master);
  // ✅ جديد: سجل موافقات المستخدمين على شروط الاستخدام وإخلاء المسؤولية — دليل موثّق
  // إن كل مستخدم وافق فعلاً قبل أول عملية شراء/اشتراك، وعلى أي نسخة من النص بالظبط
  if (!master.getSheetByName('Consents')) {
    master.insertSheet('Consents').appendRow(['Email','TermsVersion','AcceptedAt','Tier']);
  }
  // ✅ جديد: باقة ماقما — تسجيل "مرة واحدة تكفي" لاطلاع مشترك على بزنس معيّن من
  // دليل الـ120 نشاط (upsert: أول ضغطة بس بتتسجل، أي ضغطة تانية على نفس البزنس
  // ما بتضيفش صف جديد). أساس عداد "زرت X من 120" لكل مشترك ماقما.
  if (!master.getSheetByName('MagmaViews')) {
    master.insertSheet('MagmaViews').appendRow(['Email','SheetID','FirstViewedAt']);
  }
  // ✅ جديد: سجل تدقيق مركزي — كل عملية حساسة (شراء، بيع، اعتماد/رفض أدمن) بتتسجل هنا
  // بصيغة موحّدة، عشان لو حصل نزاع يكون فيه دليل واضح "مين عمل إيه وإمتى" بدل ما
  // البيانات تكون متفرقة في شيتات مختلفة يصعب الرجوع لها بسرعة.
  if (!master.getSheetByName('AuditLog')) {
    master.insertSheet('AuditLog').appendRow(['Timestamp','Actor','Action','Details']);
  }
  // ✅ جديد: سجل استحقاق كل بزنس من كل دفعة مباشرة من الصندوق
  if (!master.getSheetByName('Distributions')) {
    master.insertSheet('Distributions').appendRow(['Date','ParticipantEmail','BusinessSheetID','BusinessName','Weight%','Entitlement','Status','SentAt','Orders','GuaranteeStatus']);
  }
  // ✅ جديد: ملخص تراكمي — كم كل بزنس مستحق (لسا ما اتحول) وكم اتحول له فعلياً، بدل ما تعد صف صف
  if (!master.getSheetByName('DistributionsSummary')) {
    master.insertSheet('DistributionsSummary').appendRow(['BusinessSheetID','BusinessName','TotalAvailable','TotalAwaitingGuarantee','TotalCompleted']);
  }
  // ✅ جديد: لقطة يومية لحركة الطلبات (الزيادة اليومية بس، مش تراكمي) — أساس شارت
  // "اتجاه الطلبات عبر الوقت" بالداشبورد. صف واحد لكل يوم (مش سطر لكل طلب) عشان
  // الحجم يفضل محدود للأبد بغض النظر عن عدد الطلبات — نفس فلسفة شيت History بالظبط.
  if (!master.getSheetByName('DailyOrderStats')) {
    master.insertSheet('DailyOrderStats').appendRow(['Date','Orders','TopProductsJSON']);
  }
  // ✅ جديد: لقطة يومية لقيم PropertiesService الحساسة — دي مش موجودة في أي شيت،
  // فمكانتش مغطّاة بنسخة backupMasterSheet الاحتياطية خالص. الأهم فيها AP_EARNINGS
  // (مش قابلة لإعادة البناء من إعادة قراءة الطلبات — لو اتمسحت، القيمة ضاعت للأبد
  // بدون هذه اللقطة). باقي القيم (BUSINESS_ORDER_COUNTS إلخ) قابلة لإعادة البناء
  // نظريًا بإعادة قراءة كل الطلبات، لكن اللقطة بتوفر استرجاع فوري بدل انتظار إعادة
  // مسح الـ120 شيت. عايشة جوه الشيت الرئيسي نفسه، يعني بتتنسخ تلقائيًا مع كل
  // backupMasterSheet من غير أي بنية تحتية إضافية.
  if (!master.getSheetByName('PropertiesSnapshot')) {
    master.insertSheet('PropertiesSnapshot').appendRow(
      ['Timestamp','AP_EARNINGS','GROSS_ORDERS','REDEMPTION_ORDERS','BUSINESS_ORDER_COUNTS','LOCATION_COUNTS','LAST_COUNTS','AP_ACTIVITY']
    );
  }
  getBusinessSheetIds().forEach(id => {
    try {
      const ss = SpreadsheetApp.openById(id);
      if (!ss.getSheetByName('Orders')) {
        ss.insertSheet('Orders').appendRow(['Timestamp','Product','Qty','Price','Total','Customer','Type','AP_Code','Location']);
      }
    } catch(e) {}
  });
  props.setProperty('INITIALIZED', 'TRUE');
  return 'System Initialized';
}

function createHourlyTrigger() {
  // ✅ فصل جوهري (تحسين فعالية): تحليل الطلبات (فتح الـ120 شيت وقراءتها) بقى تريجر
  // منفصل تمامًا عن updateHistory — راجع analyzeBusinessOrders() تحت لتفاصيل السبب.
  // بيتشغّل الساعة XX:50 (10 دقايق قبل updateHistory اللي في XX:00) عشان لما
  // updateHistory تستدعي getData()، تلاقي أرقام الساعة دي محدّثة فعلاً وليست القديمة.
  ScriptApp.newTrigger('analyzeBusinessOrders').timeBased().everyHours(1).nearMinute(50).create();
  ScriptApp.newTrigger('updateHistory').timeBased().everyHours(1).create();
  ScriptApp.newTrigger('checkMonthlySnapshot').timeBased().everyDays(1).atHour(0).create();
  ScriptApp.newTrigger('settleMaturedAPOrders').timeBased().everyDays(1).atHour(1).create();
  // ✅ جديد: أرشفة أسبوعية — تمنع شيت Subscribers من التضخم للأبد مع نمو المشتركين
  ScriptApp.newTrigger('archiveExpiredSubscribers').timeBased().everyDays(7).atHour(2).create();
  // ✅ جديد: تقرير الأوراكل الشهري لمشتركي ڤندكس (checkOracleReports بيقرر لوحده
  // لو الشهر ده كمان نصف سنوي/سنوي — راجع installOracleReportTrigger للتفعيل
  // المنفصل على نظام شغّال بالفعل)
  ScriptApp.newTrigger('checkOracleReports').timeBased().onMonthDay(1).atHour(7).create();
  return 'Triggers Created';
}
// ✅ ملاحظة: لقطة الطلبات اليومية (DailyOrderStats) ما محتاجاش تريجر منفصل — بتتسجل
// مباشرة من جوه analyzeBusinessOrders() نفسها (دالة recordDailyOrderCounts) بتاريخ كل
// طلب الحقيقي، مش بلقطة ليلية تقريبية. يعني مفيش خطوة تفعيل إضافية مطلوبة هنا.

// ✅ جديد: تريجر تفعيل التحليل المنفصل على نظام شغّال بالفعل (بدون تكرار باقي التريجرز
// الأربعة الموجودين) — استخدمها مرة واحدة لو النظام مركّب من قبل تعديل الفصل ده.
// شغّلها بدل createHourlyTrigger() الكاملة عشان ما تتكررش التريجرز التانية.
function installAnalysisTrigger() {
  ScriptApp.newTrigger('analyzeBusinessOrders').timeBased().everyHours(1).nearMinute(50).create();
  return 'تم تفعيل تريجر تحليل الطلبات الساعي (analyzeBusinessOrders) — أول تشغيلة الساعة XX:50 تقريبًا';
}

// ✅ جديد: شغّلها مرة واحدة يدويًا لو شيت BusinessSheets عندك موجود بالفعل من قبل
// إضافة باقة ماقما — بتضيف عناوين عمودي Category/ExternalLink الجداد من غير ما
// تلمس أي بيانات موجودة. لو الشيت اتنشأ حديثًا (initializeSystem بعد هذا التحديث)،
// العناوين هتكون موجودة من الأول ومفيش داعي تشغّلها.
function migrateBusinessSheetsCategoryColumns() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  if (!sheet) return 'شيت BusinessSheets مش موجود أصلاً — شغّل initializeSystem الأول';
  if (!sheet.getRange(1, 7).getValue()) sheet.getRange(1, 7).setValue('Category');
  if (!sheet.getRange(1, 8).getValue()) sheet.getRange(1, 8).setValue('ExternalLink');
  return 'تم إضافة عناوين Category/ExternalLink لشيت BusinessSheets';
}

// ─────────────────────────────────────────────
// Snapshots & History
// ─────────────────────────────────────────────
function checkMonthlySnapshot() {
  const now = new Date();
  const day = parseInt(Utilities.formatDate(now, CONFIG.TIMEZONE, 'dd'));
  if (day !== CONFIG.SNAPSHOT_DAY) return;
  // ✅ جديد: هذا التريجر بيتشغّل مرة واحدة بس في الشهر (يوم 21) — لو فشل بصمت،
  // مفيش محاولة تانية إلا الشهر اللي بعده (30 يوم كامل)، يعني تقارير المشاركين
  // الشهرية ممكن تتأخر شهر كامل من غير ما حد يعرف. حماية أهم هنا من updateHistory.
  try {
    saveMonthlySnapshotWithNotification();
  } catch(err) {
    Logger.log('checkMonthlySnapshot فشلت: ' + err + (err && err.stack ? ('\n' + err.stack) : ''));
    try {
      sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - تنبيه هام: فشل التقرير الشهري',
        'محاولة إرسال التقرير الشهري (يوم ' + CONFIG.SNAPSHOT_DAY + ') فشلت بالكامل.\n\n' +
        'السبب: ' + err + '\n\n' +
        'المشاركين ما استلموش تقريرهم الشهري. راجع سجل Executions في Apps Script وشغّل ' +
        'saveMonthlySnapshotWithNotification() يدوياً بعد حل المشكلة.');
    } catch(e) {}
    throw err;
  }
}

function saveMonthlySnapshot() {
  const data = getData();
  const month = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM');
  const top5 = data.trending.slice(0,5).map(x => x[0]).join(', ');
  const snapshotSheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Monthly_Snapshots');
  // ✅ إصلاح بگ مؤكد: getRange(2,1,getLastRow()-1,1) بترمي استثناء فعلي لو الشيت لسه
  // فاضي (بس صف العنوان، getLastRow()=1) — عدد الصفوف بيبقى صفر وGAS بيرفضه صراحة.
  // ده بالظبط حال الشيت أول مرة يتشغل فيها الـsnapshot الشهري، فالدالة كانت تفشل
  // بالكامل وتوقف saveMonthlySnapshotWithNotification معاها (بما فيها إيميلات المشاركين).
  const existing = snapshotSheet.getLastRow() < 2 ? [] :
    snapshotSheet.getRange(2,1,snapshotSheet.getLastRow()-1,1).getValues().flat();
  if (!existing.includes(month)) {
    snapshotSheet.appendRow([month,data.timestamp,data.index.NAV,data.index.IIV,data.index.premium,data.index.netOrders,data.index.netUnits,data.index.components,top5]);
  }
}

function getMonthlySnapshots() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Monthly_Snapshots');
  if (sheet.getLastRow() < 2) return [];
  return sheet.getRange(2,1,sheet.getLastRow()-1,9).getValues().map(r => ({
    month:r[0],date:r[1],NAV:r[2],IIV:r[3],premium:r[4],
    netOrders:r[5],netUnits:r[6],components:r[7],top5:r[8]
  })).reverse();
}

function getHistoricalData(month) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('History');
  const data = sheet.getDataRange().getValues();
  return data.filter((r,i) => i>0 && Utilities.formatDate(new Date(r[0]),CONFIG.TIMEZONE,'yyyy-MM') === month)
             .map(r => ({time:Utilities.formatDate(new Date(r[0]),CONFIG.TIMEZONE,'HH:mm'),NAV:r[1],IIV:r[2]}));
}

// ✅ إصلاح: updateHistory تكتب في History فقط — مش في كل زيارة للداشبورد
// ✅ فصل جوهري: بعد استخراج analyzeBusinessOrders() كتريجر منفصل (يشتغل XX:50، قبل
// updateHistory بـ10 دقايق)، هذه الدالة بقت تعتمد على getData() السريعة (قراءة
// Properties جاهزة بس) بدل ما تكون هي نفسها سبب فتح الـ120 شيت. الترتيب الزمني للتريجرز
// (analyzeBusinessOrders الساعة XX:50 ثم updateHistory الساعة XX:00) يضمن إن الأرقام
// اللي هتتسجل في History كل ساعة تكون محدّثة من تحليل نفس الساعة، مش من الساعة اللي قبلها.
function updateHistory() {
  // ✅ جديد: هذا التريجر الساعي الأهم — بيشغّل اعتماد الدفعات وتحديث ملخص التوزيعات
  // وتحديث الـ NAV كله. لو فشل باستثناء جوجل هتبعت إيميل تلقائي فعلاً (ده مفيد، سايبينه
  // شغال بإعادة رمي الخطأ تحت) لكن رسالته تقنية بحتة. هنا بنضيف تنبيه إضافي مبسّط
  // وواضح للأدمن + تسجيل صريح في Logger.
  try {
    processApprovedPayments(); // ✅ جديد: يفعّل/يرفض الدفعات اللي راجعها الأدمن يدوياً بالشيت
    updateDistributionSummary(); // ✅ جديد: يحدّث ملخص "مستحق/اتحول" لكل بزنس
    const data = getData();
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('History');
    sheet.appendRow([new Date(),data.index.NAV,data.index.IIV,data.index.premium,
      data.index.netOrders,data.index.netUnits,data.index.grossOrders,data.index.redemptionOrders]);
    updateParticipantValues(parseFloat(data.index.NAV));
  } catch(err) {
    Logger.log('updateHistory فشلت: ' + err + (err && err.stack ? ('\n' + err.stack) : ''));
    try {
      sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - تنبيه: فشل التحديث الساعي',
        'التحديث الساعي (updateHistory) فشل ولم يتم تحديث NAV/اعتماد الدفعات هذه الساعة.\n\n' +
        'السبب: ' + err + '\n\n' +
        'لو تكرر الأمر أكتر من ساعة أو اتنين، راجع سجل Executions في Apps Script.');
    } catch(e) {}
    throw err; // ✅ نعيد رميه عشان إيميل جوجل التلقائي (تفاصيل تقنية كاملة) يفضل شغال زي ما هو
  }
}

// ✅ إصلاح: شِيل بُعد "النوع" (شراء/استرداد) بالكامل من هنا بطلب صريح — داتا الطلبات
// المعتمدة للداشبورد 3 أبعاد بس: اسم المنتج، تاريخ الطلب، الموقع الجغرافي. الجدول
// دلوقتي عمودين بس: التاريخ + صافي عدد الطلبات (بيزيد مع الشراء، بينقص مع الاسترداد،
// زي ما بالظبط productCount شغّالة) + أكثر منتج. upsert: لو التاريخ موجود يزوّد
// عليه (أو ينقص لو صافي سالب)، لو تاريخ جديد يضيف صف. آمنة حتى لو batch واحد فيه
// أكتر من تاريخ مختلف (بزنس اتأخر في المزامنة وجاله backlog من كذا يوم دفعة واحدة).
function recordDailyOrderCounts(netByDate, productsByDate) {
  const allDates = Object.keys(netByDate||{});
  if (allDates.length === 0) return;
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('DailyOrderStats');
  if (!sheet) return;
  const lastRow = sheet.getLastRow();
  const existing = lastRow >= 2 ? sheet.getRange(2, 1, lastRow - 1, 3).getValues() : [];
  const rowIndexByDate = {};
  existing.forEach((r, i) => {
    const d = r[0] instanceof Date ? Utilities.formatDate(r[0], CONFIG.TIMEZONE, 'yyyy-MM-dd') : String(r[0]);
    rowIndexByDate[d] = i + 2;
  });
  allDates.forEach(date => {
    const netChange = netByDate[date] || 0;
    const newProducts = (productsByDate && productsByDate[date]) || {};
    if (rowIndexByDate[date]) {
      const row = rowIndexByDate[date];
      const curTotal = parseInt(sheet.getRange(row, 2).getValue()) || 0;
      sheet.getRange(row, 2).setValue(Math.max(0, curTotal + netChange));
      let existingProducts = {};
      try { (JSON.parse(sheet.getRange(row, 3).getValue() || '[]')).forEach(p => existingProducts[p.name] = p.count); } catch(e) {}
      Object.keys(newProducts).forEach(p => existingProducts[p] = (existingProducts[p]||0) + newProducts[p]);
      const mergedTop = Object.entries(existingProducts).sort((a,b) => b[1]-a[1]).slice(0,5)
        .map(([name,count]) => ({name:name, count:count}));
      sheet.getRange(row, 3).setValue(JSON.stringify(mergedTop));
    } else {
      const topProducts = Object.entries(newProducts).sort((a,b) => b[1]-a[1]).slice(0,5)
        .map(([name,count]) => ({name:name, count:count}));
      sheet.appendRow([date, Math.max(0, netChange), JSON.stringify(topProducts)]);
    }
  });
  // ✅ تنظيف: خلي آخر 400 يوم بس (أكتر من سنة) عشان الشيت ميكبرش للأبد
  const finalLastRow = sheet.getLastRow();
  if (finalLastRow > 401) sheet.deleteRows(2, finalLastRow - 401);
}

// ✅ جديد: يقرأ DailyOrderStats كامل ويرتبه بتاريخه الحقيقي قبل ما ياخد آخر N يوم —
// ضروري لأن upsert مش بالضرورة بيضيف الصفوف بترتيب تاريخي (backlog من بزنس متأخر
// ممكن يوصل بتاريخ أقدم من آخر صف موجود فعلاً)، فـ"آخر N صف" مش نفس "آخر N تاريخ".
function getDailyOrderTrend(days) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('DailyOrderStats');
  if (!sheet || sheet.getLastRow() < 2) return [];
  const n = days || 30;
  const allRows = sheet.getRange(2, 1, sheet.getLastRow() - 1, 3).getValues();
  const parsed = allRows.map(r => {
    let topProduct = null;
    try { const p = JSON.parse(r[2] || '[]'); if (p[0]) topProduct = p[0].name; } catch(e) {}
    return {
      date: r[0] instanceof Date ? Utilities.formatDate(r[0], CONFIG.TIMEZONE, 'yyyy-MM-dd') : String(r[0]),
      orders: parseInt(r[1]) || 0,
      topProduct: topProduct
    };
  });
  parsed.sort((a,b) => a.date < b.date ? -1 : (a.date > b.date ? 1 : 0));
  return parsed.slice(-n);
}

// ✅ جديد: إرسال إشعار يوم 21
function saveMonthlySnapshotWithNotification() {
  saveMonthlySnapshot();
  const data = getData();

  // بيانات شخصية لكل مشارك
  const participantsData = {};
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Participants');
  if (sheet.getLastRow() > 1) {
    sheet.getDataRange().getValues().slice(1).forEach(row => {
      if (row[1] === 'active') {
        participantsData[row[0]] = {
          currentValue: parseFloat(row[5]).toFixed(2),
          pnl: parseFloat(row[6]).toFixed(2)
        };
      }
    });
  }

  // إيميل لكل مشارك يوم 21
  sendMonthlyEmailsToParticipants(data);
}

// ✅ جديد: إيميل شهري لكل مشارك
// ✅ إصلاح: كان فشل الإرسال (مثلاً وصول MailApp لحده اليومي منتصف القائمة) يُبتلع
// بصمت (catch(e){} فاضي) — باقي المشاركين ما كانوا يستلموا تقريرهم ولا حد يعرف.
// دلوقتي نعد الفشل ونبلّغ الأدمن بملخص واحد في الآخر لو صار أي فشل.
function sendMonthlyEmailsToParticipants(data) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Participants');
  if (sheet.getLastRow() < 2) return;
  const rows = sheet.getDataRange().getValues().slice(1);
  let failedCount = 0;
  const failedEmails = [];
  rows.forEach(row => {
    const email = row[0];
    const status = row[1];
    if (status !== 'active') return;
    const currentValue = parseFloat(row[5]).toFixed(2);
    const pnl = parseFloat(row[6]);
    const pnlText = pnl >= 0 ? '+$' + pnl.toFixed(2) + ' ربح' : '-$' + Math.abs(pnl).toFixed(2) + ' خسارة';
    const top5 = data.trending.slice(0,5).map(x=>x[0]).join('، ');
    try {
      const sendResult = sendTransactionalEmail(email, CONFIG.INDEX_TICKER + ' - تقرير يوم 21',
        'تقرير صندوق ' + CONFIG.INDEX_TICKER + '\n\n' +
          'قيمة حصتك: $' + currentValue + '\n' +
          'الربح/الخسارة: ' + pnlText + '\n' +
          'NAV: $' + data.index.NAV + '\n' +
          'Top5: ' + top5 + '\n\n' +
          'افتح الداشبورد للتفاصيل.');
      if (!sendResult.success) { failedCount++; failedEmails.push(email); }
    } catch(e) { failedCount++; failedEmails.push(email); }
  });
  if (failedCount > 0) {
    try {
      sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - تنبيه: فشل إرسال ' + failedCount + ' تقرير شهري',
        'فشل إرسال التقرير الشهري لـ ' + failedCount + ' مشارك (على الأغلب وصلنا لحد MailApp اليومي).\n\n' +
        'الإيميلات المتأثرة:\n' + failedEmails.join('\n') + '\n\n' +
        'راجع تفعيل Resend (Script Properties → RESEND_API_KEY) لتفادي هذا مستقبلاً.');
    } catch(e) {}
  }
}

// ⚠️ تم إيقاف Render نهائياً (استضافة مجانية غير مستقرة + كانت بتسرّب RENDER_SECRET
// بالكود). الدالة باقية كـ no-op عشان أماكن الاستدعاء ما تنكسرش — لو حبيت إشعارات
// فورية مستقبلاً، أفضل بديل serverless: Cloudflare Worker + Queues أو GAS triggers.
function sendNotificationToRender(type, payload) {
  // متعمّد فارغة — لا استدعاء شبكي، لا سر مكشوف.
}

function getAllParticipantEmails() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Participants');
  if (sheet.getLastRow() < 2) return [];
  return sheet.getDataRange().getValues().slice(1)
    .filter(r => r[1] === 'active')
    .map(r => r[0]);
}

// ─────────────────────────────────────────────
// ✅ جديد: نظام المشاركين
// ─────────────────────────────────────────────

// حساب توزيع الـ$513 على البزنسات حسب الأوزان
function calcAllocation(weights) {
  const alloc = {};
  weights.forEach(w => {
    alloc[w.name] = parseFloat((parseFloat(w.weight) / 100 * CONFIG.SHARE_PRICE).toFixed(2));
  });
  return alloc;
}

// شراء حصة — المشارك يدخل الصندوق
function buyShare(email, targetMarketRow) {
  // ✅ جديد: قفل — يمنع مستخدمين اتنين يضغطوا "اشتري" بنفس اللحظة ويحجزوا نفس حصة السوق مرتين
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return {error: 'النظام مشغول، حاول تاني بعد لحظات'};

  try {
    const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
    const sheet = master.getSheetByName('Participants');
    const data = sheet.getDataRange().getValues();

    // التحقق من عدم الاشتراك المسبق
    // ملاحظة مراجعة: قيّمنا توحيد الفحص ده مع isEmailAuthorized (اللي معاد بناؤها
    // بـTextFinder للتوسّع) ورفضناه — المعنى مختلف (هنا "عنده سجل نشط بالفعل؟"، مش
    // "مصرح له يشتري؟")، والفحص بيوقف عند أول تطابق (مش بيدور على كل الصفوف زي
    // isSubscriberActive)، وعدد المشاركين الفعليين (مستثمرين دفعوا $513 فعلاً) محدود
    // بطبيعته أصلاً بعكس Subscribers/AllowedEmails. التوحيد كان تعقيد بلا فايدة أداء حقيقية.
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === email && data[i][1] === 'active') {
        return {error: 'المشارك مسجل مسبقاً'};
      }
    }

    // ✅ لو عنده طلب دفع سابق لسا مفتوح (بانتظار OTP أو بانتظار المراجعة) — ما ننشئ طلب جديد
    const pendingSheet = master.getSheetByName('PendingPayments');
    const pendingData = pendingSheet.getDataRange().getValues();
    for (let i = 1; i < pendingData.length; i++) {
      if (pendingData[i][0] === email) {
        const status = pendingData[i][5];
        if (status === 'awaiting_otp') {
          const mail = buildOTPEmail(email, pendingData[i][1], pendingData[i][2]);
          const sendResult = sendTransactionalEmail(mail.to, mail.subject, mail.body);
          // ✅ إصلاح حرج: كان بيتجاهل فشل الإرسال (خدمة الإيميل وصلت حدها اليومي) ويرجّع
          // نجاح وهمي — المستخدم يفضل مستني رمز ما بيوصلش أبداً. دلوقتي بنقول له صريح.
          if (!sendResult.success) {
            return {error: 'تعذّر إرسال رمز التحقق حالياً (خدمة الإيميل وصلت حدها). حاول تاني بعد شوية أو تواصل مع الأدمن.'};
          }
          return {status: 'pending_payment', stage: 'awaiting_otp', amount: pendingData[i][2]};
        }
        if (status === 'awaiting_review') {
          return {status: 'pending_payment', stage: 'awaiting_review', amount: pendingData[i][2]};
        }
      }
    }

    // تحديد السعر والمصدر: من السوق لو متاح (نحجزها ولا نبيعها نهائياً إلا بعد اعتماد الدفع)، وإلا مباشرة من الصندوق
    const marketSheet = master.getSheetByName('Market');
    const market = marketSheet.getDataRange().getValues();
    let amount = CONFIG.SHARE_PRICE;
    let sellerEmail = '';
    let marketRow = 0;

    // ✅ إصلاح ثغرة: قبل كده لو المستخدم ضغط "شراء" على حصة معيّنة بشاشة السوق (سعر/بائع
    // محدد ظاهر بالواجهة)، كانت buyShare تتجاهل تحديده تماماً وتاخد أول صف "available"
    // بترتيب الشيت — ممكن يكون سعر/بائع مختلف تماماً عن اللي شافه وضغط عليه فعلاً.
    // دلوقتي لو الفرونت اند بعت رقم صف محدد، نتأكد إنه لسه "available" ونحجزه هو بالذات.
    const wantedRow = parseInt(targetMarketRow) || 0;
    if (wantedRow > 1 && wantedRow <= market.length) {
      const row = market[wantedRow - 1];
      if (row && row[3] === 'available') {
        // ✅ إصلاح: الفرونت اند بيمنع شراء حصتك هو نفسه بإخفاء الزرار — ده فحص واجهة
        // بس، أي استدعاء مباشر للـ API كان يتجاوزه. نفس المنع لازم يكون في الباك اند.
        if (String(row[0]).toLowerCase() === email.toLowerCase()) {
          return {error: 'لا يمكنك شراء حصتك المعروضة أنت للبيع'};
        }
        amount = parseFloat(row[1]);
        sellerEmail = row[0];
        marketRow = wantedRow;
        marketSheet.getRange(marketRow, 4).setValue('pending');
      } else {
        return {error: 'هذه الحصة لم تعد متاحة — حدّث الصفحة وجرّب حصة تانية'};
      }
    } else {
      for (let i = 1; i < market.length; i++) {
        // ✅ نفس المنع هنا كمان: الاختيار التلقائي (بدون تحديد حصة بعينها) لازم يتخطى
        // أي حصة معروضة من نفس المستخدم بدل ما يحجزها له بالغلط
        if (market[i][3] === 'available' && String(market[i][0]).toLowerCase() !== email.toLowerCase()) {
          amount = parseFloat(market[i][1]);
          sellerEmail = market[i][0];
          marketRow = i + 1;
          marketSheet.getRange(marketRow, 4).setValue('pending'); // محجوزة لحين اعتماد الدفع، مو مباعة نهائياً بعد
          break;
        }
      }
    }

    const otp = generateOTP();
    // ✅ جديد: try/catch إضافي هنا — لو حصل استثناء غير متوقع (مش فشل إرسال إيميل
    // عادي، ده متحكم فيه أصلاً، لكن خطأ حقيقي زي مشكلة وصول مؤقتة للشيت) بعد ما
    // الحصة اتحجزت (pending) وقبل ما الطلب يتسجل بالكامل، كانت الحصة هتفضل عالقة
    // 'pending' للأبد بدون أي استرداد تلقائي. دلوقتي أي عطل هنا بيرجّعها 'available'.
    try {
      const mail = buildOTPEmail(email, otp, amount);
      const sendResult = sendTransactionalEmail(mail.to, mail.subject, mail.body);
      if (!sendResult.success) {
        // ✅ إصلاح حرج: لو فشل الإرسال، لازم نفك حجز حصة السوق فوراً — وإلا حصة نادرة
        // تفضل "pending" محجوزة لطلب ما هيكمل أبداً، وما حد تاني يقدر يشتريها
        if (marketRow > 0) marketSheet.getRange(marketRow, 4).setValue('available');
        return {error: 'تعذّر إرسال رمز التحقق حالياً (خدمة الإيميل وصلت حدها). حاول تاني بعد شوية أو تواصل مع الأدمن.'};
      }
      // العمود العاشر (Index 9): FailedAttempts — عداد محاولات رمز خاطئة، يبدأ من صفر
      pendingSheet.appendRow([email, otp, amount, sellerEmail, marketRow, 'awaiting_otp', new Date(), '', '', 0]);
      logAudit(email, 'buy_initiated', {amount: amount, marketRow: marketRow, sellerEmail: sellerEmail || null});
    } catch(innerErr) {
      if (marketRow > 0) {
        try { marketSheet.getRange(marketRow, 4).setValue('available'); } catch(e2) {}
      }
      Logger.log('buyShare فشلت بعد حجز الحصة — تم فك الحجز: ' + innerErr);
      return {error: 'حدث خطأ غير متوقع — حاول تاني'};
    }

    return {status: 'pending_payment', stage: 'awaiting_otp', amount: amount};
  } finally {
    lock.releaseLock();
  }
}

// ✅ جديد: يستقبل رمز التحقق + رقم/مرجع المعاملة البنكية بعد التحويل
// ✅ جديد: يمنع استخدام نفس رقم مرجع المعاملة البنكية مرتين — بدونه، شخص يقدر ياخد
// صورة إشعار تحويل حقيقي (بتاعه أو حتى مسروق) ويحاول يستخدم نفس الرقم على أكتر من
// طلب، والمراجعة اليدوية للأدمن ممكن ما تلاحظش لو عنده طلبات كتير قدامه. الفحص عبر
// PendingPayments وSubscribers مع بعض، لأن نفس المرجع ممكن يتحاول استخدامه في
// النوعين. بيتجاهل الطلبات اللي اتقفلت قبل مرحلة إدخال txnRef أصلاً (زي انتهاء صلاحية
// أو قفل بمحاولات كتيرة) لأنها مش محاولة إعادة استخدام فعلية.
function isTxnRefAlreadyUsed(txnRef, excludeSheetName, excludeRow) {
  const normalized = String(txnRef).trim().toLowerCase();
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);

  const paymentsSheet = master.getSheetByName('PendingPayments');
  if (paymentsSheet && paymentsSheet.getLastRow() >= 2) {
    const data = paymentsSheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (excludeSheetName === 'PendingPayments' && (i+1) === excludeRow) continue;
      const existingRef = String(data[i][7] || '').trim().toLowerCase();
      if (existingRef && existingRef === normalized) return true;
    }
  }

  const subsSheet = master.getSheetByName('Subscribers');
  if (subsSheet && subsSheet.getLastRow() >= 2) {
    const data = subsSheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (excludeSheetName === 'Subscribers' && (i+1) === excludeRow) continue;
      const existingRef = String(data[i][6] || '').trim().toLowerCase();
      if (existingRef && existingRef === normalized) return true;
    }
  }

  return false;
}

function submitPaymentVerification(email, otp, txnRef) {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('PendingPayments');
  const data = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === email && data[i][5] === 'awaiting_otp') {
      const requestedAt = new Date(data[i][6]);
      const hoursElapsed = (new Date() - requestedAt) / 3600000;
      if (hoursElapsed > CONFIG.OTP_EXPIRY_HOURS) {
        return {error: 'انتهت صلاحية الرمز. اضغط "اشتري حصة" مرة ثانية لطلب رمز جديد'};
      }
      if (String(data[i][1]).trim() !== String(otp).trim()) {
        // ✅ جديد: حد لعدد المحاولات — بدونه كان أي حد يعرف الإيميل يقدر يجرّب المليون احتمال
        // للرمز المكوّن من 6 أرقام (brute-force) لأن ما كان في أي قفل بعد المحاولات الفاشلة.
        const attempts = (parseInt(data[i][9]) || 0) + 1;
        if (attempts >= CONFIG.OTP_MAX_ATTEMPTS) {
          sheet.getRange(i+1, 6).setValue('closed_locked'); // يقفل الطلب نهائياً
          const marketRow = parseInt(data[i][4]) || 0;
          if (marketRow > 0) {
            master.getSheetByName('Market').getRange(marketRow, 4).setValue('available'); // يرجّع الحصة متاحة بالسوق
          }
          return {error: 'محاولات كتيرة برمز غلط — الطلب اتقفل. اضغط "اشتري حصة" تاني لطلب رمز جديد'};
        }
        sheet.getRange(i+1, 10).setValue(attempts);
        return {error: 'رمز التحقق غير صحيح (' + attempts + '/' + CONFIG.OTP_MAX_ATTEMPTS + ')'};
      }
      if (!txnRef || !String(txnRef).trim()) {
        return {error: 'رقم/مرجع المعاملة مطلوب'};
      }
      if (!isValidTxnRef(txnRef)) {
        return {error: 'رقم/مرجع المعاملة يحتوي على رموز غير مسموحة — أدخل الرقم/الكود كما هو من إشعار البنك بدون رموز خاصة'};
      }
      // ✅ جديد: منع إعادة استخدام نفس رقم المعاملة على طلب آخر (شراء أو اشتراك)
      if (isTxnRefAlreadyUsed(txnRef, 'PendingPayments', i+1)) {
        return {error: 'رقم المعاملة ده مستخدم بالفعل في طلب سابق — تأكد إنك بتدخل رقم المرجع الصحيح من إشعار البنك'};
      }
      sheet.getRange(i+1, 8).setValue(String(txnRef).trim()); // TxnRef
      sheet.getRange(i+1, 9).setValue(new Date());            // SubmittedAt
      sheet.getRange(i+1, 6).setValue('awaiting_review');      // Status
      try {
        sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - دفعة جديدة بانتظار المراجعة',
          'مشارك: ' + email + '\nالمبلغ: $' + data[i][2] +
                '\nرقم المعاملة المُدخل: ' + txnRef +
                '\n\nراجع الحوالة البنكية فعلياً، بعدين اعتمد الطلب من لوحة الأدمن.');
      } catch(e) {}
      pushToAdmins('دفعة جديدة بانتظار المراجعة', String(email) + ' — مرجع: ' + String(txnRef));
      return {status: 'submitted_for_review'};
    }
  }
  return {error: 'ما لقينا طلب دفع بانتظار رمز تحقق لهذا الإيميل — اضغط "اشتري حصة" أولاً'};
}

// ✅ جديد: طلب اشتراك "لافا" (يومي) أو "سنوي" — لطبقة العامة، بدون حصة حقيقية بالصندوق.
// نفس نمط buyShare بالضبط (OTP + مراجعة أدمن يدوية) لكن على شيت Subscribers منفصل.
// ✅ دالة داخلية موحّدة: تلاقي آخر صف لإيميل معيّن في شيت Subscribers عبر TextFinder
// (بدون سحب الشيت كامل). تُستخدم من subscribeLava (محتاجة الـ OTP الفعلي للإعادة)
// ومن getSubscriptionStatus (نسخة مبسّطة بدون OTP، آمنة للواجهة).
function findLatestSubscriberRow(sheet, email) {
  if (sheet.getLastRow() < 2) return null;
  const finder = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1)
    .createTextFinder(email).matchEntireCell(true).matchCase(false);
  const matches = finder.findAll();
  if (matches.length === 0) return null;
  const rowNum = matches[matches.length - 1].getRow();
  const vals = sheet.getRange(rowNum, 1, 1, 12).getValues()[0];
  return {
    row: rowNum, email: vals[0], tier: vals[1], otp: vals[2], amount: vals[3],
    status: vals[4], requestedAt: vals[5], txnRef: vals[6], submittedAt: vals[7],
    startDate: vals[8], endDate: vals[9], failedAttempts: vals[10],
    country: String(vals[11] || '')
  };
}

// ✅ جديد: آخر صف لإيميل + باقة محددة (+ دولة للباقات perCountry) — ضروري لأن المستخدم
// الآن يقدر يشترك في أكثر من باقة، وكل باقة لها صف وحالة مستقلة.
function findSubscriberRowForTier(sheet, email, tier, country) {
  if (sheet.getLastRow() < 2) return null;
  const matches = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1)
    .createTextFinder(email).matchEntireCell(true).matchCase(false).findAll();
  const info = tierInfo(tier);
  for (let i = matches.length - 1; i >= 0; i--) {
    const rowNum = matches[i].getRow();
    const vals = sheet.getRange(rowNum, 1, 1, 12).getValues()[0];
    if (vals[1] !== tier) continue;
    if (info && info.perCountry && normalizeCountry(vals[11]) !== normalizeCountry(country)) continue;
    return {
      row: rowNum, email: vals[0], tier: vals[1], otp: vals[2], amount: vals[3],
      status: vals[4], requestedAt: vals[5], txnRef: vals[6], submittedAt: vals[7],
      startDate: vals[8], endDate: vals[9], failedAttempts: vals[10],
      country: String(vals[11] || '')
    };
  }
  return null;
}

// ✅ جديد: دوال مساعدة موحّدة لقراءة إعدادات أي باقة من TIER_CONFIG — بديل عن
// انتشار `tier === 'lava' ? أ : ب` في كذا دالة مختلف، وأساس آمن لإضافة باقات
// مستقبلية من غير ما نلمس نفس المنطق تاني.
function tierInfo(tier) {
  return CONFIG.TIER_CONFIG[tier] || null;
}
function tierPrice(tier) {
  const info = tierInfo(tier);
  if (!info) return 0;
  return CONFIG[info.priceProp];
}
function tierBaseMax(tier) {
  const info = tierInfo(tier);
  return (info && info.maxProp) ? CONFIG[info.maxProp] : 0;
}
// المبلغ الأولي المطلوب عند بدء الاشتراك: الفرانشايز يبدأ بدفعة الحجز، الباقي بالسعر الكامل
function tierInitialAmount(tier) {
  const info = tierInfo(tier);
  if (info && info.progressive) return CONFIG.FRANCHISE_RESERVATION_USD;
  return tierPrice(tier);
}
function tierDurationMs(tier) {
  const info = tierInfo(tier);
  return info ? info.durationMs : 0;
}
function tierNameAr(tier) {
  const info = tierInfo(tier);
  return info ? info.nameAr : tier;
}

// ✅ جديد: عدد المشتركين النشطين فعليًا (status='active' وEndDate لسه ما خلصش)
// لباقة معينة — يُحسب بفحص شيت Subscribers مباشرة (قراءة دفعة واحدة، مش صف صف)،
// مع كاش قصير (60 ثانية) عشان لو كذا طلب اشتراك جالوا مع بعض في نفس اللحظة ما
// نكررش الفحص الثقيل. الأرشفة الأسبوعية (archiveExpiredSubscribers) بتشيل الصفوف
// المنتهية القديمة من الشيت الحي، فالفحص هنا بيفضل سريع حتى مع نمو المشتركين.
function countActiveSubscribers(tier) {
  // ✅ أداء: مسح واحد للشيت يحسب كل الباقات مرة واحدة (بدل مسح لكل باقة × 10 باقات)،
  // ويُخزَّن 60 ثانية. مهم مع نمو Subscribers (آلاف الصفوف، وأكثر مع لافا اليومي).
  const all = getAllActiveCounts();
  return all[tier] || 0;
}
function getAllActiveCounts() {
  const cacheKey = 'ACTIVE_SUB_COUNTS_ALL';
  const cached = cache.get(cacheKey);
  if (cached !== null) { try { return JSON.parse(cached); } catch (e) {} }
  const counts = {};
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
    if (sheet && sheet.getLastRow() >= 2) {
      const data = sheet.getRange(2, 2, sheet.getLastRow() - 1, 9).getValues(); // B..J: Tier..EndDate
      const now = new Date();
      for (let i = 0; i < data.length; i++) {
        if (data[i][3] === 'active' && new Date(data[i][8]) > now) counts[data[i][0]] = (counts[data[i][0]] || 0) + 1;
      }
    }
  } catch(e) { Logger.log('getAllActiveCounts error: ' + e); }
  try { cache.put(cacheKey, JSON.stringify(counts), 60); } catch (e) {}
  return counts;
}

// ✅ جديد: السقف *الفعلي* الحالي لباقة معينة — بياخد في الاعتبار حجز ڤندكس لباقتي
// لافا (يومي/سنوي). كل مشترك ڤندكس نشط بيقلل السقف المتاح (مش بيلغي مشتركين
// موجودين فعلاً — لو النتيجة أقل من عدد النشطين الحاليين، محدش بيتشال، بس مفيش
// أماكن جديدة تتفتح لحد ما مشتركين حاليين يخلصوا مدتهم أو ڤندكس نشط يقل).
// الحد الأدنى صفر دايمًا (Math.max) — حماية ضد رقم سالب لو ڤندكس اتباع بالكامل.
function getEffectiveTierMax(tier) {
  const info = tierInfo(tier);
  if (info && info.perCountry) return Infinity; // تايكون: السقف لكل دولة (عضو واحد/دولة)
  const base = tierBaseMax(tier);
  if (tier === 'lava' || tier === 'annual') {
    const fendexActive = countActiveSubscribers('fendex');
    const reserve = tier === 'lava' ? CONFIG.FENDEX_LAVA_DAILY_RESERVE : CONFIG.FENDEX_LAVA_ANNUAL_RESERVE;
    return Math.max(0, base - (fendexActive * reserve));
  }
  return base;
}

// ✅ جديد: عدد النشطين في "مجموعة سعة" مشتركة (OMS خدمات + منتجات + VIP = سقف واحد 120)
function countActiveInCapacityGroup(group) {
  let total = 0;
  Object.keys(CONFIG.TIER_CONFIG).forEach(t => {
    if (CONFIG.TIER_CONFIG[t].capacityGroup === group) total += countActiveSubscribers(t);
  });
  return total;
}
function activeCountForCapacityCheck(tier) {
  const info = tierInfo(tier);
  if (info && info.capacityGroup) return countActiveInCapacityGroup(info.capacityGroup);
  return countActiveSubscribers(tier);
}

// ✅ جديد: تايكون واحد لكل دولة — 'active' | 'pending' | null لأي طلب لنفس الدولة من إيميل آخر
function normalizeCountry(c) {
  return String(c || '').trim().replace(/\s+/g, ' ').toLowerCase();
}
function findAnyTycoonRequestForCountry(country, excludingEmail) {
  const target = normalizeCountry(country);
  if (!target) return null;
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return null;
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 12).getValues();
  const now = new Date();
  const exclude = String(excludingEmail || '').toLowerCase();
  let result = null;
  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    if (row[1] !== 'tycoon') continue;
    if (String(row[0]).toLowerCase() === exclude) continue;
    if (normalizeCountry(row[11]) !== target) continue;
    const status = row[4];
    if (status === 'active' && new Date(row[9]) > now) return 'active';
    if (status === 'awaiting_otp' || status === 'awaiting_review' || status === 'waitlisted') result = 'pending';
  }
  return result;
}

// ✅ جديد: تشغيل مرة واحدة من محرر Apps Script — يضيف عمود Country (L) لشيت Subscribers القائم
function migrateSubscribersCountryColumn() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
  if (!sheet) return 'لا يوجد شيت Subscribers';
  const header = sheet.getRange(1, 1, 1, Math.max(12, sheet.getLastColumn())).getValues()[0];
  if (String(header[11]) === 'Country') return 'العمود موجود بالفعل';
  sheet.getRange(1, 12).setValue('Country');
  return 'تمت إضافة عمود Country';
}

// ملخص الطاقة الاستيعابية لكل الباقات — لفحص السقف ولعرضه للأدمن
function getSubscriberCapacity() {
  const result = {};
  Object.keys(CONFIG.TIER_CONFIG).forEach(t => {
    const info = tierInfo(t);
    if (info.internal) return;
    result[t] = {
      active: activeCountForCapacityCheck(t),
      max: getEffectiveTierMax(t),
      baseMax: tierBaseMax(t),
      perCountry: !!info.perCountry,
      capacityGroup: info.capacityGroup || null
    };
  });
  return result;
}

// نسخة عامة آمنة: متاحة/مكتملة بدون أرقام حساسة، عدا الباقات الحصرية (الندرة جزء من عرضها)
function getSubscriptionAvailability() {
  const cap = getSubscriberCapacity();
  const result = {};
  const scarce = ['fendex', 'magma', 'reseller', 'franchise', 'oms_services', 'oms_products', 'oms_vip'];
  Object.keys(cap).forEach(t => {
    if (cap[t].perCountry) { result[t] = { available: true, perCountry: true }; return; }
    const remaining = Math.max(0, cap[t].max - cap[t].active);
    result[t] = { available: remaining > 0 };
    if (scarce.indexOf(t) !== -1) {
      result[t].remaining = remaining;
      result[t].max = cap[t].baseMax;
    }
  });
  return result;
}
function subscribeLava(email, tier, country) {
  if (!Object.prototype.hasOwnProperty.call(CONFIG.TIER_CONFIG, tier)) return {error: 'باقة غير صالحة'};
  const info = tierInfo(tier);
  if (info.internal) return {error: 'باقة غير صالحة'}; // الدفعات الداخلية لا تُطلب مباشرة
  const countryClean = String(country || '').trim().slice(0, 60);
  if (info.perCountry && countryClean.length < 2) return {error: 'country_required', message: 'الدولة مطلوبة لهذه العضوية'};
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return {error: 'النظام مشغول، حاول تاني بعد لحظات'};

  try {
    const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
    const sheet = master.getSheetByName('Subscribers');
    const now = new Date();
    const existing = findSubscriberRowForTier(sheet, email, tier, countryClean);

    // ✅ إصلاح ثغرة حقيقية: الكود القديم كان بيقارن آخر صف اشتراك للإيميل *بغض
    // النظر عن الباقة* — يعني حد عنده اشتراك لافا نشط ومحاول يترقّى لڤندكس (أغلى
    // وأحصري باقة!) كان بيترفض بـ"عندك اشتراك نشط بالفعل (لافا)" بدل ما يخليه
    // يشترك في ڤندكس فعليًا. لازم نقارن بس لو الباقة المطلوبة *نفسها* اللي عنده
    // بالفعل — مش أي باقة تانية، عشان الترقية بين الباقات تفضل ممكنة دايمًا.
    const sameScope = existing && existing.tier === tier &&
      (!info.perCountry || normalizeCountry(existing.country) === normalizeCountry(countryClean));
    if (sameScope) {
      if (existing.status === 'active' && new Date(existing.endDate) > now) {
        return {status: 'already_active', tier: existing.tier, endDate: existing.endDate};
      }
      if (existing.status === 'awaiting_otp') {
        const mail = buildSubscriptionOTPEmail(email, existing.otp, existing.tier, existing.amount);
        const sendResult = sendTransactionalEmail(mail.to, mail.subject, mail.body);
        if (!sendResult.success) {
          return {error: 'تعذّر إرسال رمز التحقق حالياً (خدمة الإيميل وصلت حدها). حاول تاني بعد شوية أو تواصل مع الأدمن.'};
        }
        return {status: 'pending_subscription', stage: 'awaiting_otp', tier: existing.tier, amount: existing.amount};
      }
      if (existing.status === 'awaiting_review') {
        return {status: 'pending_subscription', stage: 'awaiting_review', tier: existing.tier, amount: existing.amount};
      }
      // ✅ جديد: أصلاً مسجّل بقائمة الانتظار لنفس الباقة — نرجّعله نفس الحالة بدل
      // ما نضيف صف قائمة انتظار تاني (upsert، مش تكرار)
      if (existing.status === 'waitlisted') {
        return {status: 'waitlisted', tier: existing.tier, category: info.category, readyCount: getReadyBusinessCount(), targetCount: CONFIG.BUSINESS_COUNT};
      }
      // آخر حالة كانت مقفولة (rejected/locked) أو منتهية — نكمل ونعمل طلب جديد تحت
    }

    // ✅ جديد: حماية مباشرة لحق المشترك — السوق نفسه لسه في طور التكوين (أقل من
    // 120 نشاط فعلي)، فمفيش معنى حقيقي لأي اشتراك مدفوع دلوقتي (بيانات مؤشر
    // لسوق ناقص، تقرير أوراكل عن سوق غير مكتمل، دليل بزنسات ناقص). بدل ما نبدأ
    // إجراءات دفع حقيقية (OTP + تفاصيل بنكية) على منتج لسه مش جاهز، نحفظ الطلب
    // في قائمة انتظار بمعلوماته، ونتواصل معاه تلقائيًا (processSubscriptionWaitlistIfMarketReady)
    // بمجرد ما السوق يكتمل فعليًا.
    // تايكون: دولة واحدة = عضو واحد (يُفحص حتى في مرحلة ما قبل الاشتراك)
    if (info.perCountry) {
      const conflict = findAnyTycoonRequestForCountry(countryClean, email);
      if (conflict) return {error: 'country_taken', message: 'عضوية التايكون لهذه الدولة ' + (conflict === 'active' ? 'محجوزة بالفعل' : 'عليها طلب قيد المعالجة') + ' — تايكون واحد لكل دولة'};
    }

    if (!isMarketComplete()) {
      sheet.appendRow([email, tier, '', 0, 'waitlisted', now, '', '', '', '', 0, countryClean]);
      logAudit(email, 'subscription_waitlisted', {tier: tier, category: info.category, country: countryClean, readyCount: getReadyBusinessCount()});
      // ✅ إيميل تأكيد للمشترك (يدعوه لإكمال الدفع الآن من الداشبورد) + إشعار للأدمن
      try {
        sendTransactionalEmail(email, CONFIG.INDEX_TICKER + ' - تم تسجيلك، أكمل اشتراكك الآن',
          'أهلاً،\n\nتم تسجيل طلبك للباقة (' + tierNameAr(tier) + ').\n' +
          'السوق الآن ' + getReadyBusinessCount() + ' من ' + CONFIG.BUSINESS_COUNT + ' نشاط. ' +
          'يمكنك تأمين مكانك الآن: ادخل الداشبورد واضغط "تابع للدفع الآن" فتصلك تفاصيل الدفع ورمز التحقق على هذا البريد.\n\n' +
          'لا يلزمك الدفع الآن إن فضّلت الانتظار؛ وسنراسلك فور اكتمال السوق.');
        sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - طلب جديد (بانتظار الدفع)',
          'المشترك: ' + email + '\nالباقة: ' + tierNameAr(tier) + (countryClean ? '\nالدولة: ' + countryClean : ''));
      } catch (mailErr) { Logger.log('waitlist email failed: ' + mailErr); }
      return {status: 'waitlisted', tier: tier, category: info.category, readyCount: getReadyBusinessCount(), targetCount: CONFIG.BUSINESS_COUNT};
    }

    // ✅ جديد: فحص السقف — بس لطلب جديد فعليًا (لو existing كان awaiting_otp/awaiting_review
    // كان اترجّع فوق قبل ما نوصل هنا، لأن صاحبه أصلاً محجوزله مكان بالفعل). الفحص هنا
    // جوه نفس القفل (lock) اللي فوق، فمحمي من أي تعارض مع decideAdminSubscription
    // (بيشارك نفس LockService.getScriptLock() العام بالسكريبت). استخدام السقف
    // *الفعلي* (getEffectiveTierMax) هنا مهم جدًا للافا (يومي/سنوي) — بياخد في
    // الاعتبار حجز ڤندكس النشط قبل ما يقبل طلب جديد.
    const maxForTier = getEffectiveTierMax(tier);
    const activeNow = activeCountForCapacityCheck(tier);
    if (activeNow >= maxForTier) {
      return { error: 'باقة ' + tierNameAr(tier) + ' وصلت العدد الأقصى للمشتركين حاليًا (' + maxForTier.toLocaleString('en-US') + ') — حاول تاني لاحقًا لو حد جدد اشتراكه أو انتهت صلاحيته' };
    }

    const amount = tierInitialAmount(tier);
    const otp = generateOTP();
    const mail = buildSubscriptionOTPEmail(email, otp, tier, amount);
    const sendResult = sendTransactionalEmail(mail.to, mail.subject, mail.body);
    if (!sendResult.success) {
      return {error: 'تعذّر إرسال رمز التحقق حالياً (خدمة الإيميل وصلت حدها). حاول تاني بعد شوية أو تواصل مع الأدمن.'};
    }
    // ['Email','Tier','OTP','AmountUSD','Status','RequestedAt','TxnRef','SubmittedAt','StartDate','EndDate','FailedAttempts']
    sheet.appendRow([email, tier, otp, amount, 'awaiting_otp', now, '', '', '', '', 0, countryClean]);

    return {status: 'pending_subscription', stage: 'awaiting_otp', tier: tier, amount: amount};
  } finally {
    lock.releaseLock();
  }
}

// ✅ جديد: المشترك في قائمة الانتظار يضغط "تابع للدفع الآن" → نحوّل طلبه من waitlisted إلى
// awaiting_otp ونرسل له تفاصيل الدفع + رمز التحقق بالإيميل. آمنة للتكرار (لو كان بالفعل
// awaiting_otp نعيد إرسال نفس الرمز).
function prepaySubscription(email, tier, country) {
  if (!Object.prototype.hasOwnProperty.call(CONFIG.TIER_CONFIG, tier)) return {error: 'باقة غير صالحة'};
  const info = tierInfo(tier);
  const countryClean = String(country || '').trim().slice(0, 60);
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return {error: 'النظام مشغول، حاول تاني بعد لحظات'};
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
    const r = findSubscriberRowForTier(sheet, email, tier, countryClean);
    if (!r) return {error: 'ما لقينا طلب لهذه الباقة — اضغط "اشترك" أولاً'};
    if (r.status === 'awaiting_review') return {status: 'pending_subscription', stage: 'awaiting_review', tier: tier, amount: r.amount};
    if (r.status === 'active') return {status: 'already_active', tier: tier, endDate: r.endDate};
    if (r.status !== 'waitlisted' && r.status !== 'awaiting_otp') {
      return {error: 'هذا الطلب مغلق — اضغط "اشترك" لطلب جديد'};
    }
    // حماية من تكرار الضغط (إغراق الإيميل): لو الرمز أُرسل قبل أقل من دقيقة لا نعيد الإرسال
    if (r.status === 'awaiting_otp' && (new Date() - new Date(r.requestedAt)) < 60000) {
      return {status: 'pending_subscription', stage: 'awaiting_otp', tier: tier, amount: r.amount, resent: false};
    }
    let otp = r.otp, amount = r.amount;
    if (r.status === 'waitlisted') {
      const maxForTier = getEffectiveTierMax(tier);
      if (activeCountForCapacityCheck(tier) >= maxForTier) {
        return {error: 'باقة ' + tierNameAr(tier) + ' وصلت العدد الأقصى للمشتركين حاليًا'};
      }
      amount = tierInitialAmount(tier);
      otp = generateOTP();
    }
    const mail = buildSubscriptionOTPEmail(email, otp, tier, amount);
    const sendResult = sendTransactionalEmail(mail.to, mail.subject, mail.body);
    if (!sendResult.success) return {error: 'تعذّر إرسال تفاصيل الدفع حالياً — حاول بعد قليل'};
    if (r.status === 'waitlisted') {
      sheet.getRange(r.row, 3).setValue(otp);
      sheet.getRange(r.row, 4).setValue(amount);
      sheet.getRange(r.row, 5).setValue('awaiting_otp');
      sheet.getRange(r.row, 6).setValue(new Date());
      sheet.getRange(r.row, 11).setValue(0);
      logAudit(email, 'subscription_prepay_started', {tier: tier, amount: amount});
    }
    return {status: 'pending_subscription', stage: 'awaiting_otp', tier: tier, amount: amount};
  } finally {
    lock.releaseLock();
  }
}

function buildSubscriptionOTPEmail(email, otp, tier, amount) {
  const b = CONFIG.BANK_DETAILS;
  const tierName = tierNameAr(tier) + (tier === 'franchise_installment' ? '' : (tier === 'franchise' ? ' (دفعة الحجز)' : ' (' + (tier === 'lava' ? '24 ساعة' : '12 شهر') + ')'));
  // ✅ التسعير بالدولار فقط دائماً — لا يوجد أي تحويل/سعر صرف يُحسب داخل النظام.
  // ملاحظة تحويل السطر التالي ضرورية فعلياً (لا يمكن حذفها) لأن الحساب البنكي الحقيقي
  // في BANK_DETAILS هو حساب بالجنيه السوداني (IBAN يبدأ بـ SD) — النظام ما بيقدرش
  // يستقبل تحويلات دولار فعلية طالما الحساب نفسه بعملة تانية.
  const sdgLine = '\nملاحظة: القيمة أعلاه بالدولار الأمريكي فقط (تسعير المنصة بالكامل بالدولار)، لكن التحويل البنكي الفعلي بالجنيه السوداني (' + b.CURRENCY + ') — حوّل ما يعادل هذا المبلغ حسب سعر الصرف السائد يوم التحويل.';
  return {
    to: email,
    subject: CONFIG.INDEX_TICKER + ' - تفاصيل الدفع لـ ' + tierName,
    body:
      'لإتمام اشتراكك في ' + tierName + ' بقيمة $' + amount + sdgLine + '\n\n' +
      'حوّل المبلغ إلى:\n' +
      'البنك: ' + b.BANK_NAME + '\n' +
      'اسم صاحب الحساب: ' + b.ACCOUNT_HOLDER + '\n' +
      'رقم الحساب: ' + b.ACCOUNT_NUMBER + '\n' +
      'IBAN: ' + b.IBAN + '\n' +
      'الفرع: ' + b.BRANCH + '\n' +
      'العملة: ' + b.CURRENCY + '\n\n' +
      'بعد التحويل، ارجع للداشبورد وأدخل:\n' +
      '1) رمز التحقق: ' + otp + '\n' +
      '2) رقم/مرجع المعاملة من إشعار البنك\n\n' +
      'صلاحية الرمز: ' + CONFIG.OTP_EXPIRY_HOURS + ' ساعة. اشتراكك بيتفعّل بعد مراجعة الأدمن يدوياً لرقم المعاملة.'
  };
}

// ✅ معاد بناؤها للتوسّع: TextFinder بدل getDataRange() كامل — نفس المشكلة اللي حصلت في
// isSubscriberActive بالظبط.
function submitSubscriptionVerification(email, otp, txnRef, tier, country) {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Subscribers');
  const r = tier ? findSubscriberRowForTier(sheet, email, tier, country) : findLatestSubscriberRow(sheet, email);

  if (!r || r.status !== 'awaiting_otp') {
    return {error: 'ما لقينا طلب اشتراك بانتظار رمز تحقق لهذا الإيميل — اضغط "اشترك" أولاً'};
  }
  const requestedAt = new Date(r.requestedAt);
  const hoursElapsed = (new Date() - requestedAt) / 3600000;
  if (hoursElapsed > CONFIG.OTP_EXPIRY_HOURS) {
    return {error: 'انتهت صلاحية الرمز. اضغط "اشترك" مرة ثانية لطلب رمز جديد'};
  }
  if (String(r.otp).trim() !== String(otp).trim()) {
    const attempts = (parseInt(r.failedAttempts) || 0) + 1;
    if (attempts >= CONFIG.OTP_MAX_ATTEMPTS) {
      sheet.getRange(r.row, 5).setValue('closed_locked');
      return {error: 'محاولات كتيرة برمز غلط — الطلب اتقفل. اضغط "اشترك" تاني لطلب رمز جديد'};
    }
    sheet.getRange(r.row, 11).setValue(attempts);
    return {error: 'رمز التحقق غير صحيح (' + attempts + '/' + CONFIG.OTP_MAX_ATTEMPTS + ')'};
  }
  if (!txnRef || !String(txnRef).trim()) {
    return {error: 'رقم/مرجع المعاملة مطلوب'};
  }
  if (!isValidTxnRef(txnRef)) {
    return {error: 'رقم/مرجع المعاملة يحتوي على رموز غير مسموحة — أدخل الرقم/الكود كما هو من إشعار البنك بدون رموز خاصة'};
  }
  // ✅ جديد: منع إعادة استخدام نفس رقم المعاملة على طلب آخر (شراء أو اشتراك)
  if (isTxnRefAlreadyUsed(txnRef, 'Subscribers', r.row)) {
    return {error: 'رقم المعاملة ده مستخدم بالفعل في طلب سابق — تأكد إنك بتدخل رقم المرجع الصحيح من إشعار البنك'};
  }
  sheet.getRange(r.row, 7).setValue(String(txnRef).trim()); // TxnRef
  sheet.getRange(r.row, 8).setValue(new Date());            // SubmittedAt
  sheet.getRange(r.row, 5).setValue('awaiting_review');      // Status
  sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - اشتراك جديد بانتظار المراجعة',
    'مشترك: ' + email + '\nالباقة: ' + r.tier + '\nالمبلغ: $' + r.amount +
    '\nرقم المعاملة المُدخل: ' + txnRef +
    '\n\nراجع الحوالة البنكية فعلياً، بعدين اعتمد الطلب من لوحة الأدمن.');
  pushToAdmins('اشتراك جديد بانتظار المراجعة', email + ' — ' + tierNameAr(r.tier) + ' ($' + r.amount + ')');
  return {status: 'submitted_for_review'};
}

// ✅ إصلاح: بترجع اسم الباقة النشطة فعليًا (lava/annual/fendex/magma) بدل true/false
// بس — لازم نميّز فندكس وماقما (ليهم صلاحيات/شاشات خاصة) عن لافا/السنوي (باقة
// مطالعة عادية بس). لسه بنفس أسلوب TextFinder بدل سحب الشيت كامل.
function getActiveSubscriberTier(email) {
  if (!email) return null;
  const lower = email.toLowerCase();
  const cacheKey = 'SUB_TIER_' + lower;
  const cached = cache.get(cacheKey);
  if (cached !== null) return cached === '' ? null : cached;

  // ✅ إصلاح: لو حد عنده أكتر من اشتراك نشط بنفس الوقت (مثلاً ڤندكس نشط، وبعدين
  // اشترك لافا كمان لأي سبب)، "آخر صف" مش بالضرورة أعلى باقة عنده — كان ممكن
  // يترجع دور "subscriber" العادي بدل "fendex" غلط لمجرد إن صف لافا اتضاف بعده
  // بالترتيب. دلوقتي بنفحص *كل* الصفوف النشطة ونختار أعلى باقة فعليًا حسب أولوية
  // واضحة (فندكس > ماقما > سنوي > يومي)، مش أحدث صف بترتيب الإضافة.
  const TIER_PRIORITY = ['fendex', 'magma', 'annual', 'lava', 'oms_vip', 'tycoon', 'franchise', 'reseller', 'oms_products', 'oms_services'];
  let bestTier = null;
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
    if (sheet && sheet.getLastRow() >= 2) {
      const finder = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1) // عمود Email بس
        .createTextFinder(email).matchEntireCell(true).matchCase(false);
      const matches = finder.findAll();
      const now = new Date();
      let bestPriority = Infinity;
      matches.forEach(m => {
        const rowVals = sheet.getRange(m.getRow(), 2, 1, 9).getValues()[0]; // B..J: Tier..EndDate
        const rowTier = rowVals[0], status = rowVals[3], endDate = rowVals[8];
        if (status === 'active' && new Date(endDate) > now) {
          const p = TIER_PRIORITY.indexOf(rowTier);
          const priority = p === -1 ? TIER_PRIORITY.length : p; // باقة مستقبلية مش معروفة تتحط آخر الأولوية
          if (priority < bestPriority) { bestPriority = priority; bestTier = rowTier; }
        }
      });
    }
  } catch(e) { Logger.log('getActiveSubscriberTier error: ' + e); }
  cache.put(cacheKey, bestTier || '', 300); // كاش 5 دقايق
  return bestTier;
}

// ✅ جديد: أرشفة الاشتراكات المنتهية/المرفوضة/المقفولة — تُشغّل دورياً (شهرياً مثلاً) عشان
// شيت Subscribers ما يتضخّمش للأبد مع نمو المشتركين لمئات الآلاف. الأرشيف يحتفظ بكل
// شيء لأغراض السجل، بس بيطلع بره الشيت "الحي" اللي بيتفحص في كل طلب.
// ✅ جديد: تنبيه موحّد لفشل أي تريجر — نفس النمط اللي كان موجود بالفعل في updateHistory
// وcheckMonthlySnapshot، استخرجته كدالة مشتركة عشان نطبّقه كمان على settleMaturedAPOrders
// وarchiveExpiredSubscribers اللي كانوا بيفشلوا بصمت تمامًا من غير أي تنبيه للأدمن.
function notifyAdminOfTriggerFailure(functionName, err) {
  Logger.log(functionName + ' فشلت: ' + err + (err && err.stack ? ('\n' + err.stack) : ''));
  try {
    sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - تنبيه: فشل ' + functionName,
      'التريجر (' + functionName + ') فشل ولم يكتمل تنفيذه.\n\n' +
      'السبب: ' + err + '\n\n' +
      'راجع سجل Executions في Apps Script (Extensions → Apps Script → Executions) لمعرفة التفاصيل الكاملة.');
  } catch(e) {}
}

// ✅ جديد: نسخة احتياطية حقيقية للشيت الرئيسي — version history بتاع Google مفيدة
// لكنها مش backup فعلي (لو حد مسح صف بالغلط ومر وقت، صعب ترجعها بثقة). هنا بننسخ
// الملف بالكامل لمجلد منفصل في Drive، بامتداد تاريخ/وقت، ونحتفظ بآخر 30 نسخة بس.
// ✅ جديد: يسجّل لقطة من قيم Properties الحساسة كصف جديد في PropertiesSnapshot —
// أهم قيمة فيها AP_EARNINGS (مش قابلة لإعادة البناء من أي مصدر تاني). بتتنادى من
// جوه backupMasterSheet نفسها قبل ما تاخد نسخة الـDrive، عشان النسخة تتضمّن آخر لقطة.
function snapshotCriticalProperties() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('PropertiesSnapshot');
  if (!sheet) return;
  sheet.appendRow([
    new Date(),
    props.getProperty('AP_EARNINGS') || '{}',
    props.getProperty('GROSS_ORDERS') || '0',
    props.getProperty('REDEMPTION_ORDERS') || '0',
    props.getProperty('BUSINESS_ORDER_COUNTS') || '{}',
    props.getProperty('LOCATION_COUNTS') || '{}',
    props.getProperty('LAST_COUNTS') || '{}',
    props.getProperty('AP_ACTIVITY') || '{}'
  ]);
  // ✅ تنظيف: آخر 30 لقطة بس (نفس مدة الاحتفاظ بنسخ backupMasterSheet بالظبط)
  const lastRow = sheet.getLastRow();
  if (lastRow > 31) sheet.deleteRows(2, lastRow - 31);
}

// ✅ جديد: دالة استرجاع طوارئ — تتشغّل يدويًا من محرر Apps Script بس لو Properties
// اتمسحت أو اتلخبطت فعليًا. بتاخد آخر لقطة مسجّلة وتعيد كتابتها في PropertiesService.
// ⚠️ متعمّد إنها يدوية (مش أوتوماتيك) — استرجاع Properties عملية حساسة، الأدمن لازم
// يتأكد بنفسه إن ده فعلاً اللي محتاجه قبل ما يستبدل أي قيم حالية.
function restoreLatestPropertiesSnapshot() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('PropertiesSnapshot');
  if (!sheet || sheet.getLastRow() < 2) return 'مفيش أي لقطة محفوظة للاسترجاع منها';
  const row = sheet.getRange(sheet.getLastRow(), 1, 1, 8).getValues()[0];
  props.setProperty('AP_EARNINGS', row[1] || '{}');
  props.setProperty('GROSS_ORDERS', row[2] || '0');
  props.setProperty('REDEMPTION_ORDERS', row[3] || '0');
  props.setProperty('BUSINESS_ORDER_COUNTS', row[4] || '{}');
  props.setProperty('LOCATION_COUNTS', row[5] || '{}');
  props.setProperty('LAST_COUNTS', row[6] || '{}');
  props.setProperty('AP_ACTIVITY', row[7] || '{}');
  return 'تم استرجاع آخر لقطة محفوظة بتاريخ: ' + row[0];
}

function backupMasterSheet() {
  try {
    snapshotCriticalProperties(); // ✅ جديد — لازم قبل makeCopy عشان النسخة تتضمّنها
    const file = DriveApp.getFileById(CONFIG.MASTER_SHEET_ID);
    const folders = DriveApp.getFoldersByName('LAVNDR120_Backups');
    const folder = folders.hasNext() ? folders.next() : DriveApp.createFolder('LAVNDR120_Backups');
    const stamp = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd_HHmm');
    file.makeCopy('LAVNDR120_Backup_' + stamp, folder);

    // ✅ تنظيف: احتفظ بآخر 30 نسخة بس (شهر تقريبًا لو يومية) عشان Drive ما يمتلئش للأبد
    const files = folder.getFiles();
    const all = [];
    while (files.hasNext()) all.push(files.next());
    all.sort((a,b) => b.getDateCreated() - a.getDateCreated());
    for (let i = 30; i < all.length; i++) all[i].setTrashed(true);
  } catch(err) {
    notifyAdminOfTriggerFailure('backupMasterSheet', err);
    throw err;
  }
}

// ✅ جديد: تريجر واحد بس لتفعيل backupMasterSheet على نظام شغّال بالفعل — نفس مبدأ
// الحماية اللي اتعلّمناه قبل كده: ما نعيدش تشغيل createHourlyTrigger() كامل عشان
// كده هيكرر التريجرز الأربعة الموجودين. شغّل الدالة دي مرة واحدة من محرر Apps Script.
function installBackupTrigger() {
  ScriptApp.newTrigger('backupMasterSheet').timeBased().everyDays(1).atHour(3).create();
  return 'تم تفعيل النسخ الاحتياطي اليومي — أول نسخة هتتاخد الساعة 3 صباحًا (بتوقيت ' + CONFIG.TIMEZONE + ')';
}


function archiveExpiredSubscribers() {
 try {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return {archived: 0};

  let archiveSheet = master.getSheetByName('SubscribersArchive');
  if (!archiveSheet) {
    archiveSheet = master.insertSheet('SubscribersArchive');
    archiveSheet.appendRow(sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0]);
  }

  const data = sheet.getDataRange().getValues();
  const now = new Date();
  const cutoff = new Date(now.getTime() - 30*24*3600000); // 30 يوم بعد الانتهاء
  const toArchive = [];
  const rowsToDelete = [];

  for (let i = data.length - 1; i >= 1; i--) {
    const status = data[i][4];
    const endDate = data[i][9] ? new Date(data[i][9]) : null;
    const isOldClosed = ['closed_rejected', 'closed_locked'].includes(status);
    const isOldExpired = status === 'active' && endDate && endDate < cutoff;
    if (isOldClosed || isOldExpired) {
      toArchive.push(data[i]);
      rowsToDelete.push(i + 1); // رقم الصف الفعلي بالشيت
    }
  }
  if (toArchive.length === 0) return {archived: 0};

  archiveSheet.getRange(archiveSheet.getLastRow()+1, 1, toArchive.length, toArchive[0].length)
    .setValues(toArchive.reverse());
  // نحذف من الأسفل للأعلى عشان ما تتزحزحش أرقام الصفوف أثناء الحذف
  rowsToDelete.sort((a,b) => b-a).forEach(r => sheet.deleteRow(r));

  return {archived: toArchive.length};
 } catch(err) {
   notifyAdminOfTriggerFailure('archiveExpiredSubscribers', err);
   throw err;
 }
}

// ✅ جديد: فحص حالة اشتراك المستخدم الحالية — بدون إرسال أي إيميل، للاستخدام في الواجهة فقط
// (تقرر الفرونت اند تعرض شاشة اختيار الباقة، أو شاشة OTP، أو "بانتظار المراجعة")
// ✅ معاد بناؤها للتوسّع: نفس فكرة isSubscriberActive — TextFinder بدل getDataRange() على شيت
// ممكن يوصل لمئات آلاف الصفوف. بيانات "حالة الاشتراك" هنا (awaiting_otp/awaiting_review) قصيرة
// العمر عادةً (ساعات لحد يوم)، فمش هنحطها في كاش طويل زي isSubscriberActive.
function getSubscriptionStatus(email, tierFilter, countryFilter) {
  // ✅ جديد: الإتاحة (متاح/مكتمل) بترجع مع كل رد بغض النظر عن المرحلة — شاشة اختيار
  // الباقة (stage='none') محتاجاها عشان تعطّل زرار أي باقة وصلت السقف من البداية
  // بدل ما تسيب المستخدم يجرب ويترفض بعد ما يدخل بياناته.
  const availability = getSubscriptionAvailability();
  const marketComplete = isMarketComplete(); // يحدد للواجهة: مسار ما قبل الاشتراك (واتساب) أم الاشتراك المباشر
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return { stage: 'none', availability: availability, marketComplete: marketComplete };
  const r = tierFilter ? findSubscriberRowForTier(sheet, email, tierFilter, countryFilter) : findLatestSubscriberRow(sheet, email);
  if (!r) return { stage: 'none', availability: availability, marketComplete: marketComplete };
  // فرانشايز مفعّل: شاشة التقدّم الرقمية (ما لم تكن هناك دفعة قيد التحقق/المراجعة فتظهر مرحلتها)
  if (r.status !== 'awaiting_otp' && r.status !== 'awaiting_review') {
    const fr = getFranchiseStatus(email);
    if (fr.hasFranchise) return { stage: 'franchise', tier: 'franchise', franchise: fr, availability: availability, marketComplete: marketComplete };
  }
  // ✅ جديد: قائمة الانتظار — السوق لسه في طور التكوين، بنوريه العدد الحالي/المستهدف
  // عشان الرسالة تكون صادقة وشفافة، مش بس "استنى" من غير سياق
  if (r.status === 'waitlisted') {
    return { stage: 'waitlisted', tier: r.tier, category: (tierInfo(r.tier) || {}).category || 'lavenders', country: r.country || '', readyCount: getReadyBusinessCount(), targetCount: CONFIG.BUSINESS_COUNT, availability: availability, marketComplete: marketComplete };
  }
  if (r.status === 'awaiting_otp')    return { stage: 'awaiting_otp', tier: r.tier, amount: r.amount, bank: CONFIG.BANK_DETAILS, availability: availability, marketComplete: marketComplete };
  if (r.status === 'awaiting_review') return { stage: 'awaiting_review', tier: r.tier, amount: r.amount, availability: availability, marketComplete: marketComplete };
  if (r.status === 'active' && new Date(r.endDate) > new Date()) {
    return { stage: 'active', tier: r.tier, endDate: r.endDate, availability: availability, marketComplete: marketComplete };
  }
  return { stage: 'none', availability: availability, marketComplete: marketComplete }; // مقفول (rejected/locked) أو منتهي — يقدر يبدأ طلب جديد
}

// ✅ جديد: كل اشتراكات المستخدم (آخر حالة لكل باقة/دولة) — تستخدمها الواجهة بعد الدخول:
// اشتراك واحد فقط ← تدخله مباشرة، أكثر من اشتراك ← نافذة اختيار. لا تُرجع إلا بيانات
// صاحب التوكن نفسه (الإيميل يؤخذ من التوكن لا من الطلب).
function getMySubscriptions(email) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return { items: [] };
  const matches = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1)
    .createTextFinder(email).matchEntireCell(true).matchCase(false).findAll();
  const latest = {};
  matches.forEach(m => {
    const v = sheet.getRange(m.getRow(), 1, 1, 12).getValues()[0];
    const info = tierInfo(v[1]);
    const key = v[1] + '|' + (info && info.perCountry ? normalizeCountry(v[11]) : '');
    latest[key] = v; // الصفوف مرتبة زمنياً فآخر واحد يغلب
  });
  const now = new Date();
  const items = [];
  Object.keys(latest).forEach(k => {
    const v = latest[k];
    const st = v[4];
    let stage = null;
    if (st === 'active') stage = (new Date(v[9]) > now) ? 'active' : null;
    else if (st === 'waitlisted' || st === 'awaiting_otp' || st === 'awaiting_review') stage = st;
    if (!stage) return; // مقفول/مرفوض/منتهي لا يظهر في القائمة
    items.push({
      tier: v[1], tierName: tierNameAr(v[1]), stage: stage,
      amount: v[3], endDate: stage === 'active' ? v[9] : '', country: String(v[11] || ''),
      category: (tierInfo(v[1]) || {}).category || ''
    });
  });
  const order = { active: 0, awaiting_review: 1, awaiting_otp: 2, waitlisted: 3 };
  items.sort((a, b) => order[a.stage] - order[b.stage]);
  return { items: items, activeCount: items.filter(i => i.stage === 'active').length };
}

// ✅ جديد: يحدد دور المستخدم — admin > participant (حصة حقيقية) > subscriber (اشتراك مطالعة) > visitor (سجّل دخول بس ما اشترك)
// مكاش لمدة دقيقتين — بدون ده، كل action (data/month/participant/market...) كان بيعيد
// فحص isEmailAuthorized وisSubscriberActive من الصفر، وهما أكتر حاجتين بتقرأن الشيتات.
function getUserRole(email) {
  if (!email) return 'visitor';
  const lower = email.toLowerCase();
  const cacheKey = 'ROLE_' + lower;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  let role = 'visitor';
  if (isAdminAuthorized(email)) role = 'admin';
  else if (isEmailAuthorized(email)) role = 'participant';
  else {
    // ✅ إصلاح: فندكس وماقما ليهم صلاحيات إضافية خاصة بيهم (تقرير الأوراكل، دليل
    // البزنسات) — مش مجرد "مشترك مطالعة عادي" زي لافا/السنوي. الدور بقى بيعكس
    // الباقة الفعلية النشطة بدل ما يوحّد كل الاشتراكات المدفوعة تحت اسم واحد.
    const activeTier = getActiveSubscriberTier(email);
    if (activeTier === 'fendex') role = 'fendex';
    else if (activeTier === 'magma') role = 'magma';
    else if (activeTier === 'lava' || activeTier === 'annual') role = 'subscriber';
    // ✅ سياق منفصل: أعضاء الحركة الاقتصادية (OMS/ريسيلر/فرانشايز/تايكون) — بدون أي بيانات سوق حقيقية
    else if (activeTier && tierInfo(activeTier) && (tierInfo(activeTier).category === 'movement' || tierInfo(activeTier).capacityGroup === 'oms')) role = 'movement';
  }

  cache.put(cacheKey, role, 120);
  return role;
}

// ✅ جديد: إبطال فوري لكاش الدور — يُستدعى بعد أي قرار أدمن يغيّر دور مستخدم (اعتماد
// اشتراك/دفعة)، عشان المستخدم يشوف التحديث فوراً بدل ما ينتظر انتهاء الكاش (دقيقتين/5 دقايق)
function invalidateRoleCache(email) {
  if (!email) return;
  const lower = email.toLowerCase();
  cache.remove('ROLE_' + lower);
  cache.remove('SUB_TIER_' + lower);
}

// ✅ جديد: قائمة اشتراكات بانتظار مراجعة الأدمن
function getAdminPendingSubscriptions() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [] };
  const data = sheet.getDataRange().getValues();
  const rows = [];
  for (let i = 1; i < data.length; i++) {
    // ✅ بانتظار المراجعة (دفع وأدخل رقم المعاملة) ← زر اعتماد؛ بانتظار الدفع (طلب التفاصيل ولم يكمل) ← عرض فقط
    if (data[i][4] !== 'awaiting_review' && data[i][4] !== 'awaiting_otp') continue;
    rows.push({
      row: i + 1, email: data[i][0], tier: data[i][1], amount: data[i][3],
      requestedAt: data[i][5], txnRef: data[i][6], submittedAt: data[i][7], country: data[i][11] || '',
      state: data[i][4] === 'awaiting_review' ? 'review' : 'awaiting_payment'
    });
  }
  rows.sort((a, b) => (a.state === 'review' ? 0 : 1) - (b.state === 'review' ? 0 : 1));
  return { rows: rows };
}

// ✅ جديد: قائمة الانتظار — مشتركين طلبوا الاشتراك قبل ما السوق يكتمل (أقل من
// 120 نشاط). الأدمن يقدر يشوف مين مستني وكام باقي، بدون أي إجراء يدوي مطلوب
// منه — التحويل لمرحلة الدفع بيحصل تلقائيًا (processSubscriptionWaitlistIfMarketReady)
// بمجرد ما آخر بزنس ينضاف.
function getAdminWaitlist() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [], readyCount: getReadyBusinessCount(), targetCount: CONFIG.BUSINESS_COUNT };
  const data = sheet.getDataRange().getValues();
  const rows = [];
  for (let i = 1; i < data.length; i++) {
    if (data[i][4] !== 'waitlisted') continue;
    rows.push({ email: data[i][0], tier: data[i][1], category: (tierInfo(data[i][1]) || {}).category || '', country: data[i][11] || '', requestedAt: data[i][5] });
  }
  return { rows: rows, readyCount: getReadyBusinessCount(), targetCount: CONFIG.BUSINESS_COUNT };
}


// ═══════════════ إشعارات الهاتف (Firebase Cloud Messaging) ═══════════════
// إشعارات فورية على هاتف المستخدم/الأدمن بنفس فكرة واتساب: اشتراك جديد بانتظار المراجعة،
// اعتماد/رفض اشتراك أو دفعة، اكتمال السوق لقائمة الانتظار.
// الإعداد (مرة واحدة): Firebase Console → Project settings → Service accounts → Generate new
// private key، ثم الصق محتوى ملف JSON كاملًا في Apps Script → Project Settings → Script
// properties باسم FCM_SERVICE_ACCOUNT. بدونه كل دوال الإرسال لا تفعل شيئًا (آمنة، لا تُفشل أي عملية).
function ensureDeviceTokensSheet() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  let sh = master.getSheetByName('DeviceTokens');
  if (!sh) { sh = master.insertSheet('DeviceTokens'); sh.appendRow(['Email', 'Token', 'UpdatedAt']); }
  return sh;
}
// تسجيل/تحديث توكن جهاز لإيميل (upsert بالتوكن نفسه، فلا يتكرر)
function registerDeviceToken(email, token) {
  const t = String(token || '').trim();
  if (!email || t.length < 20 || t.length > 4096) return { error: 'توكن غير صالح' };
  const lock = LockService.getScriptLock();
  let got = false; try { got = lock.tryLock(5000); } catch (e) {}
  if (!got) return { error: 'النظام مشغول، حاول بعد لحظات' };
  try {
    const sh = ensureDeviceTokensSheet();
    if (sh.getLastRow() >= 2) {
      const m = sh.getRange(2, 2, sh.getLastRow() - 1, 1).createTextFinder(t).matchEntireCell(true).findAll();
      if (m.length) {
        const r = m[0].getRow();
        sh.getRange(r, 1).setValue(email); sh.getRange(r, 3).setValue(new Date());
        return { status: 'registered' };
      }
    }
    sh.appendRow([email, t, new Date()]);
    return { status: 'registered' };
  } finally { lock.releaseLock(); }
}
function getFcmServiceAccount() {
  const raw = props.getProperty('FCM_SERVICE_ACCOUNT');
  if (!raw) return null;
  try { const sa = JSON.parse(raw); return (sa.client_email && sa.private_key && sa.project_id) ? sa : null; }
  catch (e) { return null; }
}
function getFcmAccessToken(sa) {
  const cached = cache.get('FCM_ACCESS_TOKEN');
  if (cached) return cached;
  const now = Math.floor(Date.now() / 1000);
  const header = Utilities.base64EncodeWebSafe(JSON.stringify({ alg: 'RS256', typ: 'JWT' })).replace(/=+$/, '');
  const claim = Utilities.base64EncodeWebSafe(JSON.stringify({
    iss: sa.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600
  })).replace(/=+$/, '');
  const sig = Utilities.base64EncodeWebSafe(Utilities.computeRsaSha256Signature(header + '.' + claim, sa.private_key)).replace(/=+$/, '');
  const res = UrlFetchApp.fetch('https://oauth2.googleapis.com/token', {
    method: 'post', muteHttpExceptions: true,
    payload: { grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: header + '.' + claim + '.' + sig }
  });
  if (res.getResponseCode() !== 200) throw new Error('FCM token error ' + res.getResponseCode());
  const tok = JSON.parse(res.getContentText()).access_token;
  cache.put('FCM_ACCESS_TOKEN', tok, 3000);
  return tok;
}
// رسالة بيانات فقط (data) لتمرّ دائمًا عبر خدمة التطبيق (قناة/صوت LAVNDR) حتى والتطبيق مغلق
function sendPushToToken(sa, accessToken, deviceToken, title, body, type) {
  const res = UrlFetchApp.fetch('https://fcm.googleapis.com/v1/projects/' + sa.project_id + '/messages:send', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { Authorization: 'Bearer ' + accessToken },
    payload: JSON.stringify({ message: { token: deviceToken, data: { title: String(title), body: String(body), type: String(type || 'market_update') }, android: { priority: 'HIGH' } } })
  });
  return res.getResponseCode();
}
function removeDeviceToken(deviceToken) {
  try {
    const sh = ensureDeviceTokensSheet();
    if (sh.getLastRow() < 2) return;
    const m = sh.getRange(2, 2, sh.getLastRow() - 1, 1).createTextFinder(deviceToken).matchEntireCell(true).findAll();
    if (m.length) sh.deleteRow(m[0].getRow());
  } catch (e) {}
}
// يرسل لكل أجهزة إيميل معيّن. لا يرمي أخطاء أبدًا (الإشعار إضافة، لا يوقف العملية الأساسية).
function pushToEmail(email, title, body, type) {
  try {
    const sa = getFcmServiceAccount();
    if (!sa || !email) return { sent: 0, reason: 'not_configured' };
    const sh = ensureDeviceTokensSheet();
    if (sh.getLastRow() < 2) return { sent: 0 };
    const rows = sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues();
    const tokens = rows.filter(r => String(r[0]).toLowerCase() === String(email).toLowerCase()).map(r => String(r[1]));
    if (!tokens.length) return { sent: 0 };
    const at = getFcmAccessToken(sa);
    let sent = 0;
    tokens.forEach(tk => {
      const code = sendPushToToken(sa, at, tk, title, body, type);
      if (code === 200) sent++;
      else if (code === 404 || code === 400) removeDeviceToken(tk); // توكن منتهٍ/غير مسجّل
    });
    return { sent: sent };
  } catch (e) { Logger.log('pushToEmail فشل: ' + e); return { sent: 0, error: String(e) }; }
}
function pushToAdmins(title, body, type) {
  const emails = CONFIG.ADMIN_PANEL_EMAILS || [];
  emails.forEach(e => pushToEmail(e, title, body, type || 'payment_confirmation'));
}

// ═══════════════ الفرانشايز: الدفع التدريجي ═══════════════
// الإجمالي 2709$ = 120 مقعد × 22.58$. يبدأ بحجز 90$ (≈4 مقاعد)، ثم دفعات من نفس
// مسار الدفع (رمز + مرجع تحويل + مراجعة أدمن). الواجهة للعضو أرقام + زر "ادفع" فقط.
// "عدد البزنسات المضافة" معلومة يُدخلها الأدمن فقط (لا تظهر لغير الأدمن).
function ensureFranchiseSheet(master) {
  master = master || SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  let sh = master.getSheetByName('FranchiseProgress');
  if (!sh) {
    sh = master.insertSheet('FranchiseProgress');
    sh.appendRow(['Email','TotalUSD','PaidUSD','RemainingUSD','SeatsPaid','BusinessesAdded','Status','CreatedAt','UpdatedAt']);
  }
  return sh;
}
function findFranchiseRow(sh, email) {
  if (sh.getLastRow() < 2) return 0;
  const m = sh.getRange(2, 1, sh.getLastRow() - 1, 1).createTextFinder(email).matchEntireCell(true).matchCase(false).findAll();
  return m.length ? m[m.length - 1].getRow() : 0;
}
function seatsForPaid(paid) {
  return Math.min(CONFIG.FRANCHISE_TOTAL_SEATS, Math.max(0, Math.round(paid / CONFIG.FRANCHISE_PER_SEAT_USD)));
}
// يُسجّل مبلغاً مدفوعاً (معتمداً من الأدمن) على رصيد الفرانشايز — يُنشئ السجل لو أول دفعة
function applyFranchisePayment(email, amount) {
  const sh = ensureFranchiseSheet();
  const now = new Date();
  const total = CONFIG.FRANCHISE_TOTAL_USD;
  let row = findFranchiseRow(sh, email);
  if (!row) {
    const paid = Math.min(total, amount);
    sh.appendRow([email, total, paid, total - paid, seatsForPaid(paid), 0, paid >= total ? 'completed' : 'in_progress', now, now]);
    row = sh.getLastRow();
  } else {
    const cur = parseFloat(sh.getRange(row, 3).getValue()) || 0;
    const paid = Math.min(total, parseFloat((cur + amount).toFixed(2)));
    sh.getRange(row, 3, 1, 5).setValues([[paid, parseFloat((total - paid).toFixed(2)), seatsForPaid(paid), sh.getRange(row, 6).getValue() || 0, paid >= total ? 'completed' : 'in_progress']]);
    sh.getRange(row, 9).setValue(now);
  }
  const vals = sh.getRange(row, 1, 1, 9).getValues()[0];
  logAudit('system', 'franchise_payment_applied', {email: email, amount: amount, paid: vals[2], remaining: vals[3]});
  invalidateRoleCache(email);
  return { paid: vals[2], remaining: vals[3], seatsPaid: vals[4], status: vals[6] };
}
// ما يراه العضو: أرقام الدفع فقط (بدون عدد البزنسات المضافة — خاص بالأدمن)
function getFranchiseStatus(email) {
  const sh = ensureFranchiseSheet();
  const row = findFranchiseRow(sh, email);
  if (!row) return { hasFranchise: false };
  const v = sh.getRange(row, 1, 1, 9).getValues()[0];
  const nextAmount = Math.min(parseFloat(v[3]) || 0, CONFIG.FRANCHISE_RESERVATION_USD);
  const latest = findLatestSubscriberRow(SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers'), email);
  const pendingStage = (latest && latest.tier === 'franchise_installment' && (latest.status === 'awaiting_otp' || latest.status === 'awaiting_review')) ? latest.status : null;
  return {
    hasFranchise: true, totalUsd: v[1], paidUsd: v[2], remainingUsd: v[3], seatsPaid: v[4],
    totalSeats: CONFIG.FRANCHISE_TOTAL_SEATS, status: v[6], nextAmountUsd: nextAmount, pendingStage: pendingStage
  };
}
// زر "ادفع" الوحيد: يفتح الدفعة التالية بنفس مسار الرمز/المرجع/المراجعة
function payFranchiseInstallment(email) {
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return {error: 'النظام مشغول، حاول تاني بعد لحظات'};
  try {
    const st = getFranchiseStatus(email);
    if (!st.hasFranchise) return {error: 'لا توجد عضوية فرانشايز مفعّلة لهذا الحساب'};
    if (st.status === 'completed' || st.remainingUsd <= 0) return {status: 'completed'};
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
    const latest = findLatestSubscriberRow(sheet, email);
    if (latest && latest.tier === 'franchise_installment') {
      if (latest.status === 'awaiting_review') return {status: 'pending_subscription', stage: 'awaiting_review', tier: latest.tier, amount: latest.amount};
      if (latest.status === 'awaiting_otp' && (new Date() - new Date(latest.requestedAt)) / 3600000 <= CONFIG.OTP_EXPIRY_HOURS) {
        const m = buildSubscriptionOTPEmail(email, latest.otp, latest.tier, latest.amount);
        if (!sendTransactionalEmail(m.to, m.subject, m.body).success) return {error: 'تعذّر إرسال رمز التحقق حالياً. حاول لاحقاً.'};
        return {status: 'pending_subscription', stage: 'awaiting_otp', tier: latest.tier, amount: latest.amount};
      }
    }
    const amount = st.nextAmountUsd;
    const otp = generateOTP();
    const mail = buildSubscriptionOTPEmail(email, otp, 'franchise_installment', amount);
    if (!sendTransactionalEmail(mail.to, mail.subject, mail.body).success) {
      return {error: 'تعذّر إرسال رمز التحقق حالياً (خدمة الإيميل وصلت حدها). حاول تاني بعد شوية أو تواصل مع الأدمن.'};
    }
    sheet.appendRow([email, 'franchise_installment', otp, amount, 'awaiting_otp', new Date(), '', '', '', '', 0, '']);
    return {status: 'pending_subscription', stage: 'awaiting_otp', tier: 'franchise_installment', amount: amount};
  } finally {
    lock.releaseLock();
  }
}
// للأدمن: كل الفرانشايز (المدفوع، المتبقي، عدد البزنسات المضافة)
function getAdminFranchises() {
  const sh = ensureFranchiseSheet();
  if (sh.getLastRow() < 2) return { rows: [], maxFranchise: CONFIG.MAX_FRANCHISE_MEMBERS };
  const data = sh.getRange(2, 1, sh.getLastRow() - 1, 9).getValues();
  return {
    maxFranchise: CONFIG.MAX_FRANCHISE_MEMBERS,
    rows: data.map(v => ({ email: v[0], totalUsd: v[1], paidUsd: v[2], remainingUsd: v[3], seatsPaid: v[4], businessesAdded: v[5], status: v[6], createdAt: v[7], updatedAt: v[8] }))
  };
}
function setFranchiseBusinessesAdded(email, count, adminEmail) {
  const n = parseInt(count, 10);
  if (isNaN(n) || n < 0 || n > CONFIG.FRANCHISE_TOTAL_SEATS) return {error: 'عدد غير صالح (0–' + CONFIG.FRANCHISE_TOTAL_SEATS + ')'};
  const sh = ensureFranchiseSheet();
  const row = findFranchiseRow(sh, email);
  if (!row) return {error: 'لا يوجد سجل فرانشايز لهذا الإيميل'};
  sh.getRange(row, 6).setValue(n);
  sh.getRange(row, 9).setValue(new Date());
  logAudit(adminEmail || 'admin', 'franchise_businesses_set', {email: email, count: n});
  return {status: 'done', businessesAdded: n};
}

// ═══════════════ OMS VIP: مقعد مشارك فعلي ═══════════════
// VIP = قيمة التطبيق (429$) + مقعد دخول لسوق التداول الداخلي (513$). عند اعتماد الأدمن
// للاشتراك يُنشأ صف مشارك فعلي (نفس صيغة معالجة الدفعات المعتمدة)، وإن تعذّر يُنبَّه الأدمن لإضافته يدوياً.
// يضيف الإيميل إلى قائمة الـ120 (AllowedEmails) إن لم يكن موجوداً — يصبح دوره participant
function addToAllowedEmails(email, note) {
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('AllowedEmails');
    if (!sheet) return {added: false, reason: 'no_sheet'};
    const lower = String(email).toLowerCase();
    if (getAllowedEmailsFromSheet().indexOf(lower) !== -1) { invalidateRoleCache(email); return {added: false, reason: 'exists'}; }
    sheet.appendRow([email, note || '']);
    cache.remove('lavndr_allowed_emails');
    invalidateRoleCache(email);
    logAudit('system', 'allowed_email_added', {email: email, note: note || ''});
    return {added: true};
  } catch (err) {
    notifyAdminOfTriggerFailure('addToAllowedEmails(' + email + ') — أضفه يدوياً لشيت AllowedEmails', err);
    return {added: false, error: String(err)};
  }
}

function grantParticipantSeatForOmsVip(email) {
  try {
    const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
    const partSheet = master.getSheetByName('Participants');
    if (partSheet.getLastRow() >= 2) {
      const m = partSheet.getRange(2, 1, partSheet.getLastRow() - 1, 1).createTextFinder(email).matchEntireCell(true).matchCase(false).findAll();
      if (m.length > 0) { invalidateRoleCache(email); return {granted: false, reason: 'already_participant'}; }
    }
    const liveData = getData();
    const currentNAV = parseFloat(liveData.index.NAV);
    const alloc = JSON.stringify(calcAllocation(liveData.weights));
    const seat = CONFIG.OMS_VIP_SEAT_VALUE_USD;
    partSheet.appendRow([email, 'active', currentNAV, new Date(), seat, seat, 0, alloc]);
    invalidateRoleCache(email);
    logAudit('system', 'oms_vip_seat_granted', {email: email, seatValue: seat});
    return {granted: true};
  } catch (err) {
    notifyAdminOfTriggerFailure('grantParticipantSeatForOmsVip(' + email + ') — أضف المقعد يدوياً', err);
    return {granted: false, error: String(err)};
  }
}

// ✅ جديد: قرار الأدمن على اشتراك — approve يفعّل الاشتراك فوراً بمدته الصحيحة (24 ساعة/365 يوم)
function decideAdminSubscription(rowNum, decision, adminEmail) {
  if (!['approved', 'rejected'].includes(decision)) return { error: 'قرار غير صالح' };
  // ✅ جديد: نفس مبدأ decideAdminPayment — قفل دفاعي يمنع معالجة نفس الطلب مرتين
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return { error: 'الخادم مشغول حالياً — حاول تاني بعد لحظة' };
  try {
    const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
    const sheet = master.getSheetByName('Subscribers');
    const row = parseInt(rowNum);
    if (!row || row < 2 || row > sheet.getLastRow()) return { error: 'صف غير موجود' };
    const currentStatus = sheet.getRange(row, 5).getValue();
    if (currentStatus !== 'awaiting_review') {
      return { error: 'هذا الطلب اتقرر فيه بالفعل (' + currentStatus + ')' };
    }
    const subscriberEmail = sheet.getRange(row, 1).getValue();
    if (decision === 'rejected') {
      sheet.getRange(row, 5).setValue('closed_rejected');
      logAudit(adminEmail || 'unknown_admin', 'admin_decided_subscription', {row: row, decision: 'rejected', subscriberEmail: subscriberEmail});
      pushToEmail(subscriberEmail, 'لم يتم تأكيد التحويل', 'تعذّر تأكيد تحويلك. تواصل معنا لو تعتقد أن هناك خطأ.', 'payment_confirmation');
      return { status: 'done', decision: 'rejected' };
    }
    const tier = sheet.getRange(row, 2).getValue();
    // ✅ جديد: إعادة فحص السقف هنا هو خط الدفاع الحاسم فعليًا — ممكن يكون فيه كذا
    // طلب "بانتظار المراجعة" اتسجّل قبل ما الباقة توصل السقف، والأدمن بيعتمدهم
    // واحد واحد بعدين. من غير الفحص هنا، اعتماد كل الطلبات دي كانت تتجاوز السقف
    // فعليًا حتى لو subscribeLava رفضت أي طلب *جديد* بعد الوصول للسقف. استخدام
    // getEffectiveTierMax هنا (مش الرقم الخام) مهم للافا عشان يحسب حجز ڤندكس صح.
    const isInstallment = tier === 'franchise_installment';
    const maxForTier = getEffectiveTierMax(tier);
    const activeNow = activeCountForCapacityCheck(tier);
    if (!isInstallment && activeNow >= maxForTier) {
      return { error: 'باقة ' + tierNameAr(tier) + ' وصلت العدد الأقصى للمشتركين النشطين (' + maxForTier.toLocaleString('en-US') + ') — لازم ترفض الطلب ده أو تستنى مكان يفضى' };
    }
    if (tierInfo(tier) && tierInfo(tier).perCountry) {
      const c = sheet.getRange(row, 12).getValue();
      if (findAnyTycoonRequestForCountry(c, subscriberEmail) === 'active') {
        return { error: 'تايكون هذه الدولة (' + c + ') مفعّل بالفعل لعضو آخر — ارفض هذا الطلب' };
      }
    }
    if (isInstallment) {
      // دفعة تقسيط فرانشايز: تُسجَّل على رصيد العضو ويُقفل الصف (لا يصير اشتراكاً نشطاً مستقلاً)
      const paidAmount = parseFloat(sheet.getRange(row, 4).getValue()) || 0;
      const res = applyFranchisePayment(subscriberEmail, paidAmount);
      if (res.error) return res;
      sheet.getRange(row, 5).setValue('closed_applied');
      pushToEmail(subscriberEmail, 'تم تأكيد دفعتك ✅', 'تم تسجيل دفعتك على امتياز الفرانشايز. تابع التقدّم من التطبيق.', 'payment_confirmation');
      logAudit(adminEmail || 'unknown_admin', 'admin_decided_subscription', {row: row, decision: 'approved', subscriberEmail: subscriberEmail, tier: tier, amount: paidAmount});
      return { status: 'done', decision: 'approved', franchise: res };
    }
    const now = new Date();
    const end = new Date(now.getTime() + tierDurationMs(tier));
    sheet.getRange(row, 5).setValue('active');
    sheet.getRange(row, 9).setValue(now);
    sheet.getRange(row, 10).setValue(end);
    cache.remove('ACTIVE_SUB_COUNTS_ALL'); // ✅ لازم يتحدّث فورًا مش يستنى الـ60 ثانية
    invalidateRoleCache(subscriberEmail); // ✅ يشوف الداشبورد فوراً بدل ما ينتظر انتهاء الكاش
    logAudit(adminEmail || 'unknown_admin', 'admin_decided_subscription', {row: row, decision: 'approved', subscriberEmail: subscriberEmail, tier: tier});
    // أثر جانبي حسب الباقة: فرانشايز يفتح سجل تقدّم الدفع، OMS VIP يمنح مقعد مشارك فعلي
    if (tierInfo(tier) && tierInfo(tier).progressive) {
      applyFranchisePayment(subscriberEmail, parseFloat(sheet.getRange(row, 4).getValue()) || CONFIG.FRANCHISE_RESERVATION_USD);
    }
    if (tierInfo(tier) && tierInfo(tier).capacityGroup === 'oms') {
      addToAllowedEmails(subscriberEmail, 'OMS: ' + tier); // يدخل قائمة الـ120 ← يُوجَّه للسوق الداخلي
    }
    if (tierInfo(tier) && tierInfo(tier).grantsParticipantSeat) {
      grantParticipantSeatForOmsVip(subscriberEmail);
    }
    pushToEmail(subscriberEmail, 'تم تفعيل اشتراكك ✅', 'اشتراكك في ' + tierNameAr(tier) + ' مفعّل الآن.', 'payment_confirmation');
    return { status: 'done', decision: 'approved', endDate: end };
  } finally {
    lock.releaseLock();
  }
}


function processApprovedPayments() {
  // ✅ جديد: قفل — هذي الدالة تتشغّل من التريجر الساعي (updateHistory) وكمان مباشرة
  // لحظة ما الأدمن يعتمد/يرفض دفعة (decideAdminPayment). بدون قفل، لو الاتنين
  // صادف اشتغلوا بنفس اللحظة بالظبط، ممكن الاتنين يقروا نفس الصف بحالة 'approved'
  // قبل ما أي واحد يكتب 'closed_approved'، فيتسجّل نفس المشارك مرتين وتتضاعف
  // الإيميلات وسجل توزيع الأرباح (Distributions).
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return; // تنفيذ تاني شغال بالفعل — نسيبه يكمل، هيتنادى تاني بالتريجر أو بالضغطة الجاية

  try {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('PendingPayments');
  if (!sheet || sheet.getLastRow() < 2) return;
  const data = sheet.getDataRange().getValues();
  const marketSheet = master.getSheetByName('Market');
  const partSheet = master.getSheetByName('Participants');
  let touched = false;

  for (let i = 1; i < data.length; i++) {
    const status = data[i][5];

    // ✅ جديد: تنظيف طلبات اتنسيت — ما دخل otp أبداً وعدّت مهلة الصلاحية.
    // بدون هذا، أي حجز حصة سوق مرتبط بطلب متروك كان يفضل "pending" للأبد ولا يرجع يُباع.
    if (status === 'awaiting_otp') {
      const requestedAt = new Date(data[i][6]);
      const hoursElapsed = (new Date() - requestedAt) / 3600000;
      if (hoursElapsed > CONFIG.OTP_EXPIRY_HOURS) {
        const marketRow = parseInt(data[i][4]) || 0;
        if (marketRow > 0) marketSheet.getRange(marketRow, 4).setValue('available');
        sheet.getRange(i+1, 6).setValue('closed_expired');
        touched = true;
      }
      continue;
    }

    if (status !== 'approved' && status !== 'rejected') continue;
    touched = true;
    const email = data[i][0];
    const amount = parseFloat(data[i][2]);
    const sellerEmail = data[i][3];
    const marketRow = parseInt(data[i][4]) || 0;

    if (status === 'rejected') {
      if (marketRow > 0) marketSheet.getRange(marketRow, 4).setValue('available'); // ترجع متاحة بالسوق
      try {
        sendTransactionalEmail(email, CONFIG.INDEX_TICKER + ' - لم يتم تأكيد الدفعة',
          'للأسف ما قدرنا نأكد دفعتك بقيمة $' + amount + '. لو تعتقد إنه في خطأ، تواصل معنا مباشرة.');
      } catch(e) {}
      sheet.getRange(i+1, 6).setValue('closed_rejected');
      pushToEmail(email, 'لم يتم تأكيد الدفعة', 'تعذّر تأكيد دفعتك بقيمة $' + amount + '.', 'payment_confirmation');
      logAudit(email, 'payment_rejected', {amount: amount, marketRow: marketRow || null});
      continue;
    }

    // approved
    const liveData = getData();
    const currentNAV = parseFloat(liveData.index.NAV);
    const alloc = JSON.stringify(calcAllocation(liveData.weights));
    partSheet.appendRow([email, 'active', currentNAV, new Date(), amount, amount, 0, alloc]);
    pushToEmail(email, 'تم تأكيد عمليتك ✅', 'تم تأكيد دفعتك بقيمة $' + amount + ' وإيداع حصتك.', 'payment_confirmation');
    invalidateRoleCache(email); // ✅ يشوف السوق الداخلي فوراً بدل ما ينتظر انتهاء الكاش
    if (marketRow > 0) {
      marketSheet.getRange(marketRow, 4).setValue('sold');
      marketSheet.getRange(marketRow, 5).setValue(email);
      marketSheet.getRange(marketRow, 6).setValue(new Date());
      // ✅ إصلاح إضافي: صف البائع الأصلي كان يبقى 'selling' للأبد حتى بعد بيع حصته فعلاً،
      // فيستمر updateParticipantValues يحدّث قيمة حصة ما عادت له — نقفله هنا نهائياً كـ 'sold'.
      const partData = partSheet.getDataRange().getValues();
      for (let j = 1; j < partData.length; j++) {
        if (partData[j][0] === sellerEmail && partData[j][1] === 'selling') {
          partSheet.getRange(j+1, 2).setValue('sold');
          break;
        }
      }
      // ✅ إصلاح جوهري: لحظة البيع/الشراء في السوق الداخلي هي لحظة توجيه فلوس
      // للبزنسات (مش الشراء المباشر من الصندوق كما كان الكود القديم يفترض خطأً) —
      // القيمة المتداولة هنا فعلياً بتتحرك بين مستخدمين، والنظام يسجّل استحقاق
      // كل بزنس منها حسب وزنه وقت العملية.
      recordBusinessDistribution(amount, email);
    }
    // ✅ ملاحظة: شراء مباشر من الصندوق (marketRow===0) هو دخول رأس مال جديد للصندوق
    // نفسه — مش توزيع منه، فمفيش استحقاق بزنسات يُسجَّل هنا.
    try {
      sendTransactionalEmail(email, CONFIG.INDEX_TICKER + ' - تم تأكيد حصتك 🎉',
        'أهلاً بك في ' + CONFIG.INDEX_TICKER + '!\nتم تأكيد دفعتك بقيمة $' + amount +
              '\nNAV عند الدخول: $' + currentNAV.toFixed(2) +
              '\nافتح الداشبورد الآن للاطلاع على حصتك والتداول بالسوق الداخلي.');
      if (sellerEmail) {
        sendTransactionalEmail(sellerEmail, CONFIG.INDEX_TICKER + ' - تم تأكيد بيع حصتك',
          'تم تأكيد بيع حصتك بقيمة $' + amount + ' بعد مراجعة الدفعة.');
      }
    } catch(e) {}
    sheet.getRange(i+1, 6).setValue('closed_approved');
    logAudit(email, marketRow > 0 ? 'market_purchase_approved' : 'fund_purchase_approved',
      {amount: amount, sellerEmail: sellerEmail || null, navAtEntry: currentNAV});
  }
  if (touched) cache.remove('lavndr_data');
  } finally {
    lock.releaseLock();
  }
}

// ─────────────────────────────────────────────
// ✅ جديد: طبقة إرسال إيميل قابلة للتوسع
// ─────────────────────────────────────────────
// المشكلة اللي بتحلها: MailApp.sendEmail() (المستخدمة في كل الكود القديم) محدودة بـ100
// إيميل/يوم لحساب Gmail عادي (1500 لو Google Workspace) — سقف مستحيل يكفي 120,000 مستخدم.
// وأخطر من كده، الكود القديم كان بيعمل try{...}catch(e){} حوالين كل MailApp.sendEmail،
// يعني لو فشل الإرسال (حصة خلصت)، المستخدم كان يشوف "تم الإرسال" بينما ما وصلهوش أي إيميل،
// يقعد مستني، وفي الآخر يجرب يخمّن OTP عشوائي ويوصل لقفل المحاولات بلا داعي.
//
// الحل: دالة واحدة بديلة لكل استخدامات MailApp.sendEmail. لو أضفت مفتاح Resend
// (Script Properties → RESEND_API_KEY)، بترسل عن طريقه (بدون أي سقف يومي عملياً).
// لو ما أضفتوش، بتفضل تستخدم MailApp زي الأول بالظبط، لكن بتتحقق من الحصة المتبقية
// الأول وترجع خطأ واضح بدل الفشل الصامت.
function sendTransactionalEmail(to, subject, body) {
  const resendKey = props.getProperty('RESEND_API_KEY');
  if (resendKey) {
    try {
      const res = UrlFetchApp.fetch('https://api.resend.com/emails', {
        method: 'post',
        contentType: 'application/json',
        headers: { Authorization: 'Bearer ' + resendKey },
        payload: JSON.stringify({ from: CONFIG.EMAIL_FROM, to: [to], subject: subject, text: body }),
        muteHttpExceptions: true
      });
      const code = res.getResponseCode();
      if (code >= 200 && code < 300) return { success: true };
      Logger.log('Resend error ' + code + ': ' + res.getContentText());
      return { success: false, reason: 'resend_error' };
    } catch (e) {
      Logger.log('Resend exception: ' + e);
      return { success: false, reason: 'resend_exception' };
    }
  }
  // Fallback: MailApp — نتحقق من الحصة المتبقية الأول بدل ما نحاول ونفشل بصمت
  try {
    if (MailApp.getRemainingDailyQuota() <= 0) {
      return { success: false, reason: 'quota_exceeded' };
    }
    MailApp.sendEmail({ to: to, subject: subject, body: body });
    return { success: true };
  } catch (e) {
    Logger.log('MailApp exception: ' + e);
    return { success: false, reason: 'mailapp_exception' };
  }
}

function generateOTP() {
  // ✅ إصلاح: Math.random() مش CSPRNG (مصدر عشوائية ضعيف نظرياً قابل للتنبؤ لو
  // اتجمعت عينات كافية). Utilities.getUuid() تستخدم مصدر عشوائية أقوى بكثير —
  // نشتق منه رقم الـ6 خانات بدل الاعتماد المباشر على Math.random().
  const hex = Utilities.getUuid().replace(/-/g, '').substring(0, 8);
  const num = parseInt(hex, 16);
  return String(100000 + (num % 900000)); // رمز من 6 أرقام
}

// ✅ جديد: تحقق من شكل رقم/مرجع المعاملة البنكية قبل تخزينه.
// ⚠️ ثغرة حرجة كانت موجودة: txnRef نص حر يكتبه أي مستخدم مصادَق عليه (حتى قبل ما
// يبقى مشارك فعلي)، يتخزن كما هو، وبعدين يُعرض داخل admin.html عبر innerHTML بدون
// أي تهريب (escaping). يعني أي حد يقدر يدخل مثلاً <img src=x onerror="..."> كـ"رقم
// معاملة" وينفّذ جافاسكربت في متصفح الأدمن لحظة ما يفتح لوحة المراجعة — قادر يسرق
// توكن جلسة الأدمن (sessionStorage) أو يعتمد دفعات مزوّرة تلقائياً باسمه.
// الإصلاح على طبقتين: هنا نرفض أي رمز فيه رموز HTML خطرة من الأساس (مراجع البنوك
// الحقيقية أرقام/حروف/شرطات/سلاش فقط)، وبرضو admin.html بقى يهرّب (escape) أي نص
// معروض عبر innerHTML كطبقة حماية ثانية مستقلة.
function isValidTxnRef(txnRef) {
  const s = String(txnRef).trim();
  if (!s || s.length > 80) return false;
  return /^[\p{L}\p{N}\s\-_\/.#]+$/u.test(s);
}


function buildOTPEmail(email, otp, amount) {
  const b = CONFIG.BANK_DETAILS;
  // ✅ التسعير بالدولار فقط دائماً — نفس مبدأ buildSubscriptionOTPEmail بالضبط.
  const sdgLine = '\nملاحظة: قيمة حصتك بالمنصة بالدولار الأمريكي فقط، لكن التحويل البنكي الفعلي بالجنيه السوداني (' + b.CURRENCY + ') — حوّل ما يعادل هذا المبلغ حسب سعر الصرف السائد يوم التحويل.';
  return {
    to: email,
    subject: CONFIG.INDEX_TICKER + ' - تفاصيل الدفع ورمز التحقق',
    body:
      'لإتمام شراء حصتك بقيمة $' + amount + sdgLine + '\n\n' +
      'حوّل المبلغ إلى:\n' +
      'البنك: ' + b.BANK_NAME + '\n' +
      'اسم صاحب الحساب: ' + b.ACCOUNT_HOLDER + '\n' +
      'رقم الحساب: ' + b.ACCOUNT_NUMBER + '\n' +
      'IBAN: ' + b.IBAN + '\n' +
      'الفرع: ' + b.BRANCH + '\n' +
      'العملة: ' + b.CURRENCY + '\n\n' +
      'بعد التحويل، ارجع للداشبورد وأدخل:\n' +
      '1) رمز التحقق: ' + otp + '\n' +
      '2) رقم/مرجع المعاملة من إشعار البنك\n\n' +
      'صلاحية الرمز: ' + CONFIG.OTP_EXPIRY_HOURS + ' ساعة. طلبك بيتراجع يدوياً وبيتفعّل تلقائياً خلال ساعة من إرسال رقم المعاملة.'
  };
}

// ✅ جديد: يفحص إذا كان فيه طلب دفع مفتوح لإيميل معيّن (تستخدمها الواجهة لعرض شاشة OTP بدل زر الشراء)
function getPendingPaymentStatus(email) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('PendingPayments');
  if (sheet.getLastRow() < 2) return null;
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === email && (data[i][5] === 'awaiting_otp' || data[i][5] === 'awaiting_review')) {
      return {pending: true, stage: data[i][5], amount: data[i][2]};
    }
  }
  return null;
}

// ─────────────────────────────────────────────
// AP Orders — إنشاء/استرداد وحدات بالجملة (Creation/Redemption Units)
// ─────────────────────────────────────────────
function processAPOrder(apCode, type, units) {
  // ✅ جديد: قفل دفاعي — كانت props (عدادات AP_ACTIVITY وAP_UNITS_CREATED/REDEEMED)
  // تُقرا وتُكتب بنمط read-then-write بدون قفل؛ طلبين متزامنين (تابين مفتوحين لنفس
  // حساب AP، أو ضغطة مزدوجة) ممكن يضيّعوا تحديث عداد. تأثيرها محدود (أرقام عرض بس،
  // منفصلة تماماً عن حساب NAV الأساسي) لكن بنوحّد النمط مع باقي الدوال الحساسة.
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return {error: 'النظام مشغول، حاول تاني بعد لحظات'};

  try {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const apSheet = master.getSheetByName('AP_Orders');
  const settlementDate = getSettlementDate();

  // سلة/كاش-إن-ليو مقابل وحدة إنشاء واحدة، بناءً على التوزيع الحالي الحقيقي للطلبات لكل بزنس
  const basketData = generateBasketFile(getBusinessCountsArray());
  const cashInLieuPerUnit = basketData.cashComponent;
  const totalCashInLieu = parseFloat((cashInLieuPerUnit * units).toFixed(2));

  // تسجيل الطلب بحالة "Pending" لحين تاريخ التسوية (T+2 عمل)
  apSheet.appendRow([new Date(), apCode, type, units, totalCashInLieu, settlementDate, 'Pending']);

  // عداد نشاط الـ AP التراكمي (يظهر في getData → authorizedParticipants)
  const apActivity = JSON.parse(props.getProperty('AP_ACTIVITY') || '{}');
  apActivity[apCode] = (apActivity[apCode] || 0) + units;
  props.setProperty('AP_ACTIVITY', JSON.stringify(apActivity));

  // عداد الوحدات المُصدرة/المستردة عبر الـ AP (منفصل عن أوردرات الأعمال الحقيقية)
  const key = type === 'CREATE' ? 'AP_UNITS_CREATED' : 'AP_UNITS_REDEEMED';
  const current = parseInt(props.getProperty(key) || '0');
  props.setProperty(key, (current + units).toString());

  cache.remove('lavndr_data');

  return {
    status: 'ap_order_logged',
    apCode: apCode,
    type: type,
    units: units,
    cashInLieu: totalCashInLieu,
    settlementDate: settlementDate,
    settlementCycle: 'T+' + CONFIG.SETTLEMENT_DAYS,
    ordersRepresented: units * CONFIG.ORDERS_PER_UNIT
  };
  } finally {
    lock.releaseLock();
  }
}

// تُستدعى يومياً (عبر trigger): تحوّل أي طلب AP "Pending" وصل تاريخ تسويته إلى "Settled"
function settleMaturedAPOrders() {
 try {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('AP_Orders');
  if (!sheet || sheet.getLastRow() < 2) return;
  const data = sheet.getDataRange().getValues();
  const today = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd');
  for (let i = 1; i < data.length; i++) {
    const status = data[i][6];
    const settlementDate = data[i][5];
    if (!settlementDate) continue;
    // ✅ إصلاح بگ مؤكد: settlementDate بترجع من الشيت كـ Date object حقيقي (مش نص) لأنها
    // اتخزنت كذلك أصلاً. مقارنة Date object بنص مباشرة بـ<= كانت بتحوّل الـ Date لصيغة
    // نصية غريبة ("Thu Aug 20 2026...") وتقارنها أبجديًا بـ"2026-08-24" — بتدّي نتيجة
    // غلط تقريبًا دايمًا. النتيجة: طلبات AP كانت تفضل "Pending" للأبد ومفيش تسوية بتحصل.
    // الحل: نحوّل settlementDate لنفس صيغة النص قبل المقارنة، بغض النظر عن نوعها الأصلي.
    const settlementStr = settlementDate instanceof Date
      ? Utilities.formatDate(settlementDate, CONFIG.TIMEZONE, 'yyyy-MM-dd')
      : String(settlementDate);
    if (status === 'Pending' && settlementStr <= today) {
      sheet.getRange(i + 1, 7).setValue('Settled');
    }
  }
 } catch(err) {
   notifyAdminOfTriggerFailure('settleMaturedAPOrders', err);
   throw err;
 }
}

// بيع حصة — يُعرض في السوق لمشارك آخر
function sellShare(email) {
  // ✅ جديد: التداول بالسوق الداخلي مقفول لحد ما كل بزنس من الـ120 يوصل 100 طلب على الأقل
  const stage = getTradingStage();
  if (stage < 1) {
    const minOrders = getMinBusinessOrders();
    return {error: 'التداول بالسوق الداخلي لسا مقفول — أبطأ بزنس وصل ' + minOrders + '/100 طلب المطلوبة لفتح التداول'};
  }

  // ✅ جديد: قفل — يمنع ضغطتين سريعتين (أو تبويبين مفتوحين) يعرضوا نفس الحصة مرتين بالسوق
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return {error: 'النظام مشغول، حاول تاني بعد لحظات'};

  try {
    const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
    const sheet = master.getSheetByName('Participants');
    const data = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === email && data[i][1] === 'active') {
        const currentValue = parseFloat(data[i][5]);
        sheet.getRange(i+1,2).setValue('selling');
        const marketSheet = master.getSheetByName('Market');
        marketSheet.appendRow([email, currentValue, new Date(), 'available', '', '']);
        cache.remove('lavndr_data');
        logAudit(email, 'share_listed_for_sale', {shareValue: currentValue});

        try {
          sendTransactionalEmail(email, CONFIG.INDEX_TICKER + ' - حصتك معروضة للبيع',
            'تم عرض حصتك بقيمة $' + currentValue + ' في السوق الداخلي. سنرسل لك إيميل فور بيعها.');
        } catch(e) {}

        return {status:'listed', shareValue: currentValue};
      }
    }
    return {error: 'المشارك غير موجود أو غير نشط'};
  } finally {
    lock.releaseLock();
  }
}

// تحديث قيم جميع المشاركين مع تغير NAV
function updateParticipantValues(currentNAV) {
  if (currentNAV <= 0) return;
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Participants');
  if (sheet.getLastRow() < 2) return;
  const data = sheet.getDataRange().getValues();
  const liveData = getData();
  const alloc = JSON.stringify(calcAllocation(liveData.weights));

  for (let i = 1; i < data.length; i++) {
    if (data[i][1] !== 'active' && data[i][1] !== 'selling') continue;
    const entryNAV = parseFloat(data[i][2]);
    const sharePrice = parseFloat(data[i][4]);
    if (entryNAV <= 0) continue;
    // نسبة الملكية = sharePrice / entryNAV
    const ownership = sharePrice / entryNAV;
    // القيمة الحالية = ownership × currentNAV
    const currentValue = parseFloat((ownership * currentNAV).toFixed(2));
    const pnl = parseFloat((currentValue - sharePrice).toFixed(2));
    sheet.getRange(i+1,6).setValue(currentValue);
    sheet.getRange(i+1,7).setValue(pnl);
    sheet.getRange(i+1,8).setValue(alloc);
  }
}

// بيانات مشارك واحد
function getParticipantInfo(email) {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Participants');
  if (sheet.getLastRow() < 2) return null;
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === email) {
      const alloc = JSON.parse(data[i][7] || '{}');
      return {
        email: data[i][0],
        status: data[i][1],
        entryNAV: parseFloat(data[i][2]).toFixed(2),
        entryDate: data[i][3],
        sharePrice: parseFloat(data[i][4]).toFixed(2),
        currentValue: parseFloat(data[i][5]).toFixed(2),
        pnl: parseFloat(data[i][6]).toFixed(2),
        pnlPercent: data[i][4] > 0? ((data[i][6]/data[i][4])*100).toFixed(2) : '0.00',
        allocation: alloc
      };
    }
  }
  return null;
}

// السوق الداخلي — الحصص المعروضة للبيع
function getMarket() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Market');
  if (sheet.getLastRow() < 2) return [];
  return sheet.getDataRange().getValues()
    .map((r, i) => ({r, row: i + 1}))
    .filter(x => x.r[3] === 'available')
    // ✅ جديد: نرجّع رقم الصف عشان الفرونت اند يقدر يحدد "هذه الحصة بالذات" عند الشراء
    // (شوف buyShare — قبل كده كل زر شراء بشاشة السوق كان يستدعي شراء عام بيرجّع أول
    // حصة متاحة بترتيب الشيت، مش بالضرورة الحصة اللي المستخدم ضغط عليها فعلياً).
    .map(x => ({seller: x.r[0], shareValue: x.r[1], listDate: x.r[2], row: x.row}));
}

// ─────────────────────────────────────────────
// Ticker & Basket
// ─────────────────────────────────────────────
// ✅ إصلاح: تيكر 6 حروف + 3 أرقام (كان 4+2)، ومفتاحه sheetId مو الاسم — عشان اسمين متشابهين لبزنسين مختلفين ما يتصادموا
function getTicker(sheetId, name) {
  let ticker = props.getProperty('TICKER_' + sheetId);
  if (!ticker) {
    const clean = String(name||sheetId).replace(/[^ء-يa-zA-Z0-9]/g,'').substring(0,6).toUpperCase();
    const padded = (clean + 'XXXXXX').substring(0,6);
    ticker = padded + Math.floor(Math.random()*900+100);
    props.setProperty('TICKER_' + sheetId, ticker);
  }
  return ticker;
}

function generateBasketFile(businessCounts) {
  // businessCounts: [{sheetId, name, count}, ...] من getBusinessCountsArray()
  const total = businessCounts.reduce((s,b) => s+b.count, 0);
  if (total === 0) return {basket:{},cashComponent:0};
  const basket = {};
  let cashComponent = 0;
  businessCounts.forEach(b => {
    const exactShares = (b.count/total)*CONFIG.ORDERS_PER_UNIT;
    const shares = Math.floor(exactShares);
    const remainder = exactShares - shares;
    if (shares > 0) basket[getTicker(b.sheetId, b.name)] = shares;
    cashComponent += remainder * CONFIG.ORDER_VALUE;
  });
  return {basket, cashComponent:parseFloat(cashComponent.toFixed(2))};
}

// ✅ إصلاح: عطلة السودان جمعة(5) وسبت(6)
function getSettlementDate() {
  const now = new Date();
  let settlement = new Date(now);
  let daysAdded = 0;
  while (daysAdded < CONFIG.SETTLEMENT_DAYS) {
    settlement.setDate(settlement.getDate()+1);
    const day = settlement.getDay();
    if (day !== 5 && day !== 6) daysAdded++;
  }
  return Utilities.formatDate(settlement, CONFIG.TIMEZONE, 'yyyy-MM-dd');
}

// ✅ إصلاح: capWeights تتكرر حتى لا يوجد تجاوز
// ✅ جديد: وزن كل بزنس لحاله (مبني على businessOrderCounts المفتاحه sheetId — مو أسماء المنتجات
// اللي ممكن تتكرر بين بزنسين وتخلط بياناتهم). هذا الأساس الصحيح لأي توزيع فلوس حقيقي على بزنس معين.
function getBusinessWeights() {
  const businessCounts = getBusinessCountsArray();
  const total = businessCounts.reduce((s,b) => s + b.count, 0);
  let weights = businessCounts.map(b => ({
    sheetId: b.sheetId,
    name: b.name,
    orders: b.count,
    weight: total > 0 ? (b.count/total*100) : 0
  }));
  return capWeights(weights);
}

// ✅ جديد: بعد اعتماد دفعة مباشرة من الصندوق (مو إعادة بيع بين مشاركين)، نسجل استحقاق كل بزنس
// من هذا المبلغ تحديداً حسب وزنه وقت الدفعة. التحويل الفعلي يدوي خارج النظام حسب تأكيدك،
// وهذا السجل هو "القيمة اللي النظام يعتمدها" لكل بزنس.
// ✅ إصلاح: أضفنا Orders (عدد طلبات البزنس وقت الاستحقاق ده تحديداً) — أساس حساب
// ضمان الـ36% لاحقاً بدقة، مربوط بنفس الاستحقاق مش برقم إجمالي متغيّر مع الوقت.
// وحالة البداية بقت 'available' (بدل 'pending') لتتماشى مع تسلسل الحالات الجديد:
// available (متاح للاستلام) → accepted_awaiting_guarantee (البزنس قبل، مستني ضمان)
// → completed (الأدمن أكّد استلام الضمان، الاستحقاق خلص).
function recordBusinessDistribution(amount, participantEmail) {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Distributions');
  if (!sheet) return;
  const bWeights = getBusinessWeights();
  const now = new Date();
  bWeights.forEach(w => {
    if (w.weight <= 0) return;
    const entitlement = (amount * w.weight/100);
    if (entitlement <= 0) return;
    // ✅ جديد: لو البزنس مفعّل عنده "قبول تلقائي"، الاستحقاق يتسجل مباشرة كـ
    // "قابل ومستني ضمان" (وكأنه ضغط قبول فورًا) بدل ما يفضل "متاح" وينتظر ضغطة
    // يدوية من الأدمن — بيوفر خطوة كاملة لكل بزنس اختار الوضع التلقائي.
    const autoAccept = isAutoAcceptEnabled(w.sheetId);
    const status = autoAccept ? 'accepted_awaiting_guarantee' : 'available';
    const guaranteeStatus = autoAccept ? 'awaiting_guarantee' : '';
    sheet.appendRow([now, participantEmail, w.sheetId, w.name, w.weight.toFixed(2), entitlement.toFixed(2), status, '', w.orders || 0, guaranteeStatus]);
    if (autoAccept) {
      logAudit('system_auto', 'entitlement_auto_accepted', {sheetId: w.sheetId, business: w.name, entitlement: entitlement.toFixed(2)});
    }
  });
}

// ✅ جديد: بيعيد بناء ملخص "مستحق/بانتظار ضمان/مكتمل" لكل بزنس من صفر كل ساعة —
// أبسط وأضمن من تحديث تراكمي جزئي. حدّثنا الحالات لتتماشى مع تسلسل الضمان الجديد
// (available/accepted_awaiting_guarantee/completed بدل pending/sent القديمة).
function updateDistributionSummary() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const distSheet = master.getSheetByName('Distributions');
  const sumSheet = master.getSheetByName('DistributionsSummary');
  if (!distSheet || !sumSheet || distSheet.getLastRow() < 2) return;
  const rows = distSheet.getDataRange().getValues().slice(1);
  const totals = {};
  rows.forEach(r => {
    const sheetId = r[2], name = r[3], entitlement = parseFloat(r[5])||0, status = r[6];
    if (!sheetId) return;
    if (!totals[sheetId]) totals[sheetId] = {name: name, available: 0, awaitingGuarantee: 0, completed: 0};
    if (status === 'completed') totals[sheetId].completed += entitlement;
    else if (status === 'accepted_awaiting_guarantee') totals[sheetId].awaitingGuarantee += entitlement;
    else if (status === 'available') totals[sheetId].available += entitlement;
  });
  sumSheet.clearContents();
  sumSheet.appendRow(['BusinessSheetID','BusinessName','TotalAvailable','TotalAwaitingGuarantee','TotalCompleted']);
  Object.entries(totals).forEach(([id, t]) => {
    sumSheet.appendRow([id, t.name, t.available.toFixed(2), t.awaitingGuarantee.toFixed(2), t.completed.toFixed(2)]);
  });
}
function capWeights(weights) {
  const capPct = CONFIG.MAX_COMPONENT_WEIGHT*100;
  // ✅ إصلاح: لو عدد المكونات النشطة قليل جداً (زي بداية الإطلاق، قبل ما معظم الـ120
  // بزنس ياخدوا طلبات) يكون رياضياً مستحيل نطبّق السقف ونوصل مجموع 100% سوا — مثلاً
  // مكون واحد بس نشط = وزنه الحقيقي 100%، والسقف 20%. الكود القديم كان يحاول يوزّع
  // الفائض على مكونات "غير مسقّفة بعد" فاضية، فالفائض يختفي بصمت والمجموع يبقى أقل
  // من 100% — يظهر غلط في تفصيل تخصيص كل مشارك ($513 ما بيتوزّعش كامل). لو مستحيل
  // رياضياً نطبّق السقف الآن، نرجّع الأوزان الحقيقية بدون سقف مؤقتاً بدل ما نضيّع فلوس.
  if (weights.length * capPct < 100) return weights;

  let changed = true;
  let guard = 0; // ✅ حارس دفاعي إضافي ضد أي حلقة لا نهائية نظرية
  while (changed && guard < weights.length + 5) {
    guard++;
    changed = false;
    let excess = 0;
    weights.forEach(w => {
      if (parseFloat(w.weight) > capPct) {
        excess += parseFloat(w.weight) - capPct;
        w.weight = capPct;
        changed = true;
      }
    });
    if (excess > 0) {
      const remaining = weights.filter(w => parseFloat(w.weight) < capPct);
      if (remaining.length > 0) {
        const perItem = excess/remaining.length;
        remaining.forEach(w => w.weight = parseFloat(w.weight)+perItem);
      }
    }
  }
  return weights;
}

function readSheetWithTimeout(sheetId) {
  const startTime = Date.now();
  try {
    const lastRow = parseInt(props.getProperty('ROW_'+sheetId)||'1');
    const ss = SpreadsheetApp.openById(sheetId);
    if (Date.now()-startTime > CONFIG.SHEET_TIMEOUT_MS) return null;
    let sheet = ss.getSheetByName('Orders');
    // ✅ ذاتي الإصلاح: لو تاب Orders ناقص (مثلاً شيت انضاف لـ BusinessSheets بعد آخر initializeSystem)
    // ينبني تلقائياً هنا، فما فيه اعتماد على ترتيب تشغيل initializeSystem بعد لصق الـ120 شيت.
    if (!sheet) {
      sheet = ss.insertSheet('Orders');
      sheet.appendRow(['Timestamp','Product','Qty','Price','Total','Customer','Type','AP_Code','Location']);
      return {data:[], lastRow:1};
    }
    if (Date.now()-startTime > CONFIG.SHEET_TIMEOUT_MS) return null;
    const lastSheetRow = sheet.getLastRow();
    if (lastSheetRow <= lastRow) return {data:[],lastRow:lastRow};
    if (Date.now()-startTime > CONFIG.SHEET_TIMEOUT_MS) return null;
    const data = sheet.getRange(lastRow+1,1,lastSheetRow-lastRow,9).getValues();
    return {data:data,lastRow:lastSheetRow};
  } catch(e) { return null; }
}

// ─────────────────────────────────────────────
// getData — القلب
// ─────────────────────────────────────────────
// ✅ جديد: أقل عدد طلبات وصل له بزنس (الأبطأ من الـ120) — مقياس نضج الفهرس ككل
function getMinBusinessOrders() {
  const counts = JSON.parse(props.getProperty('BUSINESS_ORDER_COUNTS')||'{}');
  const ids = getBusinessSheetIds();
  if (ids.length === 0) return 0;
  return Math.min(...ids.map(id => counts[id] || 0));
}

// ✅ جديد: مرحلة فتح التداول — الشرط: كل بزنس من الـ120 لازم يوصل الرقم لحاله (مو المجموع)
// 0 = مقفول تماماً، 1 = فُتح عند 100/بزنس، 2 = عند 500/بزنس، 3 = عند 1000/بزنس (السقف النهائي)
function getTradingStage() {
  const minOrders = getMinBusinessOrders();
  if (minOrders >= CONFIG.MAX_ORDERS_PER_BUSINESS) return 3;
  if (minOrders >= 500) return 2;
  if (minOrders >= 100) return 1;
  return 0;
}

// ─────────────────────────────────────────────
// ✅ فصل جوهري (تحسين فعالية) — "الـ Agent" المسؤول عن تحليل داتا الطلبات فقط
// ─────────────────────────────────────────────
// السبب: كل الأنشطة الحساسة (شراء/بيع/عرض بورتال البزنس/عرض الداشبورد) كانت بتمرّ
// عبر getData()، واللي كانت بتفتح وتقرأ الـ120 شيت في كل مرة الكاش ينتهي (كل 5 دقايق)
// — بغض النظر إن كان اللي طلب البيانات محتاج فعلاً رقم لحظي أو لا. ده كان بيبطّئ أي
// عملية شراء/بيع لو صادف وقتها انتهاء الكاش، وبيرفع خطر "النظام مشغول" (قفل getData).
//
// الحل: هذه الدالة (analyzeBusinessOrders) هي الوحيدة اللي بتفتح الـ120 شيت وتقرأها —
// بتشتغل مرة واحدة بالساعة من تريجر منفصل (راجع createHourlyTrigger)، مش من أي طلب حي.
// نتيجة تحليلها (productCount, locationCount, businessOrderCounts, gross/redemption
// orders, apActivity) بتتخزن في PropertiesService بالظبط زي قبل — getData() تحت بقت
// تقرأ منها فقط (Properties + شيتات صغيرة زي History/Participants)، من غير ما تفتح
// أي شيت بزنس إطلاقاً. النظام (getData) يعرض النتائج كما هي زي الأول بالضبط —
// الفرق الوحيد هو *امتى* بيتحسب التحليل، مش *شكل* البيانات النهائية.
function analyzeBusinessOrders() {
  // ✅ نفس القفل اللي كان في getData بالظبط — يمنع تشغيلتين متزامنتين (مثلاً لو حد
  // شغّل الدالة يدويًا من المحرر في نفس لحظة التريجر) يعدّوا نفس الطلبات مرتين.
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) {
    Logger.log('analyzeBusinessOrders: تشغيلة تانية شغالة بالفعل — تخطينا هذه المرة');
    return;
  }

  try {
    // ✅ إصلاح: كل الأرقام تراكمية من props
    const productCount = JSON.parse(props.getProperty('LAST_COUNTS')||'{}');
    let grossOrders = parseInt(props.getProperty('GROSS_ORDERS')||'0');
    let redemptionOrders = parseInt(props.getProperty('REDEMPTION_ORDERS')||'0');
    const apActivity = JSON.parse(props.getProperty('AP_ACTIVITY')||'{}');
    // ✅ إصلاح جوهري: الموقع الجغرافي دلوقتي بييجي من عمود "Location" في شيت الطلبات
    // نفسه (عمود 9، جنب Product/Type/...)، يعني موقع كل طلب لوحده — مش حقل واحد ثابت
    // بيحدده الأدمن لكل بزنس (اللي كان غلط، اتشال بالكامل). بيتجمّع بنفس أسلوب
    // productCount بالظبط (تراكمي، ينزل مع REDEEM زي ما يزيد مع BUY).
    const locationCount = JSON.parse(props.getProperty('LOCATION_COUNTS')||'{}');
    // ✅ جديد: عداد طلبات لكل بزنس لحاله (مو بس لكل منتج) — أساس شرط فتح التداول التدريجي
    const businessOrderCounts = JSON.parse(props.getProperty('BUSINESS_ORDER_COUNTS')||'{}');
    // ✅ إصلاح جوهري: البُعد الزمني كان بيتحسب من "الفرق بين تشغيلتين للتريجر" (غلط لو
    // بزنس اتأخر في المزامنة، كل الطلبات المتأخرة كانت هتتحسب في يوم واحد بدل تاريخها
    // الحقيقي). دلوقتي كل صف بيتبوّب بتاريخه الحقيقي من عمود Timestamp نفسه (row[0])
    // مباشرة، بغض النظر عن إمتى النظام قرأه فعليًا.
    const netOrdersByDate = {}; // {'yyyy-MM-dd': netChange} — بيزيد مع شراء وينقص مع استرداد
    const newProductsByDate = {};    // {'yyyy-MM-dd': {product: count}} — BUY بس، لأكثر منتج/يوم

    const pendingRowMarks = {}; // ROW_<sheetId> تُحفظ بعد نجاح حفظ الأعداد فقط (راجع الأسفل)
    getBusinessSheetIds().forEach(sheetId => {
      const result = readSheetWithTimeout(sheetId);
      if (!result) return;
      const {data,lastRow} = result;
      if (data.length > 0) {
        data.forEach(row => {
          const item = row[1];
          const type = row[6]||'BUY';
          const ap = row[7]||'AP001';
          // ✅ جديد: الموقع من عمود Location نفسه (row[8]) — لو فاضي (صفوف قديمة قبل
          // إضافة العمود، أو بزنس لسه ما عبّاش الخلية)، يترصّ تحت "غير محدد" بدل ما يختفي.
          const location = row[8] ? String(row[8]).trim() : '';
          const locKey = location || 'غير محدد';
          // ✅ جديد: تاريخ الطلب الحقيقي من عمود Timestamp (row[0])، مش وقت المعالجة
          let orderDate;
          try { orderDate = Utilities.formatDate(new Date(row[0]), CONFIG.TIMEZONE, 'yyyy-MM-dd'); }
          catch(e) { orderDate = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd'); }
          if (item) {
            if (type === 'REDEEM') {
              redemptionOrders++;
              productCount[item] = Math.max(0,(productCount[item]||0)-1);
              locationCount[locKey] = Math.max(0,(locationCount[locKey]||0)-1); // ✅ جديد
              netOrdersByDate[orderDate] = (netOrdersByDate[orderDate]||0)-1;
            } else {
              productCount[item] = (productCount[item]||0)+1;
              locationCount[locKey] = (locationCount[locKey]||0)+1; // ✅ جديد
              grossOrders++;
              businessOrderCounts[sheetId] = (businessOrderCounts[sheetId]||0)+1; // ✅ جديد
              netOrdersByDate[orderDate] = (netOrdersByDate[orderDate]||0)+1;
              // ✅ جديد: أي منتج اتطلب في أي تاريخ — أساس "أكثر منتج" في تلميح شارت الاتجاه اليومي
              newProductsByDate[orderDate] = newProductsByDate[orderDate] || {};
              newProductsByDate[orderDate][item] = (newProductsByDate[orderDate][item]||0)+1;
            }
            apActivity[ap] = (apActivity[ap]||0)+1;
          }
        });
        pendingRowMarks[sheetId] = lastRow;
      }
    });
    // ✅ جديد: يحفظ الأعداد المبوّبة بتاريخها الحقيقي في شيت DailyOrderStats (upsert
    // — لو التاريخ موجود يزوّد عليه، لو جديد يضيف صف). آمنة حتى لو batch واحد فيه
    // تواريخ متعددة (backlog من بزنس اتأخر في المزامنة).
    recordDailyOrderCounts(netOrdersByDate, newProductsByDate);

    // ✅ إصلاح: حفظ كل الأرقام التراكمية — دي "نتيجة التحليل" اللي getData() هتقراها بس
    props.setProperty('LAST_COUNTS', JSON.stringify(productCount));
    props.setProperty('GROSS_ORDERS', grossOrders.toString());
    props.setProperty('REDEMPTION_ORDERS', redemptionOrders.toString());
    props.setProperty('AP_ACTIVITY', JSON.stringify(apActivity));
    props.setProperty('BUSINESS_ORDER_COUNTS', JSON.stringify(businessOrderCounts)); // ✅ جديد
    props.setProperty('LOCATION_COUNTS', JSON.stringify(locationCount)); // ✅ جديد
    // ✅ إصلاح سلامة بيانات: مؤشر آخر صف مقروء لكل بزنس بيتحفظ *بعد* حفظ الأعداد، مش قبله.
    // قبل كده لو التشغيلة انقطعت (حد 6 دقايق) أو فشل الحفظ بعد قراءة بعض الشيتات، كانت
    // المؤشرات تتقدّم والأعداد تضيع = نقص دائم في عدّ الطلبات.
    Object.keys(pendingRowMarks).forEach(id => props.setProperty('ROW_' + id, pendingRowMarks[id]));

    // ✅ جديد: بعد تحديث الأرقام الخام، لازم نُبطل كاش getData() القديم — وإلا الطلبات
    // الحية (buy/sell/دخول الداشبورد) هتفضل تشوف رقم قديم لحد ما الكاش القديم ينتهي
    // من نفسه (لغاية 5 دقايق تأخير إضافي بلا داعي، رغم إن الأرقام الجديدة جاهزة فعلاً).
    cache.remove('lavndr_data');

    Logger.log('analyzeBusinessOrders: تم بنجاح — إجمالي طلبات صافية: ' + (grossOrders - redemptionOrders));
  } catch(err) {
    notifyAdminOfTriggerFailure('analyzeBusinessOrders', err);
    throw err;
  } finally {
    if (gotLock) lock.releaseLock();
  }
}

function getData() {
  const cached = cache.get('lavndr_data');
  if (cached) return JSON.parse(cached);

  // ✅ إصلاح جوهري (بعد فصل analyzeBusinessOrders): getData() ما بتفتحش أي شيت بزنس
  // خالص بقى — القفل هنا بقى وقائي بس (يمنع تكرار بناء نفس الـ result JSON لو طلبين
  // وصلوا بنفس اللحظة والكاش لسه ما اتحطش)، مش حماية ضد قراءة props متزامنة تسبب عدّ
  // مزدوج للطلبات زي قبل (ده بقى مسؤولية القفل الموجود جوه analyzeBusinessOrders نفسها).
  // مهلة القفل هنا صغيرة (3 ثواني) لأن العملية دلوقتي خفيفة جداً (Properties + شيتات
  // صغيرة زي History/Participants) وما محتاجاش الـ10 ثواني القديمة اللي كانت مخصصة
  // أساساً لقراءة الـ120 شيت.
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try {
    gotLock = lock.tryLock(3000);
  } catch(e) {}
  if (!gotLock) {
    Utilities.sleep(500);
    const retryCache = cache.get('lavndr_data');
    if (retryCache) return JSON.parse(retryCache);
    // ما لقيناش كاش وما قدرناش ناخد القفل — نكمل من غير قفل بدل ما نرمي خطأ للمستخدم
    // على عملية بقت خفيفة أصلاً (بعكس قبل الفصل، لما كانت تفتح 120 شيت فعليًا).
  }

  try {
    // ✅ إصلاح جوهري: كل الأرقام دي بقت "نتيجة تحليل جاهزة" من analyzeBusinessOrders()
    // (بتتحدث كل ساعة من تريجرها الخاص) — هنا بس بنقراها، من غير ما نفتح أي شيت بزنس.
    const productCount = JSON.parse(props.getProperty('LAST_COUNTS')||'{}');
    let grossOrders = parseInt(props.getProperty('GROSS_ORDERS')||'0');
    let redemptionOrders = parseInt(props.getProperty('REDEMPTION_ORDERS')||'0');
    const apActivity = JSON.parse(props.getProperty('AP_ACTIVITY')||'{}');

  // ✅ إصلاح: NAV من totalOrders الحقيقي (صافي بعد الاسترداد — ما اتغيرش)
  const totalOrders = Object.values(productCount).reduce((a,b) => a+b, 0);
  const netOrders = grossOrders - redemptionOrders;
  const NAV = totalOrders * CONFIG.ORDER_VALUE;

  // ✅ إصلاح: من هنا فصاعداً كل شي مبني على هوية البزنس (sheetId) مو اسم المنتج —
  // عشان بزنسين مختلفين ما يتلخبطوا لو استخدموا نفس اسم المنتج بشيتاتهم
  const businessCounts = getBusinessCountsArray();
  const totalBusinessOrders = businessCounts.reduce((s,b) => s+b.count, 0);
  const basketData = generateBasketFile(businessCounts);
  const netUnits = Math.floor(totalOrders/CONFIG.ORDERS_PER_UNIT);
  const IIV = (netUnits*CONFIG.ORDERS_PER_UNIT*CONFIG.ORDER_VALUE)+basketData.cashComponent;
  const premium = NAV > 0? ((IIV-NAV)/NAV*100) : 0;

  let weights = businessCounts.filter(b => b.count > 0).map(b => ({
    sheetId:b.sheetId, name:b.name, ticker:getTicker(b.sheetId, b.name), count:b.count,
    weight: totalBusinessOrders > 0? (b.count/totalBusinessOrders*100) : 0,
    value: (b.count*CONFIG.ORDER_VALUE).toFixed(2)
  }));
  weights = capWeights(weights);

  // ✅ إصلاح جوهري: الموقع الجغرافي دلوقتي بيتحسب من LOCATION_COUNTS التراكمي (نتيجة
  // تحليل analyzeBusinessOrders الجاهزة)، مش حقل ثابت يحدده الأدمن لكل بزنس. نفس
  // أسلوب topProducts بالظبط.
  const locationCountFresh = JSON.parse(props.getProperty('LOCATION_COUNTS')||'{}');
  const ordersByLocation = Object.entries(locationCountFresh)
    .filter(([,count]) => count > 0)
    .sort((a,b) => b[1]-a[1])
    .map(([location,count]) => ({ location: location, count: count }));

  // ✅ إصلاح: History لا تُكتب هنا
  const historySheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('History');
  const now = new Date();
  const lastRow = historySheet.getLastRow();
  if (lastRow < 2) {
    // لا يوجد بيانات بعد — أضف صف أولي
    historySheet.appendRow([now, 0, 0, 0, 0, 0, 0, 0]);
  }
  const lastRows = historySheet.getRange(Math.max(2,historySheet.getLastRow()-29),1,Math.min(30,Math.max(1,historySheet.getLastRow()-1)),3).getValues();
  const values = lastRows.map(r => r[1]);
  const returns = [];
  for (let i=1;i<values.length;i++) {
    if (values[i-1]>0) returns.push((values[i]-values[i-1])/values[i-1]);
  }
  const avg = returns.reduce((a,b)=>a+b,0)/returns.length||0;
  const variance = returns.reduce((a,b)=>a+Math.pow(b-avg,2),0)/returns.length||0;
  const volatility = Math.sqrt(variance*252)*100;

  const today = Utilities.formatDate(now,CONFIG.TIMEZONE,'yyyy-MM-dd');
  const todayValues = lastRows.filter(r=>Utilities.formatDate(new Date(r[0]),CONFIG.TIMEZONE,'yyyy-MM-dd')===today).map(r=>r[1]);
  const dayHigh = todayValues.length? Math.max(...todayValues) : NAV;
  const dayLow = todayValues.length? Math.min(...todayValues) : NAV;
  const prevNAV = lastRows.length>1? lastRows[lastRows.length-2][1] : NAV;
  const change = NAV-prevNAV;
  const changePercent = prevNAV>0? (change/prevNAV*100) : 0;

  // ✅ جديد: إحصاء المشاركين
  const participantsSheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Participants');
  const participantsCount = participantsSheet.getLastRow()-1;
  const activeCount = participantsSheet.getLastRow()>1?
    participantsSheet.getDataRange().getValues().slice(1).filter(r=>r[1]==='active').length : 0;
  const poolValue = parseFloat((participantsCount * CONFIG.SHARE_PRICE).toFixed(2));
  const marketList = getMarket();

  const result = {
    mode:'live',
    indexTicker:CONFIG.INDEX_TICKER,
    timestamp:Utilities.formatDate(now,CONFIG.TIMEZONE,"yyyy-MM-dd'T'HH:mm:ss"),
    settlementDate:getSettlementDate(),
    settlementCycle:'T+'+CONFIG.SETTLEMENT_DAYS,
    maxCapacityOrders:CONFIG.BUSINESS_COUNT*CONFIG.MAX_ORDERS_PER_BUSINESS,
    maxCapacityValue:(CONFIG.BUSINESS_COUNT*CONFIG.MAX_ORDERS_PER_BUSINESS*CONFIG.ORDER_VALUE).toFixed(2),
    maxCapacityUnits:(CONFIG.BUSINESS_COUNT*CONFIG.MAX_ORDERS_PER_BUSINESS)/CONFIG.ORDERS_PER_UNIT,
    cashInLieu:basketData.cashComponent,
    trending:weights.slice(0,10).map(w=>[w.ticker,w.count]),
    weights:weights.slice(0,CONFIG.MAX_TABLE_ROWS),
    // ✅ جديد: تفصيل المنتجات الأكثر طلبًا — البيانات كانت محسوبة أصلاً (productCount)
    // من قراءة كل الطلبات الجديدة في كل الشيتات، لكن ما كانتش بترجع للفرونت اند خالص.
    // ⚠️ الاسم مبني على عمود "Product" في شيت الطلبات، مش على sheetId — يعني لو بزنسين
    // استخدموا نفس اسم المنتج بالظبط، هيتجمعوا في نفس الشريط هنا (بعكس "weights" اللي
    // مفصولة بالـsheetId). كافي لنظرة عامة على المنتجات الرائجة، مش لتحديد بزنس بعينه.
    topProducts: Object.entries(productCount)
      .sort((a,b) => b[1]-a[1]).slice(0,15)
      .map(([name,count]) => ({name:name, count:count})),
    // ✅ جديد: اتجاه الطلبات اليومي (آخر 30 يوم) — من DailyOrderStats، البُعد الزمني
    // اللي كان مفقود من كل تحليل الطلبات قبل كده (كان في NAV إجمالي بس، بدون تفصيل).
    dailyOrderTrend: getDailyOrderTrend(30),
    // ✅ جديد: توزيع الطلبات حسب موقع البزنس — يحتاج الأدمن يعبّي حقل الموقع لكل
    // بزنس أولاً من admin.html (فاضي/"غير محدد" افتراضيًا لحد ما يتحدد).
    ordersByLocation: ordersByLocation,
    totalComponents:CONFIG.BUSINESS_COUNT,
    monthlySnapshots:getMonthlySnapshots(),
    authorizedParticipants:Object.entries(apActivity).map(([code,orders])=>({
      code:code, name:AUTHORIZED_PARTICIPANTS[code]||code, orders:orders
    })),
    // ✅ جديد: بيانات الصندوق الاستثماري
    fund: {
      totalParticipants: participantsCount,
      activeParticipants: activeCount,
      poolValue: poolValue,
      sharePrice: CONFIG.SHARE_PRICE,
      marketListings: marketList.length,
      market: marketList,
      tradingStage: getTradingStage(),          // ✅ جديد: 0/1/2/3
      minBusinessOrders: getMinBusinessOrders() // ✅ جديد: أقل عدد طلبات بين الـ120 بزنس
    },
    index:{
      NAV:NAV.toFixed(2), IIV:IIV.toFixed(2), premium:premium.toFixed(2),
      percent:((NAV/(CONFIG.BUSINESS_COUNT*CONFIG.MAX_ORDERS_PER_BUSINESS*CONFIG.ORDER_VALUE))*100).toFixed(2),
      change:change.toFixed(2), changePercent:changePercent.toFixed(2),
      dayHigh:dayHigh.toFixed(2), dayLow:dayLow.toFixed(2), volatility:volatility.toFixed(2),
      netOrders:netOrders, netUnits:netUnits,
      orderValue:CONFIG.ORDER_VALUE.toFixed(2),
      grossOrders:grossOrders, redemptionOrders:redemptionOrders, components:weights.length
    },
    history:lastRows.map(h=>({time:Utilities.formatDate(new Date(h[0]),CONFIG.TIMEZONE,'HH:mm'),NAV:h[1],IIV:h[2]}))
  };

    try { cache.put('lavndr_data', JSON.stringify(result), CONFIG.CACHE_TTL/1000); } // حد الكاش 100KB — لو تجاوزناه نكمل بدون كاش بدل ما نفشل
    catch (cacheErr) { Logger.log('lavndr_data cache.put فشل (حجم؟): ' + cacheErr); }
    return result;
  } finally {
    if (gotLock) lock.releaseLock(); // ✅ جديد: نفك القفل دايماً حتى لو صار خطأ، عشان ما نعلّق النظام
  }
}

// ─────────────────────────────────────────────

// ─────────────────────────────────────────────
// 🔐 نظام المصادقة — TOKEN عبر Render
// ─────────────────────────────────────────────

// يُستدعى من doGet عند أول زيارة بدون token
// ✅ إصلاح حرج: كانت مدة التوكن 900 ثانية (15 دقيقة) بينما الداشبورد يعمل
// setInterval(loadData, 3600000) — أي تحديث تلقائي كل ساعة. أي تبويب يتفتح ويُترك
// مفتوح كان يتقفل تلقائياً (401 → clearSessionAndReset) عند أول تحديث خلفي، رغم إن
// المستخدم فعلياً لسه شغال بالصفحة. رفعنا المدة لأقصى حد تسمح بيه CacheService
// (21600 ثانية = 6 ساعات) عشان التحديث الساعي يفضل شغال طول الجلسة الطبيعية.
const SESSION_TOKEN_TTL_SECONDS = 21600; // 6 ساعات — أقصى قيمة يقبلها CacheService
function issueToken(email) {
  // توكن مباشر من GAS Cache — بدون Render
  const token = Utilities.getUuid();
  CacheService.getScriptCache().put('TOKEN_' + token, email, SESSION_TOKEN_TTL_SECONDS);
  return token;
}

function verifyToken(token) {
  if (!token) return null;
  // ✅ المصدر الوحيد للثقة: توكن جلسة صادر فعلياً من issueToken بعد تحقق GSI حقيقي،
  // مخزّن في CacheService بعمر SESSION_TOKEN_TTL_SECONDS (6 ساعات). لا يوجد أي مسار
  // بديل يقبل نص مُركّب من العميل — (كان في السابق مسار base64Decode يقبل أي
  // "email:شيء" بدون أي تحقق توقيع فعلي، وهو ما كان يسمح لأي شخص يعرف إيميل مصرح
  // له بتزوير جلسة كاملة. تمت إزالته نهائياً.)
  return CacheService.getScriptCache().get('TOKEN_' + token) || null;
}

// ✅ جديد: تحقق حقيقي من توقيع Google ID Token (JWT) عبر endpoint جوجل الرسمي.
// بديل آمن لأي فك base64 يدوي — جوجل نفسها تتحقق من التوقيع والصلاحية وترجع الـ payload.
function verifyGoogleIdToken(idToken) {
  if (!idToken) return null;
  try {
    const res = UrlFetchApp.fetch(
      'https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(idToken),
      { muteHttpExceptions: true }
    );
    if (res.getResponseCode() !== 200) return null;
    const payload = JSON.parse(res.getContentText());
    // aud لازم يطابق Client ID بتاعنا بالضبط — وإلا توكن صادر لتطبيق تاني ممكن يُقبل غلط
    if (payload.aud !== CONFIG.OAUTH_CLIENT_ID) {
      Logger.log('Token aud mismatch: ' + payload.aud);
      return null;
    }
    if (payload.email_verified !== 'true' && payload.email_verified !== true) return null;
    if (!payload.email) return null;
    return payload.email.toLowerCase();
  } catch(e) {
    Logger.log('verifyGoogleIdToken error: ' + e);
    return null;
  }
}

// ✅ جديد: يتحقق إن الإيميل مسموح له بلوحة تحكم الأدمن تحديداً (مستقل عن isEmailAuthorized)
function isAdminAuthorized(email) {
  if (!email) return false;
  const lower = email.toLowerCase();
  return CONFIG.ADMIN_PANEL_EMAILS.map(e => e.toLowerCase()).includes(lower);
}
// يتحقق من صحة الإيميل محلياً (ALLOWED_EMAILS + Participants sheet)
// ─────────────────────────────────────────────
// شروط كل باقة — مخصّصة لكل مسار ولكل باقة (لا يوجد نص عام واحد)
// ⚠️ مسودة مبنية على معطيات المشروع (الأسعار والسقوف والاسترداد)، وتحتاج مراجعة قانونية
// محلية قبل الاعتماد الكامل لمنتج يتعامل مع أموال حقيقية.
// ─────────────────────────────────────────────
function getTermsText(tier) {
  if (tier === 'business_agreement') return getBusinessAgreementText();
  if (tier === 'oms_services' || tier === 'oms_products' || tier === 'oms_vip') {
    const pr = tierPrice(tier);
    const line = tier === 'oms_vip'
      ? 'الباقة المختارة: OMS VIP — $' + pr + ' (تشمل نظام الطلبات + مقعد المشارك).'
      : 'الباقة المختارة: ' + tierNameAr(tier) + ' — $' + pr + ' (تشمل رسم دخول المؤشر).';
    return 'شروط ' + tierNameAr(tier) + ' — مسار البناء والحركة الاقتصادية\n\n' + line +
      '\nالاسترداد: يحق لك طلب استرداد مبلغك نقداً خلال ' + CONFIG.REFUND_WINDOW_DAYS + ' يوماً (3 أسابيع) من تاريخ الدفع وفق إجراءات الاسترداد المعتمدة.\n\n' + getBusinessAgreementText();
  }
  const info = tierInfo(tier);
  if (!info || info.internal) return '';
  const price = tierPrice(tier);
  const fmt = function(n) { return Number(n).toLocaleString('en-US', {maximumFractionDigits: 2}); };
  const refund = CONFIG.REFUND_WINDOW_DAYS;
  const isMovement = info.category === 'movement';
  const pathName = isMovement ? 'مسار البناء والحركة الاقتصادية' : 'مسار الانضمام إلى لاڤندرز (Join Up LAVENDERS)';
  const head = 'شروط ' + info.nameAr + ' — ' + pathName + '\n\n';

  const payment = 'الدفع: عبر حوالة بنكية يدوية إلى الحساب المعروض لك، ثم تُدخل رمز التحقق المُرسل إلى بريدك مع رقم المعاملة. ' +
    'يراجع فريقنا التحويل يدوياً قبل التفعيل، ولا يتفعّل الاشتراك إلا بعد الاعتماد.';
  const refundTxt = 'الاسترداد: يحق لك طلب استرداد مبلغك نقداً خلال ' + refund + ' يوماً (3 أسابيع) من تاريخ الدفع وفق إجراءات الاسترداد المعتمدة.';
  const noInvest = 'هذه الباقة اشتراك في خدمة/عضوية، وليست استثماراً ولا حصة في أي صندوق، ولا تَعِد بأي عائد مالي.';

  let body = '';
  if (tier === 'lava') {
    body = '1) ما تحصل عليه: وصول للاطلاع على بيانات السوق الحقيقية (لاڤا) لمدة 24 ساعة من وقت التفعيل بقيمة $' + fmt(price) + '.\n' +
      '2) هذا اشتراك مطالعة فقط: بلا وصول إلى أي أنظمة داخلية للأعمال الـ' + CONFIG.BUSINESS_COUNT + '، وبلا أي حصة أو تداول.\n' +
      '3) ينتهي الوصول تلقائياً بانتهاء المدة، ولا يتجدد من تلقائه.\n' +
      '4) السقف محدود (' + fmt(CONFIG.MAX_LAVA_SUBSCRIBERS) + ' مشترك) وقد تُعلَّق الباقة عند اكتماله؛ وقد يُحجَز لڤندكس جزء من المقاعد.\n' +
      '5) ' + payment + '\n6) ' + refundTxt;
  } else if (tier === 'annual') {
    body = '1) ما تحصل عليه: وصول للاطلاع على بيانات السوق الحقيقية (لاڤا) لمدة 12 شهراً من وقت التفعيل بقيمة $' + fmt(price) + '.\n' +
      '2) هذا اشتراك مطالعة فقط: بلا وصول إلى أي أنظمة داخلية للأعمال، وبلا أي حصة أو تداول.\n' +
      '3) ينتهي الوصول بانتهاء السنة ولا يتجدد من تلقائه.\n' +
      '4) السقف محدود (' + fmt(CONFIG.MAX_ANNUAL_SUBSCRIBERS) + ' مشترك سنوي)، وقد يُحجَز جزء من المقاعد لڤندكس.\n' +
      '5) ' + payment + '\n6) ' + refundTxt;
  } else if (tier === 'fendex') {
    body = '1) ما تحصل عليه: عضوية ڤندكس (Lavenders Oracle) لمدة 12 شهراً بقيمة $' + fmt(price) + '، وتشمل تقرير الأوراكل التنبؤي (شهري / نصف سنوي / سنوي) عن سوق الأعمال وسلوك المستهلك.\n' +
      '2) العضوية محدودة بـ' + CONFIG.MAX_FENDEX_SUBSCRIBERS + ' عضواً فقط، ويُخصَم لكل عضو ڤندكس من مقاعد لافا اليومية والسنوية المتاحة للجمهور (لا يُلغى المشتركون الحاليون).\n' +
      '3) التقارير للاستخدام الشخصي أو الداخلي لعملك، ولا يجوز إعادة بيعها أو نشرها.\n' +
      '4) التقارير تحليلية تقديرية، ولا تُعدّ ضماناً لنتيجة تجارية.\n' +
      '5) ' + noInvest + '\n6) ' + payment + '\n7) ' + refundTxt;
  } else if (tier === 'magma') {
    body = '1) ما تحصل عليه: عضوية ماقما لمدة 12 شهراً بقيمة $' + fmt(price) + '، وتشمل دليل الأنشطة الـ' + CONFIG.BUSINESS_COUNT + ' بروابطها التي يدخلها فريق الإدارة.\n' +
      '2) العضوية محدودة بـ' + CONFIG.MAX_MAGMA_SUBSCRIBERS + ' عضو فقط.\n' +
      '3) الروابط تقود إلى أنشطة تجارية مستقلة؛ التعامل معها مسؤوليتك، ولا نضمن جودة خدماتها ولا منتجاتها.\n' +
      '4) ' + noInvest + '\n5) ' + payment + '\n6) ' + refundTxt;
  } else if (tier === 'oms_services' || tier === 'oms_products') {
    const kind = tier === 'oms_services' ? 'براند خدمات' : 'براند منتجات';
    body = '1) ما تحصل عليه: اشتراك في نظام إدارة الطلبات OMS لـ' + kind + ' بقيمة $' + fmt(price) + '، يعمل من الويب وعلى أندرويد لتبقى على تواصل مباشر مع عملائك.\n' +
      '2) الاشتراك لصاحب بزنس أو براند، وبياناتك وطلباتك تخصّك أنت وحدك.\n' +
      '3) باقات OMS الثلاث (خدمات / منتجات / VIP) تشترك في سقف واحد هو ' + CONFIG.MAX_OMS_MEMBERS + ' عضواً.\n' +
      '4) ' + noInvest + '\n5) ' + payment + '\n6) ' + refundTxt;
  } else if (tier === 'oms_vip') {
    body = '1) ما تحصل عليه: باقة OMS VIP بقيمة $' + fmt(price) + '، لبراند منتجات أو خدمات، وتشمل نظام إدارة الطلبات OMS إضافة إلى مقعد مشارك ضمن الأنشطة التجارية.\n' +
      '2) باقات OMS الثلاث تشترك في سقف واحد هو ' + CONFIG.MAX_OMS_MEMBERS + ' عضواً.\n' +
      '3) مقعد المشارك يخضع لإجراءات الاعتماد لدى الإدارة، ويتم تفعيله بعد اعتماد الدفع.\n' +
      '4) ' + noInvest + '\n5) ' + payment + '\n6) ' + refundTxt;
  } else if (tier === 'reseller') {
    body = '1) ما تحصل عليه: عضوية Reseller بقيمة $' + fmt(price) + '، وتشمل حزمة 8 تطبيقات تقدّمها لـ8 أنشطة مختلفة (قيمة التطبيق الواحد $169.35).\n' +
      '2) المطلوب منك: إيجاد الأنشطة المناسبة وتقديم الحل لها؛ ونحن نوفّر المنظومة الجاهزة للتشغيل.\n' +
      '3) أنت تحدّد سعر تقديم التطبيقات لعملائك بحرّية، على أن يبدأ من $440.3 لبراندات الخدمات و$503.3 لبراندات المنتجات.\n' +
      '4) العضوية محدودة بـ' + CONFIG.MAX_RESELLER_MEMBERS + ' عضواً.\n' +
      '5) أرباحك ناتجة عن عملك التجاري وتختلف من شخص لآخر، ولا نضمن مبلغاً أو عائداً محدداً.\n' +
      '6) ' + payment + '\n7) ' + refundTxt;
  } else if (tier === 'franchise') {
    body = '1) ما تحصل عليه: امتياز لاڤندرز لبناء سوقك الخاص من ' + CONFIG.BUSINESS_COUNT + ' بزنس وبراند، لكل بزنس تطبيق طلبات خاص به، مربوطة جميعاً بمؤشر سوق واحد، مع منظومة جاهزة للتشغيل وتدريب عملي ودعم فني وتشغيلي.\n' +
      '2) قيمة الامتياز $' + fmt(price) + '، لا تُدفع دفعة واحدة: تبدأ بحجز $' + fmt(CONFIG.FRANCHISE_RESERVATION_USD) + '، ثم تدفع دفعات حسب تقدّم بناء سوقك ($22.58 لكل بزنس وبراند يُضاف).\n' +
      '3) الامتياز محدود بـ' + CONFIG.MAX_FRANCHISE_MEMBERS + ' صاحب امتياز فقط.\n' +
      '4) أنت تحدّد سعر تقديم التطبيقات لعملائك، على أن يبدأ من $452 لبراندات الخدمات و$515 لبراندات المنتجات.\n' +
      '5) نتائجك التجارية تعتمد على جهدك وسوقك، ولا نضمن مبلغاً أو عائداً محدداً.\n' +
      '6) ' + payment + ' ينطبق ذلك على الحجز وعلى كل دفعة لاحقة.\n7) ' + refundTxt;
  } else if (tier === 'tycoon') {
    body = '1) ما تحصل عليه: وكالة لاڤندرز لدولتك بقيمة $' + fmt(price) + '، تتيح انتظام حتى 2,400 بزنس وبراند في سوق موحّد (20 سوقاً، في كل سوق ' + CONFIG.BUSINESS_COUNT + ' بزنس وبراند)، مع متابعة حركة السوق لحظة بلحظة.\n' +
      '2) تايكون واحد فقط لكل دولة؛ وإن وُجد طلب أو وكالة قائمة للدولة نفسها فلا يُقبل طلب آخر.\n' +
      '3) الوكالة سنوية، وعوائدها تعتمد على بناء الأسواق واستقرار النظام السنوي، ولا نضمن مبلغاً أو عائداً محدداً.\n' +
      '4) تفاصيل التأسيس والتشغيل تُتّفق عليها مع الإدارة بعد اعتماد الدفع.\n' +
      '5) ' + payment + '\n6) ' + refundTxt;
  } else {
    body = '1) ' + payment + '\n2) ' + refundTxt;
  }
  return head + body + '\n\nبالموافقة تُقرّ بأنك قرأت شروط هذه الباقة وفهمتها. الموافقة تخصّ هذه الباقة فقط.';
}

function getBusinessAgreementText() {
  return "لاڤندرز لإدارة البزنسات\n"
    + "اتفاقية انضمام بزنس وبراند لمؤشر سوق لاڤندرز 120 وتنفيذ تطبيق نظام الطلبات، متضمنة اللائحة التنظيمية رقم (1) لسنة 2026م — سياسة إثبات حقيقة الطلبات واستحقاق السيولة التشغيلية من صندوق بزنسات لاڤندرز.\n"
    + "\n"
    + "ملخص قبل الموافقة\n"
    + "• بياناتك وطلباتك تُقيَّم بنقاط (NAV) ترتفع وتنخفض وفق إجمالي الطلبات الموثّقة داخل المؤشر.\n"
    + "• طلب الكاش التشغيلي من الصندوق الرقمي اختياري. إن طلبته فعليك سداد 36% من جملة طلباتك المعتمدة نقداً للصندوق (الطلب الواحد 4.275 دولار).\n"
    + "• تنظر الإدارة في طلبك؛ فإذا قبلته ظهرت لك قيمة الكاش المستحق بعد اكتمال شروط التحقق (الأطواق الثلاثة: المالي، الضماني، المستندي — المادة 6).\n"
    + "• لا يُعتدّ بأي طلب غير موثّق بفاتورة ضريبية من الدفتر المعتمد (المادة 8).\n"
    + "• يمكنك تحميل نسخة الاتفاقية كاملة PDF لتوقيعها ورفعها بعد امتلاك التطبيق.\n"
    + "\n"
    + "الأطراف\n"
    + "الطرف الأول: إدارة لاڤندرز 120 — مالك منظومة مؤشر لاڤندرز 120 والكود.\n"
    + "الطرف الثاني: البزنس / البراند.\n"
    + "الطرف الثالث: الكريتر المنفذ.\n"
    + "\n"
    + "تمهيد موحد\n"
    + "حيث إن لاڤندرز تدير منظومة مؤشر سوق تضم 120 بزنس وبراند لكل سوق، وحيث إن كل بزنس وبراند يمتلك تطبيق إلكتروني لإدارة الطلبات ويرسل بيانات الطلبات التي تمت عبر التطبيق إلى مؤشر لاڤندرز 120، وحيث إن هدف صندوق بزنسات لاڤندرز تحفيزي لتوفير سيولة تشغيل دورية توجه للبزنسات وفقاً لمستحقها المحسوب بنظام التقييم بكود مؤشر السوق لاڤندرز 120، وحيث يرغب الطرف الثاني في الانضمام للمؤشر، فقد اتفقت الأطراف على ما يلي:\n"
    + "\n"
    + "الباب الأول: علاقة الكريتر بالبزنس والبراند في منظومة مؤشر سوق لاڤندرز 120\n"
    + "المادة (1)\n"
    + "1- يلتزم الطرف الثالث للطرف الثاني بتنفيذ تطبيق طلبات بمواصفات منظومة مؤشر لاڤندرز 120 باستخدام كود لاڤندرز ويتم تسليمه خلال يومين من تاريخ سداد رسم الدخول للمؤشر.\n"
    + "2- يلتزم بالمتابعة الفنية حتى اعتماد التطبيق من الطرف الأول.\n"
    + "3- لا يحق للطرف الثالث استلام أي مبالغ نقدية مباشرة من الطرف الثاني، التحصيل حصري عبر الطرف الأول.\n"
    + "4- اعتماد التطبيق وإدراجه في منظومة مؤشر السوق حق حصري للطرف الأول.\n"
    + "\n"
    + "الباب الثاني: الرسوم\n"
    + "المادة (2): اختر نوعاً واحداً فقط — السداد عبر الطرف الأول فقط\n"
    + "• بزنس منتجات: أتعاب تنفيذ $492 + رسم دخول المؤشر $22.58 = الإجمالي $514.58\n"
    + "• بزنس خدمات: أتعاب تنفيذ $429 + رسم دخول المؤشر $22.58 = الإجمالي $451.58\n"
    + "\n"
    + "الباب الثالث: التعريفات والهدف\n"
    + "المادة (3) - التعريفات\n"
    + "أ- الصندوق: صندوق بزنسات لاڤندرز الرقمي، ويظل رقمي محسوب الحقوق ويعتبر جاهزة للاعتماد ولا تتم معاملات مالية ما لم يتم توثيق الطلبات وفقاً لبنود هذه اللائحة.\n"
    + "ب- البزنس: أي كيان من ضمن الـ 120 كيان في منظومة مؤشر السوق.\n"
    + "ج- المؤشر: نظام مؤشر سوق لاڤندرز 120 بنظام تقييم الأداء للبزنسات والبراندات بالنقاط.\n"
    + "د- الإدارة: إدارة لاڤندرز.\n"
    + "هـ- الطلب المحتسب: هو الطلب المكتمل السداد والمثبت بفاتورة ضريبية وتسليم فعلي للعميل، ولا يعتد بالملغي أو المرتجع.\n"
    + "\n"
    + "المادة (4) - هدف الصندوق\n"
    + "تحفيز الأداء بتقييم البزنس والبراند وتوفير سيولة تشغيل دورية توجه للبزنسات والبراندات وفقاً لمستحقها المحسوب بنظام التقييم في منظومة مؤشر سوق لاڤندرز 120، وتنتظم وتترتب البزنسات والبراندات وفقاً للأهلية في أداء البزنس أو البراند.\n"
    + "\n"
    + "الباب الرابع: مؤشر الأداء وقيمة الالتزام في منظومة مؤشر سوق لاڤندرز 120\n"
    + "المادة (5)\n"
    + "أ- جملة الطلبات المستهدفة لكل بزنس وبراند هي 1000 طلب، وهذا العدد يمثل نقاطه الكاملة في منظومة مؤشر السوق.\n"
    + "ب- الأداء هو عدد الطلبات المستقبلة في المؤشر ويتم تحليلها وعليه سداد نقدي بنسبة 36% من جملة الطلبات المحققة كتوثيق ومصادقة على حقيقة الطلبات.\n"
    + "ج- قيمة الطلب الواحد ضمن نسبة الـ 36% محددة بمبلغ 4.275 دولار أمريكي موحدة.\n"
    + "د- طريقة الحساب المعتمدة: بزنس وبراند ارسل للمؤشر عدد طلبات وتم تحليلها فواجب السداد = 36% من جملة عدد الطلبات × $4.275\n"
    + "هـ- يتم السداد بما يعادل قيمة المبلغ بالعملة المحلية حسب سعر الصرف وقت السداد.\n"
    + "و- لا يعتد بالتقييم إلا إذا تم توثيقه وفق الباب الخامس.\n"
    + "\n"
    + "الباب الخامس: شروط استحقاق السيولة\n"
    + "المادة (6)\n"
    + "لا يستحق البزنس أو البراند أي مبلغ من حصيلة الـ 119 بزنس وبراند في منظومة مؤشر سوق لاڤندرز 120 إلا بعد استيفاء الأطواق الثلاثة مجتمعة:\n"
    + "أ- الطوق المالي: سداد قيمة 36% من عدد الطلبات المحققة وفق المادة -5/د-.\n"
    + "ب- الطوق الضماني: يلتزم بتقديم شيك مصرفي معتمد كضمان حسن تنفيذ، محرر باسم/ إدارة لاڤندرز بقيمة تعادل مبلغ السيولة التشغيلية الموجهة له. وتكون القيمة الثابتة مقومة بالدولار الأمريكي كأساس للحساب، ويحرر الشيك بالعملة المحلية بما يعادلها وقت التحرير، على أن تتم معالجة وتسوية قيمة الشيك عند التسييل وفقاً لسعر الصرف السائد وقت التسييل الفعلي، ويظل الدولار هو المرجع الثابت للقيمة.\n"
    + "ج- الطوق المستندي: تقديم ما يثبت أن 100% من الطلبات المحتسبة حقيقية.\n"
    + "\n"
    + "الباب السادس: المستندات الحاسمة لإثبات حقيقة الطلبات\n"
    + "المادة (7)\n"
    + "يعتبر الإثبات مكتملاً فقط بملف موحد يحتوي على:\n"
    + "1- صورة من إيصال شراء دفتر الفواتير الرسمي من ديوان الضرائب أو ما يعادله من الخدمية من إيصالات توريد إلكتروني معتمد.\n"
    + "2- صورة من الإقرار الضريبي الأخير مختوم ومعتمد مدون به رقم الدفتر.\n"
    + "3- صور الفواتير الضريبية بعدد الطلبات الكلي (1000) فاتورة عند الإكتمال (صادرة من ذات الدفتر ومتسلسلة).\n"
    + "4- الإشعار البنكي لسداد مبلغ الـ36% + وإبراز كشف حساب بنكي مختوم يظهر تطابق المبلغ.\n"
    + "5- شيك الضمان المشار إليه في المادة (6/ب).\n"
    + "\n"
    + "المادة (8)\n"
    + "لا يعتد بأي طلب غير مقترن بفاتورة ضريبية من الدفتر المعتمد، ولا يدخل أي طلب غير موثق في حساب التقييم بمنظومة مؤشر سوق، ويعتبر كأن لم يكن.\n"
    + "\n"
    + "الباب السابع: محضر الربط والعواقب\n"
    + "المادة (9) - محضر الربط المستندي\n"
    + "أقر أنا الموقع أدناه، صاحب بطاقة هوية رقم (الواردة في نموذج الاتفاقية)، بكامل أهليتي القانونية بأن الفواتير الضريبية من رقم (....) إلى رقم (....) وعددها (....) طلب، صادرة من دفتر الفواتير رقم (....) المشترى بالإيصال رقم (....) بتاريخ (....) والمدرج في إقراري الضريبي رقم (....) لسنة (....)، وأن المبلغ المسدد وقدره (....) دولار / ما يعادله بالجنيه السوداني، يمثل نسبة 36% منها بواقع (....) طلب × $4.275، هو توثيق لحقيقة كامل الطلبات وأنها مبيعات حقيقية مكتملة التسليم في منظومة مؤشر سوق لاڤندرز 120.\n"
    + "\n"
    + "المادة (10) - الصلاحية والعواقب\n"
    + "أ- صلاحية هذا الملف 12 شهر ميلادي من تاريخ التوقيع، ويجب تجديده عند كل دورة استحقاق جديدة للسيولة.\n"
    + "ب- يحق للإدارة مهلة 30 يوم عمل للتحقق المتقاطع من صحة المستندات عبر الاتصال بالموردين ومراجعة الدفاتر وإعتماد قيم نظام المؤشر.\n"
    + "ج- في حال ثبوت تزوير أو تلاعب أو احتيال، يحق للإدارة تسييل شيك الضمان فورا وفقاً للقيود بهذه اللائحة بعد إخطار البزنس أو البراند كتابياً، واتخاذ الإجراءات القانونية بموجب المادة (123) من القانون الجنائي السوداني لسنة 1991م.\n"
    + "\n"
    + "المادة (11) - فض النزاعات\n"
    + "في حال الاعتراض على قرار الإدارة، يحال النزاع إلى لجنة تحكيم مكونة من 3 أعضاء من البزنسات الـ 120 في منظومة مؤشر السوق يتم اختيارهم بالقرعة، على ألا يكون من بينهم طرف في النزاع، وقرارها ملزم.\n"
    + "\n"
    + "الباب الثامن: الملكية\n"
    + "المادة (12)\n"
    + "كود التطبيق والمنظومة ملكية حصرية للطرف الأول، حق الطرف الثاني انتفاع تشغيلي فقط داخل منظومة مؤشر لاڤندرز.\n"
    + "حماية من الحق الجبري: لا يترتب على هذه الاتفاقية أي شراكة أو تمثيل قانوني أو حق جبري للطرف الثاني أو الثالث على كود أو إدارة لاڤندرز، والعلاقة علاقة انتفاع تشغيلي محددة المدة فقط.\n"
    + "\n"
    + "المادة (13): تنظيم عوائد داتا السوق وحقوق البزنس أو البراند\n"
    + "1- المبدأ العام: لا يستحق البزنس أي عائد نقدي مباشر من بيع الداتا. عوائد الداتا الناتجة عن اشتراكات (لافا $1.4 يومي / $249 سنوي، ڤندكس $1287 سنوي، ماقما $100 سنوي) مملوكة حصرياً لمؤسسي المؤشر وهم: إدارة لاڤندرز (مالك المؤشر)، والتايكون (ممول المؤشر)، والامتياز (منفذو التطبيقات 410/41/19 كريتر).\n"
    + "2- المقابل المستحق للبزنس لقاء مساهمته في توليد الداتا:\n"
    + "أ. حق المعلومة: يحق للبزنس المشترك الاطلاع المجاني الكامل على داتة الـ 119 بزنس الآخرين داخل ذات المؤشر، وذلك كحق أصيل من حقوق الدخول بعد إمتلاك التطبيق ($429 / $492).\n"
    + "ب. حق الصندوق التشغيلي: يحق للبزنس التقدم بطلب كاش تشغيلي من صندوق المؤشر، والذي تبلغ قيمته التأسيسية $51,480 وينمو بمقدار $4.275 عن كل طلب (بنسبة تسييل 36% من جملة طلباته)، ويُمنح وفقاً لنقاط تقييم أدائه داخل المؤشر، على أن يتم إرجاعه بربح ال 36%.\n"
    + "ج. حق الفرصة الاستثمارية: يحق للبزنسات المتفوقة تقييمياً الحصول على فرصة استثمارية اختيارية غير ملزمة، بنسبة 13.93% من إجمالي عوائد المؤسسين وهم إدارة لاڤندرز والتايكون والكريترز عوائدهم السنوية من داتة السوق، وتمنح هذه الفرصة وفقاً لضوابط البزنس الداخلية الخاصة وحدها، ولا دخل للمؤشر في تقييمها الداخلي، وتعتبر شراكة استثمارية مباشرة وليست توزيعاً لأرباح الداتا.\n"
    + "\n"
    + "الباب التاسع: الإقرارات والنماذج\n"
    + "النموذج (2) - إقرار التحقق المتقاطع\n"
    + "أوافق أنا لإدارة لاڤندرز بالاتصال بمورديني ومراجعة دفاتري وسجلات تطبيقي في منظومة مؤشر سوق لاڤندرز 120.\n"
    + "\n"
    + "النموذج (3) - إيصال استلام شيك الضمان\n"
    + "تم استلام شيك رقم (....) بنك (....) بقيمة (....) من السيد، بتاريخ ../../2026م.\n"
    + "\n"
    + "الإقرار النهائي\n"
    + "أقر أنا الطرف الثاني بموافقتي على جميع ما ورد أعلاه، واخترت نوع البزنس المحدد والتزمت بالرسوم والتوثيق في منظومة مؤشر سوق لاڤندرز 120.\n"
    + "وأقر أنا الطرف الثالث بتنفيذ التطبيق حسب المواصفات.\n"
    + "يعتمد - إدارة لاڤندرز - منظومة مؤشر سوق لاڤندرز 120.\n"
    + "\n"
    + "بالموافقة تقرّ بأنك قرأت هذه الاتفاقية وفهمتها. للاتفاقية نسخة PDF قابلة للتعبئة والتوقيع، تُرفع بعد امتلاك تطبيق الأندرويد.\n";
}

// ✅ هل وافق المستخدم على آخر نسخة من شروط هذه الباقة تحديداً؟ (الموافقة على باقة لا تغطي غيرها)
function hasAcceptedTerms(email, tier) {
  if (!tier) return false;
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Consents');
  if (!sheet || sheet.getLastRow() < 2) return false;
  const lower = String(email).toLowerCase();
  const data = sheet.getDataRange().getValues();
  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][0]).toLowerCase() === lower && String(data[i][3] || '') === String(tier)
        && parseInt(data[i][1]) === CONFIG.TERMS_VERSION) return true;
  }
  return false;
}

// ✅ جديد: تسجيل مركزي لأي عملية حساسة — محصّنة بالكامل، فشل التسجيل نفسه (نادر لكن
// ممكن) ميوقفش العملية الأساسية اللي بتوثّقها. الشراء الفعلي أهم من سطر السجل.
function logAudit(actor, action, details) {
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('AuditLog');
    if (!sheet) return;
    sheet.appendRow([new Date(), actor, action, typeof details === 'object' ? JSON.stringify(details) : String(details || '')]);
  } catch(e) {
    Logger.log('logAudit فشلت (تجاهلناها عمداً عشان ما توقفش العملية الأساسية): ' + e);
  }
}

// موافقة «اتفاقية لاڤندرز لإدارة البزنسات» — تُحتسب من موافقة أي باقة OMS أو من المفتاح العام للاتفاقية
function hasAcceptedAgreement(email) {
  return ['business_agreement', 'oms_services', 'oms_products', 'oms_vip'].some(function(t) { return hasAcceptedTerms(email, t); });
}

function recordConsent(email, tier) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Consents');
  sheet.appendRow([email, CONFIG.TERMS_VERSION, new Date(), tier]);
}

function isEmailAuthorized(email) {
  if (!email) return false;
  const lower = email.toLowerCase();
  // 1) قائمة ALLOWED_EMAILS الثابتة (احتياطية/الأدمن)
  if (ALLOWED_EMAILS.map(e => e.toLowerCase()).includes(lower)) return true;
  // 2) شيت AllowedEmails (الـ120 إيميل المصرح لها)
  if (getAllowedEmailsFromSheet().includes(lower)) return true;
  // 3) شيت المشاركين النشطين
  // ✅ معاد بناؤها للتوسّع: TextFinder بدل سحب الشيت كامل (نفس فكرة isSubscriberActive) —
  // هذي الدالة بتتنادى على كل طلب مصادَق عليه (عبر getUserRole)، وكاشها قصير (دقيقتين بس)
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Participants');
    if (sheet.getLastRow() < 2) return false;
    const finder = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1)
      .createTextFinder(lower).matchEntireCell(true).matchCase(false);
    const matches = finder.findAll();
    for (let i = 0; i < matches.length; i++) {
      if (sheet.getRange(matches[i].getRow(), 2).getValue() === 'active') return true;
    }
  } catch(e) {}
  return false;
}

// ✅ جديد: قائمة الدفعات بانتظار مراجعة الأدمن — بدون رمز OTP نهائياً (ما فيش داعي الأدمن يشوفه)
function getAdminPendingPayments() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('PendingPayments');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [] };
  const data = sheet.getDataRange().getValues();
  const rows = [];
  for (let i = 1; i < data.length; i++) {
    if (data[i][5] !== 'awaiting_review') continue; // بس اللي فعلاً بانتظار قرار
    rows.push({
      row: i + 1, // رقم الصف الحقيقي بالشيت — نرجّعه بالضبط في admin_decide_payment
      email: data[i][0],
      amount: data[i][2],
      sellerEmail: data[i][3] || '',
      requestedAt: data[i][6],
      txnRef: data[i][7],
      submittedAt: data[i][8]
    });
  }
  return { rows: rows };
}

// ✅ جديد: قائمة المشاركين لعرضها بلوحة الأدمن
function getAdminParticipants() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  const sheet = master.getSheetByName('Participants');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [] };
  const data = sheet.getDataRange().getValues();
  const rows = [];
  for (let i = 1; i < data.length; i++) {
    rows.push({
      email: data[i][0], status: data[i][1], entryNAV: data[i][2], entryDate: data[i][3],
      sharePrice: data[i][4], currentValue: data[i][5], pnl: data[i][6]
    });
  }
  return { rows: rows };
}

// ✅ جديد: سجل التدقيق للأدمن — بيرجّع آخر 100 سطر بس (الأحدث أولاً) عشان ما تبطأش
// الشاشة لو السجل كبر كتير؛ الأدمن غالبًا محتاج آخر العمليات مش الأرشيف الكامل هنا
// ✅ جديد: عرض كل استحقاقات البزنسات مجمّعة — للأدمن، عشان يشوف مين مستحق كام
// وحالة كل استحقاق (متاح / قابل البزنس وبانتظار ضمان / مكتمل)
// ✅ جديد: قائمة كل البزنسات للأدمن — يوضّح مين مربوط بإيميل ومين لسه لأ
// أعضاء OMS (النشطون/المنتظرون) وهل رُبط إيميل كل منهم بشيت بزنسه — يعمل منه الأدمن «ربط بشيت»
function getAdminOmsMembers() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [] };
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 12).getValues();
  const out = [], seen = {};
  for (let i = data.length - 1; i >= 0; i--) {
    const r = data[i], tier = String(r[1]), status = String(r[4]);
    const info = tierInfo(tier);
    if (!info || info.capacityGroup !== 'oms') continue;
    if (['closed_rejected', 'closed_applied'].indexOf(status) !== -1) continue;
    const email = String(r[0]).toLowerCase();
    if (seen[email]) continue; seen[email] = true;
    const biz = getBusinessesByEmail(email);
    out.push({ email: email, tier: tier, tierName: info.nameAr, status: status,
      linked: biz.length > 0, businessName: biz.length ? biz[0].name : '', sheetId: biz.length ? biz[0].sheetId : '',
      requestedAt: r[5] });
  }
  return { rows: out.reverse() };
}

function getAdminBusinessList() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [] };
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 8).getValues();
  // ✅ جديد: عدد الطلبات لكل بزنس — مضاف عشان لوحة الأدمن تقدر ترسم شارت توزيع طلبات
  // حقيقي بدل ما تكون قائمة ربط أسماء بس. بيانات موجودة أصلاً (BUSINESS_ORDER_COUNTS)،
  // القراءة دي رخيصة (props، مش شيت خارجي).
  const counts = JSON.parse(props.getProperty('BUSINESS_ORDER_COUNTS')||'{}');
  // ⚠️ العمود E (Location) اتشال من الاستخدام — الموقع الجغرافي بقى بييجي من عمود
  // Location في شيت الطلبات نفسه (راجع getData)، مش حقل يحدده الأدمن هنا. سايبين
  // العمود F (Closed) في مكانه زي ما هو (بدل ما نزحزحه لـE) عشان ما نلخبطش أي شيت
  // فعلي اتعمله إغلاق قبل كده. عمودي G/H (Category/ExternalLink) جداد — راجع
  // setBusinessCategoryAndLink، أساس دليل ماقما.
  const rows = data.map((r, i) => ({
    row: i + 2, sheetId: String(r[0]).trim(), name: String(r[1] || '').trim(),
    email: String(r[2] || '').trim(), autoAccept: String(r[3] || '').trim().toLowerCase() === 'true',
    orders: counts[String(r[0]).trim()] || 0,
    closed: String(r[5] || '').trim().toLowerCase() === 'true',
    category: String(r[6] || '').trim(),
    externalLink: String(r[7] || '').trim()
  }));
  return { rows: rows };
}

function getBusinessEntitlements() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Distributions');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [] };
  const data = sheet.getDataRange().getValues();
  const rows = [];
  for (let i = 1; i < data.length; i++) {
    const entitlement = parseFloat(data[i][5]) || 0;
    const orders = parseInt(data[i][8]) || 0;
    // ✅ إصلاح جوهري: الشيك = المساهمة (entitlement، الموجّهة من رأس مال الصندوق
    // حسب وزن البزنس) + النمو الحقيقي (36% من قيمة طلباته). مش الـ36% لوحدها.
    const growthAmount = parseFloat((orders * CONFIG.GUARANTEE_RATE * CONFIG.ORDER_VALUE).toFixed(2));
    const guaranteeAmount = parseFloat((entitlement + growthAmount).toFixed(2));
    rows.push({
      row: i + 1, date: data[i][0], sheetId: data[i][2], name: data[i][3],
      weight: data[i][4], entitlement: entitlement,
      status: data[i][6], orders: orders,
      guaranteeStatus: data[i][9] || '',
      growthAmount: growthAmount, guaranteeAmount: guaranteeAmount
    });
  }
  return { rows: rows };
}

// ✅ جديد: بيانات بورتال البزنس (business.html) — دخول منفصل تماماً عن المشارك/المشترك.
// بزنس ممكن يملك أكتر من شيت (نظرياً)، فبنرجّع array. كل بزنس بيشوف بس بياناته هو
// (orders/weight من الفهرس الحي + استحقاقاته من Distributions) — بدون أي بيانات
// عن بزنسات تانية. لا يوجد فحص role هنا عمداً: ملكية البزنس (BusinessSheets.Email)
// مستقلة تماماً عن كون الشخص participant/subscriber بالصندوق.
// ─────────────────────────────────────────────
// طلبات البزنس: (1) الاتفاقية الموقّعة (رابط) و(2) طلب الكاش التشغيلي من الصندوق الرقمي
// شيت BusinessRequests (يُنشأ تلقائياً عند أول استخدام)
// ─────────────────────────────────────────────
const BR_HEADERS = ['RequestedAt','Email','SheetID','BusinessName','Type','Orders','Due36','SuggestedAmount','Status','AgreementLink','DecidedAt','DecidedBy','ApprovedAmount','Note'];
function getRequestsSheet() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  let sh = master.getSheetByName('BusinessRequests');
  if (!sh) { sh = master.insertSheet('BusinessRequests'); sh.appendRow(BR_HEADERS); }
  return sh;
}
function findOwnedBusiness(email, sheetId) {
  const list = getBusinessesByEmail(email);
  for (let i = 0; i < list.length; i++) if (list[i].sheetId === String(sheetId || '').trim()) return list[i];
  return null;
}
function notifyAdminSafe(title, body) {
  try { pushToEmail(CONFIG.ADMIN_EMAIL, title, body, 'business_request'); } catch (e) { Logger.log('notifyAdminSafe: ' + e); }
}
// البزنس يرفع رابط الاتفاقية الموقعة (Drive مثلاً) — صف واحد لكل بزنس (يُحدَّث)
function submitAgreementLink(email, sheetId, link) {
  const biz = findOwnedBusiness(email, sheetId);
  if (!biz) return { error: 'هذا البزنس غير مرتبط بحسابك', code: 403 };
  link = String(link || '').trim();
  if (!/^https:\/\/[^\s]{4,480}$/.test(link)) return { error: 'ضع رابطاً صحيحاً يبدأ بـ https://' };
  const lock = LockService.getScriptLock();
  let got = false; try { got = lock.tryLock(10000); } catch (e) {}
  if (!got) return { error: 'الخادم مشغول — حاول بعد لحظة' };
  try {
    const sh = getRequestsSheet();
    const data = sh.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (data[i][4] === 'agreement' && String(data[i][2]).trim() === biz.sheetId) {
        if (data[i][8] === 'received') return { error: 'تم استلام اتفاقيتك مسبقاً' };
        sh.getRange(i + 1, 1).setValue(new Date());
        sh.getRange(i + 1, 10).setValue(link);
        sh.getRange(i + 1, 9).setValue('submitted');
        notifyAdminSafe('اتفاقية موقّعة جديدة', biz.name + ' رفع رابط الاتفاقية الموقعة');
        return { status: 'submitted' };
      }
    }
    sh.appendRow([new Date(), email.toLowerCase(), biz.sheetId, biz.name, 'agreement', '', '', '', 'submitted', link, '', '', '', '']);
    notifyAdminSafe('اتفاقية موقّعة جديدة', biz.name + ' رفع رابط الاتفاقية الموقعة');
    return { status: 'submitted' };
  } finally { lock.releaseLock(); }
}
function businessMetrics(sheetId) {
  const w = getBusinessWeights();
  const total = w.reduce(function(a, b) { return a + (b.orders || 0); }, 0);
  let mine = null;
  w.forEach(function(x) { if (x.sheetId === sheetId) mine = x; });
  const orders = mine ? mine.orders : 0, weight = mine ? mine.weight : 0;
  const fundCapital = 51480 + CONFIG.ORDER_VALUE * total;
  return {
    orders: orders, weight: weight,
    due36: parseFloat((orders * CONFIG.GUARANTEE_RATE * CONFIG.ORDER_VALUE).toFixed(2)),
    suggested: parseFloat((fundCapital * weight / 100).toFixed(2))
  };
}
// البزنس يطلب كاش تشغيلي (اختياري) — ينتظر قرار الأدمن
function requestCash(email, sheetId) {
  const biz = findOwnedBusiness(email, sheetId);
  if (!biz) return { error: 'هذا البزنس غير مرتبط بحسابك', code: 403 };
  const m = businessMetrics(biz.sheetId);
  if (m.orders <= 0) return { error: 'لا توجد طلبات موثقة لبزنسك بعد' };
  const lock = LockService.getScriptLock();
  let got = false; try { got = lock.tryLock(10000); } catch (e) {}
  if (!got) return { error: 'الخادم مشغول — حاول بعد لحظة' };
  try {
    const sh = getRequestsSheet();
    const data = sh.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (data[i][4] === 'cash' && String(data[i][2]).trim() === biz.sheetId && data[i][8] === 'pending')
        return { error: 'لديك طلب كاش قيد الانتظار' };
    }
    sh.appendRow([new Date(), email.toLowerCase(), biz.sheetId, biz.name, 'cash', m.orders, m.due36, m.suggested, 'pending', '', '', '', '', '']);
    notifyAdminSafe('طلب كاش تشغيلي', biz.name + ' — طلبات: ' + m.orders + ' | مستحق السداد 36%: $' + m.due36);
    logAudit(email, 'cash_requested', { sheetId: biz.sheetId, orders: m.orders, due36: m.due36 });
    return { status: 'pending', orders: m.orders, due36: m.due36 };
  } finally { lock.releaseLock(); }
}
function isAgreementReceived(sheetId) {
  const sh = getRequestsSheet(); const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) if (data[i][4] === 'agreement' && String(data[i][2]).trim() === sheetId && data[i][8] === 'received') return true;
  return false;
}
// حالة طلبات بزنس واحد (للبورتال) — قيمة الكاش المعتمدة لا تظهر قبل استلام الاتفاقية
function getBusinessRequestsFor(sheetId) {
  const sh = getRequestsSheet(); const data = sh.getDataRange().getValues();
  const out = { agreement: null, cash: [], agreementReceived: false, m: businessMetrics(sheetId) };
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][2]).trim() !== sheetId) continue;
    if (data[i][4] === 'agreement') { out.agreement = { status: data[i][8], link: data[i][9] }; out.agreementReceived = data[i][8] === 'received'; }
    else if (data[i][4] === 'cash') out.cash.push({ requestedAt: data[i][0], status: data[i][8], due36: data[i][6], approvedAmount: data[i][12], note: data[i][13] });
  }
  out.cash.forEach(function(c) { if (!out.agreementReceived) c.approvedAmount = ''; });
  out.cash.sort(function(a, b) { return new Date(b.requestedAt) - new Date(a.requestedAt); });
  return out;
}
function getAdminBusinessRequests() {
  const sh = getRequestsSheet(); const data = sh.getDataRange().getValues(); const rows = [];
  for (let i = 1; i < data.length; i++) {
    rows.push({ row: i + 1, requestedAt: data[i][0], email: data[i][1], sheetId: data[i][2], name: data[i][3], type: data[i][4],
      orders: data[i][5], due36: data[i][6], suggested: data[i][7], status: data[i][8], link: data[i][9], approvedAmount: data[i][12] });
  }
  return { rows: rows.reverse() };
}
// قرار الأدمن: agreement → received/rejected | cash → approved (مع مبلغ) / rejected
function decideBusinessRequest(row, decision, amount, adminEmail) {
  row = parseInt(row);
  const lock = LockService.getScriptLock();
  let got = false; try { got = lock.tryLock(10000); } catch (e) {}
  if (!got) return { error: 'الخادم مشغول — حاول بعد لحظة' };
  try {
    const sh = getRequestsSheet();
    if (!row || row < 2 || row > sh.getLastRow()) return { error: 'صف غير موجود' };
    const r = sh.getRange(row, 1, 1, BR_HEADERS.length).getValues()[0];
    const type = r[4], status = r[8];
    if (type === 'agreement') {
      if (['received', 'rejected'].indexOf(decision) === -1) return { error: 'قرار غير صالح' };
      if (status !== 'submitted') return { error: 'الحالة الحالية: ' + status };
      sh.getRange(row, 9).setValue(decision);
      try { // مزامنة حالة نموذج الاتفاقية داخل التطبيق (القفل عند الاستلام، وإعادة الفتح عند الرفض)
        const af = getAgreementSheets().forms, ar = findAgreementRow(af, String(r[2]).trim());
        if (ar) af.getRange(ar, 4).setValue(decision === 'received' ? 'received' : 'draft');
      } catch (e) {}
    } else if (type === 'cash') {
      if (['approved', 'rejected'].indexOf(decision) === -1) return { error: 'قرار غير صالح' };
      if (status !== 'pending') return { error: 'الحالة الحالية: ' + status };
      if (decision === 'approved') {
        const amt = parseFloat(amount);
        if (!(amt > 0) || amt > 10000000) return { error: 'أدخل مبلغاً صحيحاً' };
        sh.getRange(row, 13).setValue(amt);
        // يدخل مسار الاستحقاق/الضمان الموجود: قبول ← بانتظار شيك الضمان ← تأكيد الاستلام
        const dist = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Distributions');
        const m = businessMetrics(String(r[2]).trim());
        dist.appendRow([new Date(), 'cash_request:' + r[1], r[2], r[3], m.weight.toFixed(2), amt.toFixed(2), 'accepted_awaiting_guarantee', '', r[5] || 0, 'awaiting_guarantee']);
      }
      sh.getRange(row, 9).setValue(decision);
    } else return { error: 'نوع غير معروف' };
    sh.getRange(row, 11).setValue(new Date()); sh.getRange(row, 12).setValue(adminEmail || '');
    logAudit(adminEmail || 'unknown_admin', 'business_request_' + decision, { row: row, type: type, business: r[3], amount: amount || '' });
    try {
      const txt = type === 'agreement'
        ? (decision === 'received' ? 'تم استلام اتفاقيتك الموقعة ✅' : 'لم تُقبل الاتفاقية الموقعة — راجع الإدارة')
        : (decision === 'approved' ? 'تم قبول طلب الكاش التشغيلي — أكمل شروط التحقق (الأطواق الثلاثة) لتظهر قيمته' : 'لم يُقبل طلب الكاش التشغيلي حالياً');
      pushToEmail(String(r[1]), 'لاڤندرز لإدارة البزنسات', txt, 'business_request');
    } catch (e) {}
    return { status: decision };
  } finally { lock.releaseLock(); }
}

// ─────────────────────────────────────────────
// تقدّم المستخدم (التنقل): آخر شاشة/خطوة اشتراك — محفوظ حسب الإيميل ليكمل من حيث توقف.
// البيانات المباشرة (المؤشر/الأسعار/الاستحقاقات) لا تُحفظ هنا أبداً.
// ─────────────────────────────────────────────
function getProgressSheet() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  let sh = master.getSheetByName('UserProgress');
  if (!sh) { sh = master.insertSheet('UserProgress'); sh.appendRow(['Email', 'State', 'UpdatedAt']); }
  return sh;
}
function sanitizeProgress(st) {
  const str = function(v, n) { return typeof v === 'string' ? v.replace(/[^\w\-.:@ ]/g, '').slice(0, n) : ''; };
  st = (st && typeof st === 'object') ? st : {};
  const out = { page: str(st.page, 20), screen: str(st.screen, 20), space: str(st.space, 12) };
  if (st.form) { out.form = str(st.form, 20); out.sheet = str(st.sheet, 60); } // نموذج مفتوح (الاتفاقية) لاستعادته
  if (st.gate && typeof st.gate === 'object') {
    out.gate = { view: str(st.gate.view, 12), key: str(st.gate.key, 20), variant: str(st.gate.variant, 20) };
  }
  return out;
}
function getUserProgress(email) {
  const sh = getProgressSheet();
  const lower = String(email).trim().toLowerCase();
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim().toLowerCase() === lower) {
      try { return { state: sanitizeProgress(JSON.parse(data[i][1])), updatedAt: data[i][2] }; } catch (e) { return { state: null }; }
    }
  }
  return { state: null };
}
function saveUserProgress(email, state) {
  const clean = sanitizeProgress(state);
  const json = JSON.stringify(clean);
  if (json.length > 600) return { error: 'state too large' };
  const lock = LockService.getScriptLock();
  let got = false; try { got = lock.tryLock(5000); } catch (e) {}
  if (!got) return { error: 'busy' };
  try {
    const sh = getProgressSheet();
    const lower = String(email).trim().toLowerCase();
    const data = sh.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]).trim().toLowerCase() === lower) {
        sh.getRange(i + 1, 2).setValue(json); sh.getRange(i + 1, 3).setValue(new Date());
        return { status: 'saved' };
      }
    }
    sh.appendRow([lower, json, new Date()]);
    return { status: 'saved' };
  } finally { lock.releaseLock(); }
}

// ─────────────────────────────────────────────
// نموذج الاتفاقية داخل الصفحة (حقول + توقيعات مرسومة) — شيتا AgreementForms و AgreementSigs
// البزنس يعبّئ حقوله ويوقّع ثم يرسل؛ الأدمن يعبّئ حقوله (نموذج 3 + اعتماد الإدارة).
// ─────────────────────────────────────────────
const AGR_BUSINESS_KEYS = ['type','b_name','b_activity','b_owner','b_phone','b_id','c_name','c_number','c_id',
  'a9_name','a9_owner','a9_id','inv_from','inv_to','inv_count','book_no','receipt_no','receipt_date','tax_decl_no','tax_year',
  'paid_usd','paid_local','orders_count','m2_name','m3_note','signer_name','stamp_text','w1_name','w1_id','w2_name','w2_id','final_date'];
const AGR_ADMIN_KEYS = ['m3_cheque_no','m3_bank','m3_value','m3_from','m3_date','admin_date','admin_name'];
const AGR_BUSINESS_SIGS = ['sig_business','sig_creator','sig_witness1','sig_witness2','sig_m2'];
const AGR_ADMIN_SIGS = ['sig_admin'];

function getAgreementSheets() {
  const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
  let f = master.getSheetByName('AgreementForms');
  if (!f) { f = master.insertSheet('AgreementForms'); f.appendRow(['SheetID', 'Email', 'Fields', 'Status', 'UpdatedAt', 'SubmittedAt']); }
  let g = master.getSheetByName('AgreementSigs');
  if (!g) { g = master.insertSheet('AgreementSigs'); g.appendRow(['SheetID', 'Key', 'DataURL', 'UpdatedAt']); }
  return { forms: f, sigs: g };
}
// المالك (بإيميله) أو الأدمن فقط
function agreementAccess(email, sheetId) {
  sheetId = String(sheetId || '').trim();
  if (!sheetId) return { error: 'sheetId مطلوب' };
  if (isAdminAuthorized(email)) return { admin: true, sheetId: sheetId, bizEmail: '', name: '' };
  const biz = findOwnedBusiness(email, sheetId);
  if (!biz) return { error: 'هذا البزنس غير مرتبط بحسابك', code: 403 };
  return { admin: false, sheetId: biz.sheetId, bizEmail: email.toLowerCase(), name: biz.name };
}
function findAgreementRow(sh, sheetId) {
  const d = sh.getDataRange().getValues();
  for (let i = 1; i < d.length; i++) if (String(d[i][0]).trim() === sheetId) return i + 1;
  return 0;
}
function getAgreementForm(email, sheetId) {
  const acc = agreementAccess(email, sheetId);
  if (acc.error) return acc;
  const sh = getAgreementSheets();
  const row = findAgreementRow(sh.forms, acc.sheetId);
  let fields = {}, status = 'draft';
  if (row) {
    try { fields = JSON.parse(sh.forms.getRange(row, 3).getValue() || '{}'); } catch (e) {}
    status = sh.forms.getRange(row, 4).getValue() || 'draft';
  }
  const sigs = {};
  const d = sh.sigs.getDataRange().getValues();
  for (let i = 1; i < d.length; i++) if (String(d[i][0]).trim() === acc.sheetId) sigs[d[i][1]] = d[i][2];
  // الحالة الرسمية من طلب الاتفاقية (قد تكون received/rejected بقرار الأدمن)
  const reqSt = getBusinessRequestsFor(acc.sheetId).agreement;
  if (reqSt && reqSt.status) status = reqSt.status;
  return { fields: fields, sigs: sigs, status: status, isAdmin: acc.admin, businessName: acc.name };
}
function saveAgreementFields(email, sheetId, incoming) {
  const acc = agreementAccess(email, sheetId);
  if (acc.error) return acc;
  const allowed = acc.admin ? AGR_ADMIN_KEYS : AGR_BUSINESS_KEYS;
  if (!incoming || typeof incoming !== 'object') return { error: 'بيانات غير صالحة' };
  const lock = LockService.getScriptLock();
  let got = false; try { got = lock.tryLock(8000); } catch (e) {}
  if (!got) return { error: 'الخادم مشغول — حاول بعد لحظة' };
  try {
    const sh = getAgreementSheets().forms;
    let row = findAgreementRow(sh, acc.sheetId);
    if (!acc.admin && row) {
      const st = sh.getRange(row, 4).getValue();
      if (st === 'received') return { error: 'الاتفاقية مستلمة ومقفلة' };
    }
    let fields = {};
    if (row) { try { fields = JSON.parse(sh.getRange(row, 3).getValue() || '{}'); } catch (e) {} }
    let n = 0;
    Object.keys(incoming).forEach(function(k) {
      if (allowed.indexOf(k) === -1) return;
      fields[k] = String(incoming[k] == null ? '' : incoming[k]).slice(0, 200); n++;
    });
    const json = JSON.stringify(fields);
    if (json.length > 45000) return { error: 'حجم البيانات كبير' };
    if (row) { sh.getRange(row, 3).setValue(json); sh.getRange(row, 5).setValue(new Date()); }
    else {
      const bizEmail = acc.admin ? '' : acc.bizEmail;
      sh.appendRow([acc.sheetId, bizEmail, json, 'draft', new Date(), '']);
    }
    if (acc.admin) logAudit(email, 'agreement_admin_fields', { sheetId: acc.sheetId, keys: Object.keys(incoming).length });
    return { status: 'saved', count: n };
  } finally { lock.releaseLock(); }
}
function saveAgreementSig(email, sheetId, key, data) {
  const acc = agreementAccess(email, sheetId);
  if (acc.error) return acc;
  const allowedKeys = acc.admin ? AGR_ADMIN_SIGS : AGR_BUSINESS_SIGS;
  if (allowedKeys.indexOf(key) === -1) return { error: 'مفتاح توقيع غير صالح' };
  if (data !== '' && !(typeof data === 'string' && data.length <= 9000 && /^data:image\/png;base64,[A-Za-z0-9+\/=]+$/.test(data))) return { error: 'صورة التوقيع غير صالحة' };
  const lock = LockService.getScriptLock();
  let got = false; try { got = lock.tryLock(8000); } catch (e) {}
  if (!got) return { error: 'الخادم مشغول — حاول بعد لحظة' };
  try {
    const sh = getAgreementSheets();
    if (!acc.admin) {
      const r = findAgreementRow(sh.forms, acc.sheetId);
      if (r && sh.forms.getRange(r, 4).getValue() === 'received') return { error: 'الاتفاقية مستلمة ومقفلة' };
    }
    const d = sh.sigs.getDataRange().getValues();
    for (let i = 1; i < d.length; i++) {
      if (String(d[i][0]).trim() === acc.sheetId && d[i][1] === key) {
        sh.sigs.getRange(i + 1, 3).setValue(data); sh.sigs.getRange(i + 1, 4).setValue(new Date());
        return { status: 'saved' };
      }
    }
    sh.sigs.appendRow([acc.sheetId, key, data, new Date()]);
    return { status: 'saved' };
  } finally { lock.releaseLock(); }
}
// البزنس يرسل النموذج للإدارة — يُنشئ/يحدّث طلب الاتفاقية ليظهر للأدمن (link = in-app-form)
function submitAgreementForm(email, sheetId) {
  const acc = agreementAccess(email, sheetId);
  if (acc.error) return acc;
  if (acc.admin) return { error: 'الإرسال للبزنس فقط' };
  const form = getAgreementForm(email, sheetId);
  const f = form.fields || {};
  if (!f.type || !f.b_name || !form.sigs.sig_business) return { error: 'أكمل نوع البزنس والاسم التجاري وتوقيع البزنس أولاً' };
  if (form.status === 'received') return { error: 'تم استلام اتفاقيتك مسبقاً' };
  const res = submitAgreementLink(email, acc.sheetId, 'https://in-app-form.lavndr/' + acc.sheetId);
  if (res.error) return res;
  const sh = getAgreementSheets().forms;
  const row = findAgreementRow(sh, acc.sheetId);
  if (row) { sh.getRange(row, 4).setValue('submitted'); sh.getRange(row, 6).setValue(new Date()); }
  return { status: 'submitted' };
}

function getMyBusinessPortalData(email) {
  const businesses = getBusinessesByEmail(email); // [{sheetId, name}] — IDOR-safe: مبني على tokenEmail بس
  if (businesses.length === 0) return { linked: false, businesses: [] };

  const liveData = getData(); // مكاشة أصلاً (CACHE_TTL) — قراءة إضافية رخيصة
  const weightsMap = {};
  (liveData.weights || []).forEach(w => { weightsMap[w.sheetId] = w; });

  const allEntitlements = getBusinessEntitlements().rows;
  // ✅ جديد: بزنس مقفول بيختفي من weightsMap تلقائيًا (getBusinessSheetIds بيستبعده) —
  // من غير الفحص ده كان هيبان "0 طلب" بشكل مضلّل بدل "الحساب مقفول".
  const closedMap = getAdminBusinessList().rows.reduce((m,r) => { m[r.sheetId]=r.closed; return m; }, {});

  const businessesData = businesses.map(b => {
    const w = weightsMap[b.sheetId] || null;
    const myEntitlements = allEntitlements
      .filter(e => e.sheetId === b.sheetId)
      .sort((x, y) => new Date(y.date) - new Date(x.date));
    return {
      sheetId: b.sheetId,
      name: b.name,
      ticker: w ? w.ticker : null,
      orders: w ? w.count : 0,
      weight: w ? w.weight : 0,
      closed: !!closedMap[b.sheetId], // ✅ جديد
      autoAccept: isAutoAcceptEnabled(b.sheetId),
      entitlements: myEntitlements,
      requests: getBusinessRequestsFor(b.sheetId)
    };
  });
  return { linked: true, businesses: businessesData };
}

// ─────────────────────────────────────────────
// ✅ جديد: باقة "ماقما" — دليل الـ120 نشاط + تتبع الاطلاع
// ─────────────────────────────────────────────
// ✅ خريطة فئة/رابط كل بزنس (يدخلها الأدمن يدويًا من admin.html) — مكاشة 10 دقايق
function getBusinessCategoryLinkMap() {
  const cached = cache.get('lavndr_business_category_links');
  if (cached) return JSON.parse(cached);
  const map = {};
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('BusinessSheets');
    if (sheet && sheet.getLastRow() > 1) {
      sheet.getRange(2, 1, sheet.getLastRow() - 1, 8).getValues().forEach(r => {
        const id = String(r[0]).trim();
        if (id) map[id] = { category: String(r[6]||'').trim(), link: String(r[7]||'').trim() };
      });
      cache.put('lavndr_business_category_links', JSON.stringify(map), 600);
    }
  } catch(e) { Logger.log('getBusinessCategoryLinkMap error: ' + e); }
  return map;
}

// ✅ أي بزنس اطّلع عليه مشترك ماقما معيّن (upsert-once) — TextFinder بدل سحب الشيت كامل
function getMagmaViewedSet(email) {
  const viewed = {};
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('MagmaViews');
    if (sheet && sheet.getLastRow() > 1) {
      const finder = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1)
        .createTextFinder(email).matchEntireCell(true).matchCase(false);
      finder.findAll().forEach(m => {
        const sheetId = sheet.getRange(m.getRow(), 2).getValue();
        if (sheetId) viewed[String(sheetId).trim()] = true;
      });
    }
  } catch(e) { Logger.log('getMagmaViewedSet error: ' + e); }
  return viewed;
}

// ✅ دليل الـ120 نشاط لمشترك ماقما — مرتبين حسب وزنهم الاستهلاكي الحقيقي بالمؤشر
// (الأكتر طلبًا يظهر أول). كل نشاط بياخد بس: اسمه، فئته (يدخلها الأدمن يدويًا)،
// رابطه الخارجي، ترتيبه، ووزنه %. عمدًا بدون أي بيانات عملاء أو طلبات خام — نفس
// مبدأ الأبعاد المعتمدة (منتج/تاريخ/موقع)، مش بيانات شخصية عن عملاء البزنسات.
function getMagmaDirectory(email) {
  const liveData = getData(); // مكاشة أصلاً (CACHE_TTL) — قراءة إضافية رخيصة
  const catLinkMap = getBusinessCategoryLinkMap();
  const viewed = getMagmaViewedSet(email);
  const weights = (liveData.weights || []).slice().sort((a, b) => b.weight - a.weight);

  const businesses = weights.map((w, idx) => {
    const extra = catLinkMap[w.sheetId] || { category: '', link: '' };
    return {
      sheetId: w.sheetId,
      name: w.name,
      ticker: w.ticker,
      rank: idx + 1,
      weight: w.weight,
      category: extra.category || 'غير مصنّف',
      link: extra.link || '',
      viewed: !!viewed[w.sheetId]
    };
  });

  return {
    businesses: businesses,
    totalBusinesses: businesses.length,
    viewedCount: businesses.filter(b => b.viewed).length
  };
}

// ✅ تسجيل "مرة واحدة تكفي" لاطلاع مشترك ماقما على بزنس معيّن — upsert (أول ضغطة
// بس بتتسجل، أي ضغطة تانية على نفس البزنس مالهاش أي أثر إضافي على العداد)
function markMagmaBusinessViewed(email, sheetId) {
  if (!email || !sheetId) return { error: 'بيانات ناقصة' };
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('MagmaViews');
  if (!sheet) return { error: 'شيت MagmaViews غير موجود' };
  const lower = email.toLowerCase();
  const finder = sheet.getLastRow() > 1
    ? sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).createTextFinder(email).matchEntireCell(true).matchCase(false)
    : null;
  if (finder) {
    const matches = finder.findAll();
    for (let i = 0; i < matches.length; i++) {
      const row = matches[i].getRow();
      if (String(sheet.getRange(row, 2).getValue()).trim() === String(sheetId).trim()) {
        return { status: 'already_viewed' }; // مسجّل من قبل — مفيش داعي نضيف صف تاني
      }
    }
  }
  sheet.appendRow([email, sheetId, new Date()]);
  return { status: 'recorded' };
}

// ─────────────────────────────────────────────
// ✅ جديد: باقة "ڤندكس" (Lavenders Oracle) — تقرير الأوراكل
// ─────────────────────────────────────────────
// ✅ إسقاط إحصائي بسيط (انحدار خطي — Least Squares) على سلسلة زمنية حقيقية —
// مش "ذكاء اصطناعي"، خوارزمية بسيطة ومباشرة بتعكس فعليًا اتجاه البيانات الأخيرة،
// مش رقم مخترع. بنستخدمها هنا وبس — واضح للمشترك إنه إسقاط إحصائي، مش ضمان.
function computeSimpleForecast(values) {
  const n = values.length;
  if (n < 4) return null;
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  values.forEach((y, x) => { sumX += x; sumY += y; sumXY += x * y; sumXX += x * x; });
  const denom = (n * sumXX - sumX * sumX) || 1;
  const slope = (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;
  const projected = Math.max(0, Math.round(intercept + slope * n)); // إسقاط النقطة اللي بعد آخر نقطة فعلية
  const first = values[0], last = values[n - 1];
  const growthPercent = first > 0 ? (((last - first) / first) * 100).toFixed(1) : '0.0';
  return {
    projectedNext: projected,
    growthPercent: growthPercent,
    direction: slope >= 0 ? 'صاعد 📈' : 'هابط 📉'
  };
}

// ✅ يبني نص تقرير الأوراكل لفترة معيّنة — من بيانات حقيقية بالكامل (DailyOrderStats
// الحقيقي + weights/topProducts/ordersByLocation الحيّة من getData) — صفر أرقام مخترعة.
function buildOracleReport(periodType) {
  const days = periodType === 'monthly' ? 30 : periodType === 'semiannual' ? 180 : 365;
  const periodNameAr = periodType === 'monthly' ? 'الشهري' : periodType === 'semiannual' ? 'نصف السنوي' : 'السنوي';
  const trend = getDailyOrderTrend(days);
  const liveData = getData();

  const totalOrders = trend.reduce((s, d) => s + d.orders, 0);
  const forecast = computeSimpleForecast(trend.map(d => d.orders));

  const topBusinesses = (liveData.weights || []).slice().sort((a, b) => b.weight - a.weight).slice(0, 5);
  const topProducts = (liveData.topProducts || []).slice(0, 5);
  const topLocations = (liveData.ordersByLocation || []).slice(0, 5);

  const lines = [];
  lines.push('🔮 تقرير الأوراكل ' + periodNameAr + ' — ' + CONFIG.INDEX_TICKER);
  lines.push('الفترة: آخر ' + days + ' يوم — بتاريخ ' + Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd'));
  lines.push('');
  lines.push('📊 إجمالي الطلبات في الفترة: ' + totalOrders.toLocaleString('en-US'));
  lines.push('📈 NAV الحالي: $' + liveData.index.NAV + ' (تغيّر ' + liveData.index.changePercent + '% منذ آخر تحديث)');
  if (forecast) {
    lines.push('🔮 الاتجاه العام: ' + forecast.direction + ' (' + forecast.growthPercent + '% خلال الفترة)');
    lines.push('🔮 إسقاط تقديري للطلبات اليومية القادمة: ~' + forecast.projectedNext + ' طلب/يوم');
  }
  lines.push('');
  lines.push('🏆 أعلى 5 أنشطة وزنًا بالمؤشر حاليًا:');
  topBusinesses.forEach((b, i) => lines.push('  ' + (i + 1) + '. ' + b.name + ' — ' + b.weight.toFixed(2) + '%'));
  if (topProducts.length) {
    lines.push('');
    lines.push('🔥 أكثر 5 منتجات طلبًا:');
    topProducts.forEach((p, i) => lines.push('  ' + (i + 1) + '. ' + p.name + ' (' + p.count + ' طلب)'));
  }
  if (topLocations.length) {
    lines.push('');
    lines.push('📍 أعلى المواقع طلبًا:');
    topLocations.forEach((l, i) => lines.push('  ' + (i + 1) + '. ' + l.location + ' — ' + l.count + ' طلب'));
  }
  lines.push('');
  lines.push('⚠️ الإسقاط أعلاه تقدير إحصائي مبني على اتجاه البيانات الفعلية الأخيرة، وليس ضمانًا أو نصيحة استثمارية.');
  lines.push('هذا التقرير حصري لمشتركي باقة ڤندكس (Lavenders Oracle) — ' + CONFIG.INDEX_TICKER);
  return lines.join('\n');
}

// ✅ يبعت تقرير الأوراكل لكل مشتركي ڤندكس النشطين فعليًا في لحظة الإرسال
// ✅ إصلاح: نفس مبدأ sendMonthlyEmailsToParticipants بالظبط — فشل الإرسال (مثلاً
// وصول MailApp لحده اليومي) ما بيتبلعش بصمت. مشترك ڤندكس بيدفع $1287، فسكوت
// النظام لو تقريره الحصري فشل يوصله مش مقبول — الأدمن لازم يعرف فورًا.
function sendOracleReportsToFendexSubscribers(periodType) {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Subscribers');
  if (!sheet || sheet.getLastRow() < 2) return { sent: 0, total: 0 };
  const data = sheet.getDataRange().getValues();
  const now = new Date();
  const emails = [];
  for (let i = 1; i < data.length; i++) {
    if (data[i][1] === 'fendex' && data[i][4] === 'active' && new Date(data[i][9]) > now) {
      emails.push(data[i][0]);
    }
  }
  if (emails.length === 0) return { sent: 0, total: 0 };

  const reportText = buildOracleReport(periodType);
  const periodNameAr = periodType === 'monthly' ? 'الشهري' : periodType === 'semiannual' ? 'نصف السنوي' : 'السنوي';
  let sentCount = 0;
  const failedEmails = [];
  emails.forEach(email => {
    try {
      const result = sendTransactionalEmail(email, '🔮 تقرير الأوراكل ' + periodNameAr + ' — ' + CONFIG.INDEX_TICKER, reportText);
      if (result.success) sentCount++; else failedEmails.push(email);
    } catch(e) {
      Logger.log('sendOracleReportsToFendexSubscribers: فشل إرسال لـ ' + email + ': ' + e);
      failedEmails.push(email);
    }
  });
  if (failedEmails.length > 0) {
    try {
      sendTransactionalEmail(CONFIG.ADMIN_EMAIL, CONFIG.INDEX_TICKER + ' - تنبيه: فشل إرسال ' + failedEmails.length + ' تقرير أوراكل (' + periodNameAr + ')',
        'فشل إرسال تقرير الأوراكل ' + periodNameAr + ' لـ ' + failedEmails.length + ' مشترك ڤندكس (على الأغلب وصلنا لحد MailApp اليومي).\n\n' +
        'الإيميلات المتأثرة:\n' + failedEmails.join('\n') + '\n\n' +
        'مشتركي ڤندكس بيدفعوا $' + CONFIG.FENDEX_PRICE_USD + ' — راجع تفعيل Resend (Script Properties → RESEND_API_KEY) لتفادي هذا مستقبلاً.');
    } catch(e) {}
  }
  logAudit('system_auto', 'oracle_report_sent', { periodType: periodType, recipientCount: emails.length, sentCount: sentCount, failedCount: failedEmails.length });
  return { sent: sentCount, total: emails.length };
}

// ✅ تريجر شهري واحد بيغطي الثلاث دورات المطلوبة (شهري/نصف سنوي/سنوي) — بيشتغل
// أول كل شهر ويبعت التقرير الشهري دايمًا، ويضيف نصف السنوي في يونيو/ديسمبر، والسنوي
// في ديسمبر بس. تصميم أبسط بدل تعقيد تريجرات منفصلة (Apps Script مفيهوش نوع
// تريجر "كل 6 شهور" جاهز أصلاً).
function checkOracleReports() {
  try {
    sendOracleReportsToFendexSubscribers('monthly');
    const month = parseInt(Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'M'), 10);
    if (month % 6 === 0) sendOracleReportsToFendexSubscribers('semiannual'); // يونيو وديسمبر
    if (month === 12) sendOracleReportsToFendexSubscribers('annual'); // ديسمبر بس
  } catch(err) {
    notifyAdminOfTriggerFailure('checkOracleReports', err);
    throw err;
  }
}

// ✅ شغّلها مرة واحدة يدويًا من محرر Apps Script عشان تفعّل تريجر تقرير الأوراكل
// الشهري — نفس مبدأ installAnalysisTrigger/installBackupTrigger بالظبط.
function installOracleReportTrigger() {
  ScriptApp.newTrigger('checkOracleReports').timeBased().onMonthDay(1).atHour(7).create();
  return 'تم تفعيل تريجر تقرير الأوراكل — هيتشغّل أول كل شهر الساعة 7 صباحًا (بتوقيت ' + CONFIG.TIMEZONE + ')';
}

// ✅ جديد: يتنادى بعد ما الأدمن يتواصل مع البزنس فعلياً بره النظام والبزنس يوافق
// إنه عايز يستلم استحقاقه — النظام يسجّل "قبل، وعليه يقدّم شيك ضمان الآن قبل أي
// تحويل فعلي". لسه ما يعتبرش مكتمل لحد ما confirmGuaranteeReceived تتنادى.
function markEntitlementAccepted(rowNum, adminEmail) {
  // ✅ إصلاح ثغرة سباق (race condition) — كانت موثّقة كمشكلة مفتوحة: بعكس
  // decideAdminPayment، الدالة دي ما كانتش محمية بقفل. قراءة currentStatus وكتابة
  // الحالة الجديدة بعدها مش عملية ذرية واحدة؛ لو الأدمن فتح الصفحة في تابين أو ضغط
  // الزرار مرتين بسرعة، الاتنين ممكن يقروا 'available' صحيحة قبل ما أي واحد يسجّل
  // 'accepted_awaiting_guarantee'، فيتعالج نفس الاستحقاق مرتين (سجل تدقيق مكرر
  // وربما إيميلات/قرارات متضاربة). نفس قفل decideAdminPayment بالظبط.
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return { error: 'الخادم مشغول حالياً — حاول تاني بعد لحظة' };
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Distributions');
    const row = parseInt(rowNum);
    if (!row || row < 2 || row > sheet.getLastRow()) return { error: 'صف غير موجود' };
    const currentStatus = sheet.getRange(row, 7).getValue();
    if (currentStatus !== 'available') {
      return { error: 'هذا الاستحقاق مش بحالة "متاح" (الحالة الحالية: ' + currentStatus + ')' };
    }
    const entitlement = parseFloat(sheet.getRange(row, 6).getValue()) || 0;
    const orders = parseInt(sheet.getRange(row, 9).getValue()) || 0;
    // ✅ إصلاح جوهري: الشيك المطلوب = المبلغ اللي النظام وجّهه فعلاً للبزنس من رأس
    // مال الصندوق حسب وزنه (entitlement) + النمو الحقيقي (36% من قيمة طلباته وقتها).
    // الكود القديم كان بيحسب الـ36% لوحدها بس وناسي يضيف entitlement نفسها.
    const growthAmount = parseFloat((orders * CONFIG.GUARANTEE_RATE * CONFIG.ORDER_VALUE).toFixed(2));
    const guaranteeAmount = parseFloat((entitlement + growthAmount).toFixed(2));
    sheet.getRange(row, 7).setValue('accepted_awaiting_guarantee');
    sheet.getRange(row, 10).setValue('awaiting_guarantee');
    const businessName = sheet.getRange(row, 4).getValue();
    logAudit(adminEmail || 'unknown_admin', 'entitlement_accepted', {row: row, business: businessName, contributionAmount: entitlement, growthAmount: growthAmount, guaranteeRequired: guaranteeAmount});
    return { status: 'accepted', contributionAmount: entitlement, growthAmount: growthAmount, guaranteeAmount: guaranteeAmount };
  } finally {
    lock.releaseLock();
  }
}

// ✅ جديد: التأكيد النهائي — يتنادى فقط بعد ما الأدمن يستلم شيك الضمان فعلياً بيده.
// بعد هذا التأكيد فقط، الاستحقاق يعتبر "مكتمل" والتحويل الفعلي للبزنس (يدوي بره
// النظام) يقدر يحصل. هذا الترتيب (ضمان قبل تحويل) هو الحماية الأساسية ضد الطلبات الوهمية.
function confirmGuaranteeReceived(rowNum, adminEmail) {
  // ✅ إصلاح ثغرة سباق حرجة — أخطر من markEntitlementAccepted لأن الدالة دي بتفتح
  // باب التحويل الفعلي للفلوس بره النظام وبتحسب حافز الـAP التراكمي فعليًا
  // (creditApIncentive، رقم مالي متراكم حقيقي). بدون قفل، تنفيذين شبه متزامنين على
  // نفس الصف ممكن الاتنين يقروا 'accepted_awaiting_guarantee' صحيحة قبل ما أي واحد
  // يسجّل 'completed'، فيتضاعف حافز الـAP فعليًا أو يتسجل نفس الاستحقاق "مكتمل" مرتين.
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return { error: 'الخادم مشغول حالياً — حاول تاني بعد لحظة' };
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('Distributions');
    const row = parseInt(rowNum);
    if (!row || row < 2 || row > sheet.getLastRow()) return { error: 'صف غير موجود' };
    const currentStatus = sheet.getRange(row, 7).getValue();
    if (currentStatus !== 'accepted_awaiting_guarantee') {
      return { error: 'هذا الاستحقاق مش بحالة "بانتظار ضمان" (الحالة الحالية: ' + currentStatus + ')' };
    }
    sheet.getRange(row, 7).setValue('completed');
    sheet.getRange(row, 8).setValue(new Date());
    sheet.getRange(row, 10).setValue('received');
    const businessName = sheet.getRange(row, 4).getValue();
    const entitlement = sheet.getRange(row, 6).getValue();
    // ✅ جديد: حافز الـAP الرمزي — نسبة من "النمو" بس (الـ36% المحسوبة من عدد طلبات
    // البزنس وقت هذا الاستحقاق تحديدًا)، مش من المساهمة الأصلية. راجع creditApIncentive.
    const orders = parseInt(sheet.getRange(row, 9).getValue()) || 0;
    const growthAmount = orders * CONFIG.GUARANTEE_RATE * CONFIG.ORDER_VALUE;
    const apIncentive = parseFloat((growthAmount * CONFIG.AP_INCENTIVE_RATE).toFixed(2));
    const defaultApCode = Object.keys(AUTHORIZED_PARTICIPANTS)[0]; // ⚠️ AP واحد بس حاليًا
    if (defaultApCode) creditApIncentive(defaultApCode, apIncentive);
    logAudit(adminEmail || 'unknown_admin', 'guarantee_confirmed', {row: row, business: businessName, entitlement: entitlement, apIncentive: apIncentive});
    return { status: 'completed' };
  } finally {
    lock.releaseLock();
  }
}

function getAdminAuditLog() {
  const sheet = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID).getSheetByName('AuditLog');
  if (!sheet || sheet.getLastRow() < 2) return { rows: [] };
  const lastRow = sheet.getLastRow();
  const startRow = Math.max(2, lastRow - 99);
  const data = sheet.getRange(startRow, 1, lastRow - startRow + 1, 4).getValues();
  const rows = data.map(r => ({ timestamp: r[0], actor: r[1], action: r[2], details: r[3] })).reverse();
  return { rows: rows };
}

// ✅ جديد: قرار الأدمن الفعلي (approve/reject) — يكتب الحالة ويطبّقها فوراً
// بدل ما ينتظر processApprovedPayments يشتغل بالـ trigger الساعي.
function decideAdminPayment(rowNum, decision, adminEmail) {
  if (!['approved', 'rejected'].includes(decision)) return { error: 'قرار غير صالح' };
  // ✅ جديد: قفل دفاعي — بدونه، قراءة currentStatus وكتابة decision بعدها مش عملية
  // ذرية واحدة؛ نقرتين شبه متزامنتين على نفس الطلب ممكن الاتنين يعدّوا نفس الحالة
  // 'awaiting_review' صحيحة قبل ما أي واحد يسجّل القرار، فيتعالج نفس الطلب مرتين.
  const lock = LockService.getScriptLock();
  let gotLock = false;
  try { gotLock = lock.tryLock(10000); } catch(e) {}
  if (!gotLock) return { error: 'الخادم مشغول حالياً — حاول تاني بعد لحظة' };
  try {
    const master = SpreadsheetApp.openById(CONFIG.MASTER_SHEET_ID);
    const sheet = master.getSheetByName('PendingPayments');
    const row = parseInt(rowNum);
    if (!row || row < 2 || row > sheet.getLastRow()) return { error: 'صف غير موجود' };
    const currentStatus = sheet.getRange(row, 6).getValue();
    if (currentStatus !== 'awaiting_review') {
      return { error: 'هذا الطلب اتقرر فيه بالفعل (' + currentStatus + ')' };
    }
    sheet.getRange(row, 6).setValue(decision);
    logAudit(adminEmail || 'unknown_admin', 'admin_decided_payment', {row: row, decision: decision});
  } finally {
    lock.releaseLock();
  }
  processApprovedPayments(); // يطبّق القرار فوراً بدل انتظار التريجر (قفلها الخاص منفصل)
  return { status: 'done', decision: decision };
}


function doGet(e) {

  // ── طلبات البيانات من GAS مباشرة (data/month/basket/participant/market)
  //    محمية بـ API_KEY + token معاً
  if (e.parameter.action) {
    // التحقق من API_KEY
    if (e.parameter.key !== CONFIG.API_KEY) {
      return ContentService.createTextOutput(JSON.stringify({error:'Unauthorized'}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // ✅ جديد: كل الـ actions تحتاج token دلوقتي (حتى data) — قررنا نقفل كل حاجة خلف تسجيل
    // دخول Google، لأن فيه دلوقتي طبقة "مشاهدين" مدفوعة (لافا/سنوي) لازم تتفلتر عن الزوار
    // اللي سجلوا دخول بس لسه ما اشتركوا، وعن أي زائر غير مسجل خالص.
    const token = e.parameter.token || '';
    if (!token) {
      return ContentService.createTextOutput(JSON.stringify({error:'Token required', code:401}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    const tokenEmail = verifyToken(token);
    if (!tokenEmail) {
      return ContentService.createTextOutput(JSON.stringify({error:'Invalid token', code:401}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    const role = getUserRole(tokenEmail);

    // ✅ جديد: try/catch عام (نفس مبدأ doPost) — بدونه أي استثناء غير متوقع هنا
    // (زي رسالة "النظام مشغول" من getData، أو أي خطأ Sheets API عابر) كان يرجّع
    // صفحة خطأ HTML خام من جوجل للعميل بدل رد JSON نضيف، وبدون أي تسجيل داخلي.
    try {

    if (e.parameter.action === 'agreement_form') {
      return ContentService.createTextOutput(JSON.stringify(getAgreementForm(tokenEmail, e.parameter.sheetId)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (e.parameter.action === 'my_progress') {
      return ContentService.createTextOutput(JSON.stringify(getUserProgress(tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (e.parameter.action === 'data') {
      // ✅ visitor (سجّل دخول بس لسه ما اشترك) ما يشوفش بيانات المؤشر — لازم يشترك الأول
      if (role === 'visitor' || role === 'movement') { // movement = نفس تجربة الزائر: لا بيانات حقيقية
        return ContentService.createTextOutput(JSON.stringify({error:'subscription_required', code:402}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      const payload = getData();
      payload.role = role; // ✅ جديد: الفرونت اند يقدر يبني واجهة صحيحة حسب الدور بدل ما يخمّن من شكل البيانات
      // ✅ إصلاح ثغرة خصوصية: أي دور "مطالعة" (لافا/سنوي/فندكس/ماقما) مفروض يشوف
      // بيانات المؤشر فقط، وليس السوق الداخلي — ده حصري للمشاركين الفعليين (الـ120)
      // والأدمن. لكن fund.market (اللي فيها إيميلات البائعين) كانت تترجع لأي دور غير
      // visitor — يعني أي مشترك كان يقدر يشوف إيميلات مشاركين حقيقيين بالسوق الداخلي.
      // action=market المنفصل كان محمي صح، لكن نفس البيانات كانت متسربة من هنا.
      if (['subscriber', 'fendex', 'magma'].includes(role) && payload.fund) {
        payload.fund = Object.assign({}, payload.fund, { market: [] });
      }
      // ✅ إصلاح ثغرة: تم حذف دعم JSONP (?callback=) نهائياً — الفرونت اند بيستخدم
      // fetch()+CORS عبر الـ Worker وليس <script src>، فمفيش أي استخدام شرعي له.
      // القيمة القديمة كانت تُرجّع كما هي حرفياً كـ JavaScript قابل للتنفيذ
      // (Content-Type: application/javascript) بدون أي تحقق — أي حد يقدر يمرر
      // ?callback=alert(document.cookie)// ويخلي الرد كله كود جافاسكربت جاهز للتنفيذ
      // لو حد ضمّن الرابط ده كـ <script src> بصفحة تانية. حذفها أأمن من محاولة تنقيتها.
      return ContentService.createTextOutput(JSON.stringify(payload))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'month') {
      if (role === 'visitor' || role === 'movement') {
        return ContentService.createTextOutput(JSON.stringify({error:'subscription_required', code:402}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      const month = e.parameter.month;
      const snap  = getMonthlySnapshots().find(s => s.month === month);
      return ContentService.createTextOutput(JSON.stringify({
        mode:'historical', month:month, snapshot:snap||null, history:getHistoricalData(month)
      })).setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'basket') {
      // ✅ بيانات آلية إنشاء/استرداد الوحدات — خاصة بالمشاركين/AP فقط، مش جزء من اشتراك المطالعة
      if (role !== 'participant' && role !== 'admin') {
        return ContentService.createTextOutput(JSON.stringify({error:'غير مصرح', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      const basketData = generateBasketFile(getBusinessCountsArray());
      return ContentService.createTextOutput(JSON.stringify({
        indexTicker:CONFIG.INDEX_TICKER,
        asOf:Utilities.formatDate(new Date(),CONFIG.TIMEZONE,"yyyy-MM-dd'T'HH:mm:ss"),
        settlementDate:getSettlementDate(), settlementCycle:'T+'+CONFIG.SETTLEMENT_DAYS,
        ordersPerUnit:CONFIG.ORDERS_PER_UNIT, basket:basketData.basket, cashInLieu:basketData.cashComponent
      })).setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'terms') {
      // ✅ جديد: متاحة حتى لـvisitor (بعكس bank_details) — المستخدم محتاج يشوف
      // الشروط قبل أي قرار اشتراك أو شراء، يعني قبل ما يبقى حتى subscriber
      return ContentService.createTextOutput(JSON.stringify({
        tier: String(e.parameter.tier || ''),
        text: getTermsText(e.parameter.tier),
        version: CONFIG.TERMS_VERSION,
        accepted: hasAcceptedTerms(tokenEmail, e.parameter.tier)
      })).setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'bank_details') {
      // ✅ جديد: مصدر الحقيقة الوحيد لبيانات الحساب البنكي — كانت مكتوبة يدويًا مرتين
      // (هنا في CONFIG.BANK_DETAILS، ونسخة ثانية hardcoded في dashboard.html كنص ثابت).
      // أي مستخدم مسجّل دخول (participant/subscriber/admin) يقدر يشوفها؛ visitor لأ
      // (لسه ما اشتركش، مش محتاجها).
      if (role === 'visitor') {
        return ContentService.createTextOutput(JSON.stringify({error:'subscription_required', code:402}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(CONFIG.BANK_DETAILS))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'participant') {
      const email = e.parameter.email;
      if (!email) return ContentService.createTextOutput(JSON.stringify({error:'email required'}))
        .setMimeType(ContentService.MimeType.JSON);
      // ✅ إصلاح ثغرة IDOR حرجة: كان أي مستخدم بتوكن صالح يقدر يشوف بيانات محفظة/ربح أي
      // مشارك تاني بس بمعرفة إيميله (data[i][email] كان يُقرأ من query param مباشرة بدون
      // مطابقته مع صاحب التوكن). دلوقتي لازم يكون إيميلك نفسه، أو تكون أدمن.
      if (email.toLowerCase() !== tokenEmail.toLowerCase() && role !== 'admin') {
        return ContentService.createTextOutput(JSON.stringify({error:'غير مصرح', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      const info = getParticipantInfo(email);
      if (info) return ContentService.createTextOutput(JSON.stringify(info)).setMimeType(ContentService.MimeType.JSON);
      const pending = getPendingPaymentStatus(email); // ✅ جديد: يورّي حالة "بانتظار OTP/المراجعة" بدل "not found"
      return ContentService.createTextOutput(JSON.stringify(pending || {error:'not found'}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'my_businesses') {
      // ✅ جديد: يستخدم getBusinessesByEmail — مفيد لأي واجهة (أندرويد/WebView/PWA)
      // تحتاج تعرض "البزنسات المسجّلة بإيميلي" (بزنس ممكن يملك أكتر من شيت نظرياً).
      // نفس حماية IDOR بتاعة action=participant بالظبط.
      const email = e.parameter.email;
      if (!email) return ContentService.createTextOutput(JSON.stringify({error:'email required'}))
        .setMimeType(ContentService.MimeType.JSON);
      if (email.toLowerCase() !== tokenEmail.toLowerCase() && role !== 'admin') {
        return ContentService.createTextOutput(JSON.stringify({error:'غير مصرح', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify({businesses: getBusinessesByEmail(email)}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // ✅ جديد: بورتال البزنس المنفصل (business.html) — دايماً يقرأ بيانات tokenEmail نفسه
    // (ما فيش email كـ query param هنا أصلاً، فمفيش سطح IDOR جديد للتحقق منه).
    if (e.parameter.action === 'my_business_portal') {
      return ContentService.createTextOutput(JSON.stringify(getMyBusinessPortalData(tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // ✅ جديد: دليل الـ120 نشاط — حصري لمشتركي باقة ماقما (والأدمن للمراجعة/الاختبار).
    // دايماً يقرأ بيانات tokenEmail نفسه (نفس مبدأ my_business_portal، مفيش IDOR).
    if (e.parameter.action === 'magma_directory') {
      if (role !== 'magma' && role !== 'admin') {
        return ContentService.createTextOutput(JSON.stringify({error:'هذه الميزة حصرية لمشتركي باقة ماقما', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(getMagmaDirectory(tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'market') {
      // ✅ السوق الداخلي (بيع/شراء حصص بين المشاركين) خاص بالمشاركين فقط — مش "المشاهدين"
      if (role !== 'participant' && role !== 'admin') {
        return ContentService.createTextOutput(JSON.stringify({error:'غير مصرح', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(getMarket()))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ حالة دفع الفرانشايز للعضو نفسه (أرقام الدفع فقط)
    if (e.parameter.action === 'franchise_status') {
      return ContentService.createTextOutput(JSON.stringify(getFranchiseStatus(tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'subscription_status') {
      return ContentService.createTextOutput(JSON.stringify(getSubscriptionStatus(tokenEmail, e.parameter.tier, e.parameter.country)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (e.parameter.action === 'my_subscriptions') {
      return ContentService.createTextOutput(JSON.stringify(getMySubscriptions(tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ── Admin actions: تتطلب token صالح + إن الإيميل ضمن ADMIN_PANEL_EMAILS ──
    if (e.parameter.action === 'admin_pending_payments' || e.parameter.action === 'admin_participants'
        || e.parameter.action === 'admin_pending_subscriptions' || e.parameter.action === 'admin_audit_log'
        || e.parameter.action === 'admin_entitlements' || e.parameter.action === 'admin_business_list'
        || e.parameter.action === 'ap_earnings' || e.parameter.action === 'subscriber_capacity'
        || e.parameter.action === 'admin_waitlist' || e.parameter.action === 'admin_franchises'
        || e.parameter.action === 'admin_oms_members' || e.parameter.action === 'admin_business_requests') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_pending_payments') {
        return ContentService.createTextOutput(JSON.stringify(getAdminPendingPayments()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_pending_subscriptions') {
        return ContentService.createTextOutput(JSON.stringify(getAdminPendingSubscriptions()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_audit_log') {
        return ContentService.createTextOutput(JSON.stringify(getAdminAuditLog()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_entitlements') {
        return ContentService.createTextOutput(JSON.stringify(getBusinessEntitlements()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_business_requests') {
        return ContentService.createTextOutput(JSON.stringify(getAdminBusinessRequests()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_oms_members') {
        return ContentService.createTextOutput(JSON.stringify(getAdminOmsMembers()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_business_list') {
        return ContentService.createTextOutput(JSON.stringify(getAdminBusinessList()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      // ✅ جديد: حافز الـAP التراكمي (رمزي — راجع creditApIncentive)
      if (e.parameter.action === 'ap_earnings') {
        return ContentService.createTextOutput(JSON.stringify({rows: getApEarnings()}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      // ✅ جديد: قائمة الانتظار — مشتركين مستنيين اكتمال السوق (120 نشاط)
      if (e.parameter.action === 'admin_franchises') {
        return ContentService.createTextOutput(JSON.stringify(getAdminFranchises()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === 'admin_waitlist') {
        return ContentService.createTextOutput(JSON.stringify(getAdminWaitlist()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      // ✅ جديد: الطاقة الاستيعابية الحالية لباقتي الاشتراك (لافا/سنوي) — كام
      // مشترك نشط دلوقتي مقابل السقف المسموح به لكل باقة
      if (e.parameter.action === 'subscriber_capacity') {
        return ContentService.createTextOutput(JSON.stringify(getSubscriberCapacity()))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(getAdminParticipants()))
        .setMimeType(ContentService.MimeType.JSON);
    }

    return ContentService.createTextOutput(JSON.stringify({error:'Unknown action'}))
      .setMimeType(ContentService.MimeType.JSON);

    } catch(err) {
      // ✅ رسالة "النظام مشغول" من getData() مفيدة وآمنة نعرضها زي ما هي؛ أي حاجة
      // تانية (استثناء داخلي غير متوقع) نسجّلها في Logger بس ونرجّع رسالة عامة للعميل.
      const msg = (err && err.message === 'النظام مشغول بتحديث البيانات حالياً — حاول تاني بعد لحظة')
        ? err.message : 'حدث خطأ غير متوقع — حاول تاني';
      if (msg === 'حدث خطأ غير متوقع — حاول تاني') {
        Logger.log('doGet error: ' + err + (err && err.stack ? ('\n' + err.stack) : ''));
      }
      return ContentService.createTextOutput(JSON.stringify({error: msg}))
        .setMimeType(ContentService.MimeType.JSON);
    }
  }

  // ── طلب بدون action ولا mode ──
  // ✅ الداشبورد ما عاد يُقدَّم من هنا: الفرونت اند بقى ملف static على GitHub Pages
  // (يتواصل مع هذا الـ Web App عبر Cloudflare Worker). هذا الرابط (رابط GAS نفسه)
  // ما ينفعش يتفتح مباشرة من متصفح المستخدم — فقط الـ Worker يناديه بـ action محدد.
  return ContentService.createTextOutput(JSON.stringify({
    error: 'هذا الرابط API فقط — افتح الداشبورد من رابط الموقع الرسمي.'
  })).setMimeType(ContentService.MimeType.JSON);
}



function doPost(e) {
  if (e.parameter.key !== CONFIG.API_KEY) {
    return ContentService.createTextOutput(JSON.stringify({error:'Unauthorized'}))
      .setMimeType(ContentService.MimeType.JSON);
  }

  try {
    const data = JSON.parse(e.postData.contents);

    // ✅ جديد: تسجيل الدخول — يستقبل Google ID Token من GSI (الفرونت اند)، يتحقق من توقيعه
    // فعلياً عبر جوجل (verifyGoogleIdToken)، وبعدين يصدر توكن جلسة (session token) قصير العمر
    // عبر نفس آلية issueToken. لا يوجد هنا أي طريقة لتزوير الهوية — التحقق كامل من جهة جوجل.
    if (data.action === 'login') {
      const email = verifyGoogleIdToken(data.idToken);
      if (!email) {
        return ContentService.createTextOutput(JSON.stringify({error:'Invalid Google token'}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      // ✅ تغيير مهم: أي حساب Google حقيقي يقدر يسجّل دخول دلوقتي (حتى لو مش مشارك ولا
      // مشترك بعد) — عشان يقدر يشترك في لافا/الباقة السنوية أصلاً. الفلترة الحقيقية
      // بتحصل بعدين على مستوى كل action لوحده حسب getUserRole().
      const sessionToken = issueToken(email);
      return ContentService.createTextOutput(JSON.stringify({
        token: sessionToken, email: email, role: getUserRole(email)
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // التحقق من token في كل POST (لكل الـ actions ما عدا login)
    const token = data.token || e.parameter.token || '';
    if (!token) {
      return ContentService.createTextOutput(JSON.stringify({error:'Token required', code:401}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // التحقق من صحة التوكن — محلياً عبر verifyToken (نفس نظام التوكن الذي يُصدره issueToken في doGet)
    // ✅ إصلاح حرج: كان هذا سابقاً يستدعي Render (UrlFetchApp.fetch(CONFIG.RENDER_URL + '/data', ...))
    // للتحقق من التوكن. لكن توكنات GAS (UUID عبر CacheService) لا علاقة لها إطلاقاً بجلسات
    // Render الخاصة (والتي كانت أصلاً تُنشأ فقط عبر تدفق OAuth/Firebase منفصل تماماً في app.py).
    // نتيجة ذلك: كل عملية شراء/بيع/AP كانت تُرفض دائماً بـ "Invalid token" مهما كان المستخدم
    // مصرحاً له فعلياً. التحقق الآن محلي بالكامل داخل نفس ملف الـ.gs.
    const tokenEmail = verifyToken(token);
    if (!tokenEmail) {
      return ContentService.createTextOutput(JSON.stringify({error:'Invalid token', code:401}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // تأمين إضافي: الإيميل المُرسل بالطلب يجب أن يطابق صاحب التوكن فعلاً
    if (data.email && data.email.toLowerCase() !== tokenEmail.toLowerCase()) {
      return ContentService.createTextOutput(JSON.stringify({error:'Token/email mismatch', code:401}))
        .setMimeType(ContentService.MimeType.JSON);
    }

    const role = getUserRole(tokenEmail);

    // ✅ جديد: طلب اشتراك لافا/سنوي — أي مستخدم مسجّل دخول (حتى visitor) يقدر يشترك
    if (data.action === 'subscribe') {
      if (!data.tier) return ContentService.createTextOutput(JSON.stringify({error:'tier required'}))
        .setMimeType(ContentService.MimeType.JSON);
      // ✅ جديد: نفس فحص الموافقة على الشروط — الاشتراك برضو التزام مالي حقيقي
      if (!hasAcceptedTerms(tokenEmail, data.tier)) {
        return ContentService.createTextOutput(JSON.stringify({error:'terms_required', code:451, tier:data.tier}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(subscribeLava(tokenEmail, data.tier, data.country)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // ✅ زر "ادفع" للفرانشايز — يتطلب عضوية فرانشايز نشطة (يتحقق منها payFranchiseInstallment)
    if (data.action === 'franchise_pay') {
      if (!hasAcceptedTerms(tokenEmail, 'franchise')) {
        return ContentService.createTextOutput(JSON.stringify({error:'terms_required', code:451, tier:'franchise'}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(payFranchiseInstallment(tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'admin_set_franchise_businesses') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(setFranchiseBusinessesAdded(data.email, data.count, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'subscription_prepay') {
      if (!data.tier) return ContentService.createTextOutput(JSON.stringify({error:'tier required'})).setMimeType(ContentService.MimeType.JSON);
      if (!hasAcceptedTerms(tokenEmail, data.tier)) {
        return ContentService.createTextOutput(JSON.stringify({error:'terms_required', code:451, tier:data.tier})).setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(prepaySubscription(tokenEmail, data.tier, data.country)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'verify_subscription') {
      if (!data.otp || !data.txnRef) {
        return ContentService.createTextOutput(JSON.stringify({error:'otp و txnRef مطلوبة'}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(submitSubscriptionVerification(tokenEmail, data.otp, data.txnRef, data.tier, data.country)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ تسجيل توكن جهاز الهاتف لاستقبال الإشعارات (أي مستخدم مسجّل دخول)
    if (data.action === 'register_device') {
      return ContentService.createTextOutput(JSON.stringify(registerDeviceToken(tokenEmail, data.fcmToken)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'accept_terms') {
      const tInfo = tierInfo(data.tier);
      if (data.tier !== 'business_agreement' && (!tInfo || tInfo.internal)) {
        return ContentService.createTextOutput(JSON.stringify({error:'tier required'})).setMimeType(ContentService.MimeType.JSON);
      }
      recordConsent(tokenEmail, data.tier);
      return ContentService.createTextOutput(JSON.stringify({status: 'accepted', tier: data.tier, version: CONFIG.TERMS_VERSION}))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (data.action === 'buy') {
      // ✅ جديد: قفل حرج — buyShare() نفسها ما كانت بتتحقق إن الإيميل من الـ120 المصرح
      // لهم أصلاً (AllowedEmails). بعد ما فتحنا تسجيل الدخول لأي حساب Google (لطبقة
      // المشاهدين)، أي "visitor" أو "subscriber" عنده توكن صالح كان يقدر يستدعي buy
      // ويسجّل نفسه كمشارك حقيقي بحصة فعلية بالصندوق. دلوقتي لازم يكون role === participant.
      if (role !== 'participant') {
        return ContentService.createTextOutput(JSON.stringify({error:'هذا الحساب مش من ضمن الـ120 المصرح لهم بشراء حصة', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      // ✅ جديد: فحص حقيقي في الباك اند — لولاه، الموافقة على الشروط كانت (لو اتفعّلت
      // بالفرونت اند بس) مجرد شاشة تُتخطى بسهولة عبر طلب API مباشر بدون المرور عليها
      if (!hasAcceptedAgreement(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'terms_required', code:451, tier:'business_agreement'}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (!data.email) return ContentService.createTextOutput(JSON.stringify({error:'email required'}))
        .setMimeType(ContentService.MimeType.JSON);
      return ContentService.createTextOutput(JSON.stringify(buyShare(data.email, data.marketRow)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'sell') {
      // ✅ نفس القفل: بيع حصة لازم يكون من مشارك حقيقي فعلاً، مش أي توكن صالح
      if (role !== 'participant') {
        return ContentService.createTextOutput(JSON.stringify({error:'هذا الحساب مش مشارك فعلي بالصندوق', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (!data.email) return ContentService.createTextOutput(JSON.stringify({error:'email required'}))
        .setMimeType(ContentService.MimeType.JSON);
      return ContentService.createTextOutput(JSON.stringify(sellShare(data.email)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // ✅ جديد: تأكيد الدفع (OTP + رقم المعاملة) — نستخدم tokenEmail المُتحقق منه، مو أي إيميل يُرسله العميل
    if (data.action === 'verify_payment') {
      if (!data.otp || !data.txnRef) {
        return ContentService.createTextOutput(JSON.stringify({error:'otp و txnRef مطلوبة'}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(submitPaymentVerification(tokenEmail, data.otp, data.txnRef)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: قرار الأدمن باعتماد/رفض دفعة — محمي بـ isAdminAuthorized، مستقل عن أي مشارك عادي
    if (data.action === 'admin_decide_payment') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(decideAdminPayment(data.row, data.decision, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: قرار الأدمن باعتماد/رفض اشتراك لافا/سنوي
    if (data.action === 'admin_decide_subscription') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(decideAdminSubscription(data.row, data.decision, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (data.action === 'save_agreement_fields' || data.action === 'save_agreement_sig' || data.action === 'submit_agreement_form') {
      const r2 = data.action === 'save_agreement_fields' ? saveAgreementFields(tokenEmail, data.sheetId, data.fields)
        : data.action === 'save_agreement_sig' ? saveAgreementSig(tokenEmail, data.sheetId, data.key, data.data)
        : submitAgreementForm(tokenEmail, data.sheetId);
      return ContentService.createTextOutput(JSON.stringify(r2)).setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'save_progress') {
      return ContentService.createTextOutput(JSON.stringify(saveUserProgress(tokenEmail, data.state)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // ✅ البزنس يرفع رابط الاتفاقية الموقعة / يطلب كاش تشغيلي (ملكية البزنس تُفحص داخل الدالة)
    if (data.action === 'submit_agreement' || data.action === 'request_cash') {
      const res = data.action === 'submit_agreement'
        ? submitAgreementLink(tokenEmail, data.sheetId, data.link)
        : requestCash(tokenEmail, data.sheetId);
      return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'decide_business_request') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(decideBusinessRequest(data.row, data.decision, data.amount, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: الأدمن يربط بزنس (SheetID) بإيميل صاحبه — لما يسجّل دخول لأول مرة
    if (data.action === 'link_business') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(linkBusinessToEmail(data.sheetId, data.email, data.businessName, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: الأدمن يحدّد فئة البزنس ورابطه الخارجي — أساس دليل ماقما
    if (data.action === 'set_business_category_link') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(setBusinessCategoryAndLink(data.sheetId, data.category, data.link, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: إغلاق/إعادة فتح بزنس منطقيًا — لما بزنس حقيقي يقفل أو الإغلاق يتراجع عنه
    if (data.action === 'close_business') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(closeBusinessAccount(data.sheetId, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (data.action === 'reopen_business') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(reopenBusinessAccount(data.sheetId, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: تغيير إعداد القبول التلقائي/اليدوي لبزنس معيّن — متاح في أي وقت
    if (data.action === 'set_auto_accept') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(setAutoAcceptPreference(data.sheetId, data.enabled, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: البزنس نفسه (من business.html) يغيّر إعداد القبول التلقائي/اليدوي لحسابه
    // هو بالذات — مش أي admin action. حماية IDOR: sheetId المطلوب لازم يكون من ضمن
    // البزنسات المربوطة فعلياً بـ tokenEmail (getBusinessesByEmail)، وإلا أي بزنس كان
    // يقدر يغيّر إعداد بزنس تاني بس بمعرفة sheetId بتاعه.
    // ⚠️ قرار متعمّد: البزنس نفسه ما يقدرش يستدعي accept_entitlement/confirm_guarantee —
    // ديه سايبينها admin-only لأن التصميم الأصلي يعتمد على "تواصل فعلي" بشري كطبقة
    // حماية ضد الغش قبل أي قبول استحقاق، مش مجرد ضغطة زرار من نفس الحساب اللي سجّل الطلبات.
    if (data.action === 'set_my_auto_accept') {
      const myBusinesses = getBusinessesByEmail(tokenEmail).map(b => b.sheetId);
      if (!myBusinesses.includes(String(data.sheetId).trim())) {
        return ContentService.createTextOutput(JSON.stringify({error:'هذا البزنس مش مربوط بحسابك', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(setAutoAcceptPreference(data.sheetId, data.enabled, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: مشترك ماقما يسجّل إنه اطّلع على بزنس معيّن من الدليل (مرة واحدة تكفي)
    if (data.action === 'magma_mark_viewed') {
      if (role !== 'magma' && role !== 'admin') {
        return ContentService.createTextOutput(JSON.stringify({error:'هذه الميزة حصرية لمشتركي باقة ماقما', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      if (!data.sheetId) return ContentService.createTextOutput(JSON.stringify({error:'sheetId مطلوب'}))
        .setMimeType(ContentService.MimeType.JSON);
      return ContentService.createTextOutput(JSON.stringify(markMagmaBusinessViewed(tokenEmail, data.sheetId)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: الأدمن يسجّل إن البزنس قبل استلام استحقاقه (بعد تواصل فعلي بره النظام)
    // — يفتح مطالبة شيك الضمان
    if (data.action === 'accept_entitlement') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(markEntitlementAccepted(data.row, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // ✅ جديد: الأدمن يؤكد استلام شيك الضمان فعلياً بيده — هذا التأكيد فقط يخلّي
    // الاستحقاق "مكتمل" ويسمح بالتحويل الفعلي (يدوي بره النظام) للبزنس
    if (data.action === 'confirm_guarantee') {
      if (!isAdminAuthorized(tokenEmail)) {
        return ContentService.createTextOutput(JSON.stringify({error:'ما عندك صلاحية أدمن', code:403}))
          .setMimeType(ContentService.MimeType.JSON);
      }
      return ContentService.createTextOutput(JSON.stringify(confirmGuaranteeReceived(data.row, tokenEmail)))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // AP Orders (إنشاء/استرداد وحدات بالجملة من أطراف مخوّلة)
    const apCode = data.apCode;
    const type   = data.type;
    const units  = parseInt(data.units);
    // ✅ إصلاح: AUTHORIZED_PARTICIPANTS/AP_AUTHORIZED_EMAILS كائنات JS عادية، فلو apCode
    // كانت قيمة زي 'constructor' أو 'toString' أو '__proto__'، الوصول بـ[] كان يرجّع
    // دالة موروثة من Object/Function.prototype (truthy) بدل undefined — يعني الفحص
    // !AUTHORIZED_PARTICIPANTS[apCode] كان يتجاوَز غلط. استخدمنا hasOwnProperty صراحةً.
    const hasAP = Object.prototype.hasOwnProperty.call(AUTHORIZED_PARTICIPANTS, apCode || '');
    if (!hasAP||!['CREATE','REDEEM'].includes(type)||units<=0||units>10000) {
      return ContentService.createTextOutput(JSON.stringify({error:'Invalid AP or units'}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    // ✅ جديد: قفل حرج — بدون هذا، أي مشارك عادي عنده token صالح (وليس AP فعلي) كان
    // يقدر يستدعي processAPOrder بأي apCode ويسجّل طلبات إنشاء/استرداد وهمية بالآلاف.
    const authorizedEmail = Object.prototype.hasOwnProperty.call(AP_AUTHORIZED_EMAILS, apCode)
      ? String(AP_AUTHORIZED_EMAILS[apCode]) : '';
    if (authorizedEmail.toLowerCase() !== tokenEmail.toLowerCase()) {
      return ContentService.createTextOutput(JSON.stringify({error:'هذا الحساب غير مخوّل لتنفيذ أوامر AP', code:403}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    return ContentService.createTextOutput(JSON.stringify(processAPOrder(apCode, type, units)))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    // ✅ إصلاح تسريب معلومات: err.toString() الخام كان يترجع للعميل مباشرة — ممكن
    // يكشف تفاصيل داخلية (أسماء دوال، رسائل Sheets API، إلخ) لأي حد عنده API key
    // صالح. دلوقتي التفاصيل تتسجل في Logger (يشوفها الأدمن بس من Executions log)
    // والعميل ياخد رسالة عامة فقط.
    Logger.log('doPost error: ' + err + (err && err.stack ? ('\n' + err.stack) : ''));
    return ContentService.createTextOutput(JSON.stringify({error:'حدث خطأ غير متوقع — حاول تاني'}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
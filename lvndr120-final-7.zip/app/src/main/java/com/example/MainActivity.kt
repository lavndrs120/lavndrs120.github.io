package com.example

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.service.LavndrFirebaseMessagingService
import com.example.ui.LavndrApp
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.messaging.FirebaseMessaging

// ✅ إصلاح: كانت FragmentActivity لغرض واحد بس — BiometricPrompt (قفل التطبيق
// بالبصمة). بعد إلغاء الميزة دي بالكامل بطلب صريح، رجّعناها لـ ComponentActivity
// العادية (أخف، ومفيش أي API تاني بالملف ده محتاج FragmentActivity تحديدًا).
class MainActivity : ComponentActivity() {

  private val requestPermissionLauncher = registerForActivityResult(
    ActivityResultContracts.RequestPermission()
  ) { isGranted: Boolean ->
    if (isGranted) {
      Log.d("MainActivity", "Notification permission granted")
    } else {
      Log.d("MainActivity", "Notification permission denied")
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    createNotificationChannels()
    askNotificationPermission()
    subscribeToTopics()

    setContent {
      MyApplicationTheme {
        LavndrApp()
      }
    }
  }

  private fun createNotificationChannels() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
      val audioAttributes = AudioAttributes.Builder()
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
        .build()

      val paymentsChannel = NotificationChannel(
        LavndrFirebaseMessagingService.CHANNEL_PAYMENTS_ID,
        "تأكيدات المدفوعات والحصص",
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = "إشعارات اعتماد تحويلات الحصص والـ OTP"
        enableLights(true)
        enableVibration(true)
        vibrationPattern = longArrayOf(0, 200, 100, 200)
        setSound(soundUri, audioAttributes)
      }

      val marketChannel = NotificationChannel(
        LavndrFirebaseMessagingService.CHANNEL_MARKET_ID,
        "تحديثات السوق والمؤشر",
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = "إشعارات حركة أسعار المؤشر LAVNDR120 وتحديثات الأوزان"
        enableLights(true)
        enableVibration(true)
        vibrationPattern = longArrayOf(0, 250, 150, 250)
        setSound(soundUri, audioAttributes)
      }

      notificationManager.createNotificationChannel(paymentsChannel)
      notificationManager.createNotificationChannel(marketChannel)
    }
  }

  private fun askNotificationPermission() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
      }
    }
  }

  private fun subscribeToTopics() {
    try {
      FirebaseMessaging.getInstance().subscribeToTopic("market_updates")
        .addOnCompleteListener { task ->
          if (task.isSuccessful) {
            Log.d("MainActivity", "Subscribed to market_updates topic")
          }
        }
      FirebaseMessaging.getInstance().subscribeToTopic("payment_confirmations")
        .addOnCompleteListener { task ->
          if (task.isSuccessful) {
            Log.d("MainActivity", "Subscribed to payment_confirmations topic")
          }
        }
    } catch (e: Exception) {
      Log.e("MainActivity", "Error subscribing to FCM topics", e)
    }
  }
}



package com.example.data.model

object PreviewDataProvider {

  fun getPreviewData(): LavndrData {
    val sampleCategories = listOf(
      "سوبرماركت ومواد غذائية" to listOf("أسواق الراية", "سوبرماركت البركة", "مخابز الأمل الحديثة", "مطاحن النيلين", "مزارع الوادي لمنتجات الألبان", "شركة المحاصيل الذهبية", "مجمع السنابل الاستهلاكي", "روابي الخرطوم للحوم", "مياه النبع العذبة", "توابل وزيوت الجزيرة"),
      "صيدليات ومستلزمات طبية" to listOf("صيدلية الشفاء الكبرى", "مستودع العافية الدوائي", "مختبرات النيل للتحاليل", "شركة الأمل للمستلزمات الطبية", "صيدلية البلسم الدولي", "مركز الحياة للرعاية", "مجمع الدواء الحديث", "صيدلية قرطبة", "شركة النقاء الطبية", "معامل الفا للتشخيص"),
      "مطاعم وضيافة" to listOf("مطاعم الأمواج البحرية", "كافيه اللافندر التراثي", "مطابخ الشرق للمأكولات", "مطاعم البيت الدمشقي", "سلسلة برجر ستيشن", "واحة الشاي والقهوة", "حلويات الفيروز الشامية", "مطاعم ليالينا", "كافيه الأفق العصري", "شاورما وبطاطس زمان"),
      "أزياء ومنتجات تجميل" to listOf("بوتيك أوركيد للأناقة", "مستحضرات روز للعطور", "شركة الحرير للأقمشة", "معارض النخبة للأحذية", "دار الخياطة الراقية", "متاجر لافندر بيوتي", "عالم الأطفال للملابس", "معارض السنديان للشنط", "أطياب المسك والعنبر", "مجوهرات الفاتح الراقية"),
      "إلكترونيات وأجهزة منزلية" to listOf("تكنو بلس للأجهزة الرقمية", "المستقبل للإلكترونيات", "أبراج التبريد والتكييف", "شركة الطاقة الشمسية المتجددة", "معارض المدار للهواتف", "التقنية الذكية للكمبيوتر", "إلكترونيات السلام", "رواد الاتصالات والشبكات", "مجمع الأجهزة المنزلية الحديثة", "سما للإلكترونيات الاستهلاكية"),
      "خدمات ولوجستيات وتجزئة" to listOf("الناقل السريع للطرود", "مطابع المجد الرقمية", "مجمع قرطاسية الأوائل", "ورش النيل لصيانة السيارات", "مركز النظافة المتكامل", "وكالة السفر والسياحة الذهبية", "مستودعات الإمداد اللوجستي", "معارض السيراميك والتشطيبات", "مكتبة المعرفة الحديثة", "مغاسل الصفا الآلية")
    )

    val weightsList = mutableListOf<ComponentWeight>()
    var counter = 1
    val baseCount = 14500
    sampleCategories.forEach { (catName, businesses) ->
      businesses.forEachIndexed { idx, bizName ->
        // نولّد للـ 120 نشاط أوزان واقعية
        val orderCount = (baseCount - (counter * 85) + ((counter * 37) % 350)).coerceAtLeast(180)
        val weightPct = Math.round((orderCount.toDouble() / 120000.0 * 100.0) * 100.0) / 100.0
        val valueStr = String.format(java.util.Locale.US, "%.2f", orderCount * 4.28)
        weightsList.add(
          ComponentWeight(
            sheetId = "BIZ_${String.format(java.util.Locale.US, "%03d", counter)}",
            name = "$bizName ($catName)",
            ticker = "LV${String.format(java.util.Locale.US, "%03d", counter)}",
            count = orderCount,
            weight = weightPct,
            value = valueStr
          )
        )
        counter++
      }
    }

    // نكمل باقي الـ 120 نشاط بدقة تامة
    while (weightsList.size < 120) {
      val c = weightsList.size + 1
      val orderCount = (7500 - (c * 35)).coerceAtLeast(150)
      val weightPct = Math.round((orderCount.toDouble() / 120000.0 * 100.0) * 100.0) / 100.0
      val valueStr = String.format(java.util.Locale.US, "%.2f", orderCount * 4.28)
      weightsList.add(
        ComponentWeight(
          sheetId = "BIZ_${String.format(java.util.Locale.US, "%03d", c)}",
          name = "نشاط تجاري معتمد $c",
          ticker = "LV${String.format(java.util.Locale.US, "%03d", c)}",
          count = orderCount,
          weight = weightPct,
          value = valueStr
        )
      )
    }

    // ✅ تطبيع الأوزان: مجموعها = 100% بالضبط (كانت تُقسم على 120000 فيظهر 11–12% لكل نشاط)
    val totalOrders = weightsList.sumOf { it.count }.coerceAtLeast(1)
    for (i in weightsList.indices) {
      val w = weightsList[i]
      weightsList[i] = w.copy(weight = Math.round(w.count.toDouble() / totalOrders * 10000.0) / 100.0)
    }

    val topProducts = listOf(
      TopProduct(name = "عبوة زيت نباتي صافي 4 لتر", count = 3850),
      TopProduct(name = "حليب مجفف عائلي 2.25 كجم", count = 3120),
      TopProduct(name = "دقيق قمح ممتاز 10 كجم", count = 2890),
      TopProduct(name = "سكر أبيض نقي 10 كجم", count = 2650),
      TopProduct(name = "أرز بسمتي فاخر 5 كجم", count = 2340)
    )

    val dailyTrends = listOf(
      DailyOrderTrend("2026-08-23", 11200, "سكر أبيض 10كجم"),
      DailyOrderTrend("2026-08-24", 11450, "زيت نباتي 4لتر"),
      DailyOrderTrend("2026-08-25", 11600, "دقيق قمح 10كجم"),
      DailyOrderTrend("2026-08-26", 11820, "حليب مجفف"),
      DailyOrderTrend("2026-08-27", 11950, "أرز بسمتي"),
      DailyOrderTrend("2026-08-28", 12100, "زيت نباتي 4لتر"),
      DailyOrderTrend("2026-08-29", 12350, "سكر أبيض 10كجم"),
      DailyOrderTrend("2026-08-30", 12180, "حليب مجفف"),
      DailyOrderTrend("2026-08-31", 12400, "زيت نباتي 4لتر"),
      DailyOrderTrend("2026-09-01", 12510, "دقيق قمح 10كجم"),
      DailyOrderTrend("2026-09-02", 12620, "سكر أبيض 10كجم"),
      DailyOrderTrend("2026-09-03", 12480, "أرز بسمتي"),
      DailyOrderTrend("2026-09-04", 12700, "حليب مجفف عائلي"),
      DailyOrderTrend("2026-09-05", 12850, "زيت نباتي صافي 4 لتر")
    )

    val locations = listOf(
      LocationOrder("الخرطوم - بحري", 3450),
      LocationOrder("الخرطوم - أم درمان", 3280),
      LocationOrder("الخرطوم - الوسط", 2850),
      LocationOrder("بورتسودان", 1450),
      LocationOrder("ود مدني", 920),
      LocationOrder("كسلا", 550),
      LocationOrder("القضارف", 350)
    )

    val monthlySnapshots = listOf(
      MonthlySnapshot(
        month = "2026-08",
        date = "2026-08-31",
        NAV = "513.00",
        IIV = "513.00",
        premium = "0.00",
        netOrders = 12450,
        netUnits = 100,
        components = 120,
        top5 = "زيت نباتي، سكر، حليب مجفف، دقيق، أرز"
      ),
      MonthlySnapshot(
        month = "2026-07",
        date = "2026-07-31",
        NAV = "508.40",
        IIV = "507.90",
        premium = "+0.10",
        netOrders = 11980,
        netUnits = 100,
        components = 120,
        top5 = "سكر، زيت نباتي، دقيق، حليب مجفف، شاي"
      ),
      MonthlySnapshot(
        month = "2026-06",
        date = "2026-06-30",
        NAV = "502.15",
        IIV = "501.80",
        premium = "+0.07",
        netOrders = 11400,
        netUnits = 100,
        components = 120,
        top5 = "زيت نباتي، سكر، صابون منظف، دقيق، أرز"
      ),
      MonthlySnapshot(
        month = "2026-05",
        date = "2026-05-31",
        NAV = "496.80",
        IIV = "496.50",
        premium = "+0.06",
        netOrders = 10850,
        netUnits = 100,
        components = 120,
        top5 = "سكر، زيت نباتي، حليب، أرز، بقوليات"
      ),
      MonthlySnapshot(
        month = "2026-04",
        date = "2026-04-30",
        NAV = "490.20",
        IIV = "489.90",
        premium = "+0.06",
        netOrders = 10320,
        netUnits = 100,
        components = 120,
        top5 = "سكر، دقيق، زيت نباتي، شاي، مكرونة"
      )
    )

    val history = listOf(
      HistoryPoint("00:00", 511.20, 511.00),
      HistoryPoint("02:00", 511.50, 511.30),
      HistoryPoint("04:00", 511.90, 511.80),
      HistoryPoint("06:00", 512.10, 512.00),
      HistoryPoint("08:00", 512.45, 512.40),
      HistoryPoint("10:00", 512.80, 512.75),
      HistoryPoint("12:00", 513.00, 513.00),
      HistoryPoint("14:00", 513.25, 513.20),
      HistoryPoint("16:00", 513.15, 513.10),
      HistoryPoint("18:00", 513.35, 513.30),
      HistoryPoint("20:00", 513.10, 513.05),
      HistoryPoint("22:00", 513.00, 513.00)
    )

    return LavndrData(
      mode = "preview",
      indexTicker = "LAVNDR120",
      timestamp = "2026-09-05T12:00:00",
      settlementDate = "2026-09-07",
      settlementCycle = "T+2",
      maxCapacityOrders = 120000,
      maxCapacityValue = "513000.00",
      maxCapacityUnits = 1000.0,
      cashInLieu = 0.0,
      weights = weightsList,
      topProducts = topProducts,
      dailyOrderTrend = dailyTrends,
      ordersByLocation = locations,
      totalComponents = 120,
      monthlySnapshots = monthlySnapshots,
      authorizedParticipants = emptyList(),
      fund = FundInfo(
        totalParticipants = 120,
        activeParticipants = 84,
        poolValue = 61560.0,
        sharePrice = 513.0,
        marketListings = 3,
        tradingStage = 1,
        minBusinessOrders = 124
      ),
      index = IndexMetrics(
        NAV = "513.00",
        IIV = "513.00",
        premium = "0.00",
        percent = "0.00",
        change = "+2.40",
        changePercent = "+0.47",
        dayHigh = "514.20",
        dayLow = "511.00",
        volatility = "11.8",
        netOrders = 12850,
        netUnits = 100,
        grossOrders = 13000,
        redemptionOrders = 150,
        orderValue = "4.28",
        components = 120
      ),
      history = history,
      role = "visitor"
    )
  }
}

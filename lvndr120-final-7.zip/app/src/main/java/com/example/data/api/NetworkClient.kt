package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

// ✅ العميل الوحيد المفروض يكلمه التطبيق هو الـ Cloudflare Worker — بالظبط زي
// dashboard.html/admin.html/business.html. الـ Worker هو اللي يحقن الـ API key
// سيرفريًا قبل ما يوصل لـ GAS؛ التطبيق ما بيبعتش أي "key" في أي طلب أبدًا.
//
// ⚠️ عدّل القيمة تحت بعد نشر الـ Worker الفعلي بتاعك (نفس WORKER_URL الموجود في
// dashboard.html/admin.html/business.html — لازم تكون نفس القيمة في الأربعة أماكن).
object NetworkClient {

  @Volatile
  private var currentBaseUrl: String = "https://lavndr.omssolutionorders.workers.dev/"

  private val moshi = Moshi.Builder()
    .addLast(KotlinJsonAdapterFactory())
    .build()

  // ✅ إصلاح أمني: تسجيل جسم الطلب/الرد كامل (BODY) كان بيسرّب الـ token ورقم OTP
  // ورقم المعاملة البنكية في الـ Logcat على أي بناء، بما فيه release. دلوقتي الـ
  // BODY logging مفعّل فقط على debug builds؛ الـ release بياخد BASIC (method/URL/
  // كود الرد بس، من غير أي محتوى حساس).
  private val loggingInterceptor = HttpLoggingInterceptor().apply {
    level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.BASIC
  }

  // Interceptor يسمح بتغيير الـ baseUrl وقت التشغيل (مفيد للتطوير/الاختبار على
  // Worker مختلف قبل الإصدار النهائي) بدون إعادة بناء التطبيق.
  private val hostSelectionInterceptor = object : Interceptor {
    @Volatile
    var hostUrl: String? = null

    override fun intercept(chain: Interceptor.Chain): Response {
      var request = chain.request()
      val customUrl = hostUrl
      if (!customUrl.isNullOrBlank()) {
        val newHttpUrl = try {
          customUrl.toHttpUrlOrNull()
        } catch (e: Exception) {
          null
        }
        if (newHttpUrl != null) {
          val newRequestUrl = request.url.newBuilder()
            .scheme(newHttpUrl.scheme)
            .host(newHttpUrl.host)
            .port(newHttpUrl.port)
            .build()
          request = request.newBuilder().url(newRequestUrl).build()
        }
      }
      return chain.proceed(request)
    }
  }

  private val okHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(20, TimeUnit.SECONDS)
    .writeTimeout(20, TimeUnit.SECONDS)
    .addInterceptor(hostSelectionInterceptor)
    .addInterceptor(loggingInterceptor)
    .build()

  private var retrofit: Retrofit = buildRetrofit(currentBaseUrl)
  var apiService: LavndrApiService = retrofit.create(LavndrApiService::class.java)
    private set

  fun updateBaseUrl(newUrl: String) {
    var formatted = newUrl.trim()
    if (formatted.isNotBlank()) {
      if (!formatted.startsWith("http://") && !formatted.startsWith("https://")) {
        formatted = "https://$formatted"
      }
      if (!formatted.endsWith("/")) {
        formatted = "$formatted/"
      }
      currentBaseUrl = formatted
      hostSelectionInterceptor.hostUrl = formatted
      retrofit = buildRetrofit(formatted)
      apiService = retrofit.create(LavndrApiService::class.java)
    }
  }

  private fun buildRetrofit(baseUrl: String): Retrofit {
    val validUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
    return Retrofit.Builder()
      .baseUrl(validUrl)
      .client(okHttpClient)
      .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient())
      .build()
  }
}

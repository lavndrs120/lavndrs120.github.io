package com.example.data.alerts

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.service.LavndrFirebaseMessagingService
import com.example.util.NotificationSoundManager
import com.example.util.NotificationSoundType

data class PriceAlertConfig(
  val isEnabled: Boolean = false,
  val targetNav: Double = 530.0,
  val alertWhenAbove: Boolean = true,
  val hasTriggered: Boolean = false,
  val lastTriggeredAt: Long = 0L,
  val isSoundEnabled: Boolean = true
)

class PriceAlertManager(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("lavndr_price_alerts", Context.MODE_PRIVATE)

  private val appContext = context.applicationContext

  fun getAlertConfig(): PriceAlertConfig {
    return PriceAlertConfig(
      isEnabled = prefs.getBoolean("is_enabled", false),
      targetNav = prefs.getFloat("target_nav", 530.0f).toDouble(),
      alertWhenAbove = prefs.getBoolean("alert_when_above", true),
      hasTriggered = prefs.getBoolean("has_triggered", false),
      lastTriggeredAt = prefs.getLong("last_triggered_at", 0L),
      isSoundEnabled = prefs.getBoolean("is_sound_enabled", true)
    )
  }

  fun saveAlertConfig(config: PriceAlertConfig) {
    prefs.edit()
      .putBoolean("is_enabled", config.isEnabled)
      .putFloat("target_nav", config.targetNav.toFloat())
      .putBoolean("alert_when_above", config.alertWhenAbove)
      .putBoolean("has_triggered", config.hasTriggered)
      .putLong("last_triggered_at", config.lastTriggeredAt)
      .putBoolean("is_sound_enabled", config.isSoundEnabled)
      .apply()
  }

  /**
   * Checks current NAV against the configured alert.
   * If met and not already triggered in this cycle, fires a native notification.
   */
  fun checkAndNotify(currentNav: Double): Boolean {
    val config = getAlertConfig()
    if (!config.isEnabled || config.hasTriggered) return false

    val isConditionMet = if (config.alertWhenAbove) {
      currentNav >= config.targetNav
    } else {
      currentNav <= config.targetNav
    }

    if (isConditionMet) {
      fireNotification(currentNav, config.targetNav, config.alertWhenAbove, config.isSoundEnabled)
      saveAlertConfig(config.copy(hasTriggered = true, lastTriggeredAt = System.currentTimeMillis()))
      return true
    }
    return false
  }

  private fun fireNotification(currentNav: Double, targetNav: Double, isAbove: Boolean, isSoundEnabled: Boolean) {
    val notificationManager =
      appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    val intent = Intent(appContext, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
      appContext,
      1001,
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val title = if (isAbove) {
      "🎯 وصل المؤشر للهدف: $$currentNav!"
    } else {
      "⚠️ تنبيه هبوط المؤشر: $$currentNav!"
    }

    val content = if (isAbove) {
      "تجاوز مؤشر أصول LAVNDR120 الهدف المحدد ($$targetNav). القيمة الحالية الآن $$currentNav."
    } else {
      "انخفض مؤشر أصول LAVNDR120 دون المستوى المحدد ($$targetNav). القيمة الحالية الآن $$currentNav."
    }

    val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

    val notificationBuilder = NotificationCompat.Builder(appContext, LavndrFirebaseMessagingService.CHANNEL_MARKET_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(title)
      .setContentText(content)
      .setStyle(NotificationCompat.BigTextStyle().bigText(content))
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)

    if (isSoundEnabled) {
      notificationBuilder.setSound(soundUri)
      notificationBuilder.setDefaults(NotificationCompat.DEFAULT_ALL)
      NotificationSoundManager.play(appContext, NotificationSoundType.PRICE_TARGET)
    }

    notificationManager.notify(7701, notificationBuilder.build())
  }
}

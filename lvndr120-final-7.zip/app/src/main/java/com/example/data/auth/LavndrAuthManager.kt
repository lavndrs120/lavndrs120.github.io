package com.example.data.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import java.security.SecureRandom

// ✅ جديد: تسجيل دخول حقيقي بحساب Google، بديل الإيميلات الوهمية الثابتة اللي كانت
// موجودة في switchUserRole(). بيستخدم Credential Manager API (الطريقة الحديثة
// الموصى بها من جوجل، بديل GoogleSignIn API القديم) للحصول على Google ID Token خام.
//
// ⚠️ مهم: الباك اند (verifyGoogleIdToken في الـ.gs) بيتحقق من الـ idToken مباشرة عبر
// oauth2.googleapis.com/tokeninfo ويقارن حقل "aud" بـ CONFIG.OAUTH_CLIENT_ID — فمش
// محتاجين أي طبقة Firebase Auth وسيطة هنا. الـ idToken اللي بنجيبه هنا نفس النوع
// بالظبط اللي dashboard.html بيجيبه من GSI (google.accounts.id) في المتصفح.
//
// ⚠️ WEB_CLIENT_ID هنا لازم يكون نفس قيمة OAUTH_CLIENT_ID في الـ.gs بالظبط (نفس
// الـ Client ID المستخدم في dashboard.html/admin.html/business.html) — مش Client ID
// من نوع Android منفصل. راجع دليل النشر، خطوة 2.
object LavndrAuthManager {

  // ⚠️ عدّل القيمة دي بعد إنشاء OAuth Client ID (خطوة 2 في دليل النشر) — لازم تطابق
  // GSI_CLIENT_ID في الفرونت اند الويب وOAUTH_CLIENT_ID في الـ.gs حرفيًا.
  const val WEB_CLIENT_ID = "776097955989-go2bsq8e7c1umei4vj984jtabve49m32.apps.googleusercontent.com"

  sealed class AuthResult {
    data class Success(val idToken: String, val email: String?) : AuthResult()
    data class Failure(val message: String) : AuthResult()
  }

  // ✅ يحاول تسجيل دخول "صامت" الأول (بدون اختيار حساب لو فيه حساب واحد مصرّح له
  // بالفعل)، ولو رفض (مفيش حساب محفوظ/المستخدم لازم يختار)، بيسمح باختيار أي حساب.
  suspend fun signIn(context: Context): AuthResult {
    val credentialManager = CredentialManager.create(context)
    val nonce = generateNonce()

    // أول محاولة: filterByAuthorizedAccounts = true — تسجيل دخول أسرع وأقل احتكاكًا
    // لو المستخدم سجّل دخول قبل كده بنفس الجهاز.
    val filteredOption = GetGoogleIdOption.Builder()
      .setFilterByAuthorizedAccounts(true)
      .setServerClientId(WEB_CLIENT_ID)
      .setNonce(nonce)
      .build()

    val filteredRequest = GetCredentialRequest.Builder()
      .addCredentialOption(filteredOption)
      .build()

    try {
      val response = credentialManager.getCredential(context, filteredRequest)
      return extractResult(response)
    } catch (e: GetCredentialException) {
      // مفيش حساب محفوظ مسبقًا — نجرب تاني بعرض كل حسابات Google المتاحة على الجهاز
    }

    val openOption = GetGoogleIdOption.Builder()
      .setFilterByAuthorizedAccounts(false)
      .setServerClientId(WEB_CLIENT_ID)
      .setNonce(nonce)
      .build()

    val openRequest = GetCredentialRequest.Builder()
      .addCredentialOption(openOption)
      .build()

    return try {
      val response = credentialManager.getCredential(context, openRequest)
      extractResult(response)
    } catch (e: GetCredentialException) {
      AuthResult.Failure(e.message ?: "تعذّر تسجيل الدخول بحساب Google")
    }
  }

  private fun extractResult(response: androidx.credentials.GetCredentialResponse): AuthResult {
    val credential = response.credential
    if (credential !is CustomCredential ||
      credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
    ) {
      return AuthResult.Failure("نوع بيانات اعتماد غير متوقع من Google")
    }
    return try {
      val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
      AuthResult.Success(
        idToken = googleIdTokenCredential.idToken,
        email = googleIdTokenCredential.id
      )
    } catch (e: GoogleIdTokenParsingException) {
      AuthResult.Failure("تعذّر قراءة بيانات حساب Google")
    }
  }

  // Nonce عشوائي لكل محاولة تسجيل دخول — حماية إضافية ضد إعادة استخدام (replay) نفس
  // الاستجابة. الباك اند الحالي ما بيتحققش من nonce صراحة (زي المتصفح تمامًا، اللي
  // GSI بتاعه برضو بيولّد nonce لكن verifyGoogleIdToken في الـ.gs بيتحقق من aud/exp/
  // email_verified بس)، لكن توليده هنا أفضل ممارسة قياسية ومفيش أي ضرر منها.
  private fun generateNonce(): String {
    val bytes = ByteArray(16)
    SecureRandom().nextBytes(bytes)
    return bytes.joinToString("") { "%02x".format(it) }
  }
}

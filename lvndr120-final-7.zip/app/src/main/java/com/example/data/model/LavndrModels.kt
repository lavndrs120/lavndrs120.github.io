package com.example.data.model

import com.squareup.moshi.Json

data class IndexMetrics(
  val NAV: String = "513.00",
  val IIV: String = "513.00",
  val premium: String = "0.00",
  val percent: String = "0.00",
  val change: String = "+0.00",
  val changePercent: String = "+0.00",
  val dayHigh: String = "513.00",
  val dayLow: String = "513.00",
  val volatility: String = "12.4",
  val netOrders: Int = 12000,
  val netUnits: Int = 100,
  val grossOrders: Int = 12150,
  val redemptionOrders: Int = 150,
  val orderValue: String = "4.28",
  val components: Int = 120
)

data class ComponentWeight(
  val sheetId: String,
  val name: String,
  val ticker: String,
  val count: Int,
  val weight: Double,
  val value: String
)

data class TopProduct(
  val name: String,
  val count: Int
)

data class DailyOrderTrend(
  val date: String,
  val orders: Int,
  val topProduct: String? = null
)

data class LocationOrder(
  val location: String,
  val count: Int
)

data class HistoryPoint(
  val time: String,
  val NAV: Double,
  val IIV: Double
)

data class MarketItem(
  val row: Int,
  val seller: String,
  val shareValue: Double,
  val listDate: String
)

data class FundInfo(
  val totalParticipants: Int = 120,
  val activeParticipants: Int = 84,
  val poolValue: Double = 61560.0,
  val sharePrice: Double = 513.0,
  val marketListings: Int = 3,
  val market: List<MarketItem> = emptyList(),
  val tradingStage: Int = 1, // 0: Locked, 1: 100 orders/biz, 2: 500, 3: 1000
  val minBusinessOrders: Int = 124
)

data class MonthlySnapshot(
  val month: String,
  val date: String,
  val NAV: String,
  val IIV: String,
  val premium: String,
  val netOrders: Int,
  val netUnits: Int,
  val components: Int,
  val top5: String
)

data class AuthorizedParticipant(
  val code: String,
  val name: String,
  val orders: Int
)

data class ApEarning(
  val code: String,
  val name: String,
  val earnings: Double
)

data class LavndrData(
  val mode: String = "live",
  val indexTicker: String = "LAVNDR120",
  val timestamp: String = "2026-09-02T12:00:00",
  val settlementDate: String = "2026-09-04",
  val settlementCycle: String = "T+2",
  val maxCapacityOrders: Int = 120000,
  val maxCapacityValue: String = "513000.00",
  val maxCapacityUnits: Double = 1000.0,
  val cashInLieu: Double = 0.0,
  val weights: List<ComponentWeight> = emptyList(),
  val topProducts: List<TopProduct> = emptyList(),
  val dailyOrderTrend: List<DailyOrderTrend> = emptyList(),
  val ordersByLocation: List<LocationOrder> = emptyList(),
  val totalComponents: Int = 120,
  val monthlySnapshots: List<MonthlySnapshot> = emptyList(),
  val authorizedParticipants: List<AuthorizedParticipant> = emptyList(),
  val fund: FundInfo = FundInfo(),
  val index: IndexMetrics = IndexMetrics(),
  val history: List<HistoryPoint> = emptyList(),
  val role: String = "participant",
  // ✅ جديد: action=data بيرجّع {error:'subscription_required', code:402} بدل
  // بيانات المؤشر لو المستخدم role=visitor (سجّل دخول بس لسه ما اشتركش/انضمش).
  // بدون هذين الحقلين، Moshi كانت هترجّع LavndrData بقيم افتراضية فاضية وتُخفي
  // الخطأ الحقيقي تمامًا بدل ما تفصح عنه للـ UI.
  val error: String? = null,
  val code: Int? = null
)

// ✅ إصلاح جوهري: action=participant في الباك اند بيرجّع واحد من 3 أشكال مختلفة
// تمامًا حسب الحالة:
//   1) بيانات مشارك فعلي كاملة (email/status/entryNAV/currentValue/...)
//   2) دفعة لسه بانتظار OTP/مراجعة: {pending: true, stage, amount}
//   3) {error: 'not found'} — لسه ما اشتركش أصلاً
// موديل واحد صارم الحقول (زي القديم) كان هيفشل في تحليل (parse) الحالتين التانيتين
// لأن Moshi هيحتاج قيم للحقول non-null المفقودة. كل الحقول هنا nullable عمدًا؛
// الكود المستهلك (Repository/UI) لازم يفحص أي الحالة الثلاث موجودة فعليًا قبل القراءة.
data class ParticipantInfo(
  val email: String? = null,
  val status: String? = null,
  val entryNAV: String? = null,
  val entryDate: String? = null,
  val sharePrice: String? = null,
  val currentValue: String? = null,
  val pnl: String? = null,
  val pnlPercent: String? = null,
  val allocation: Map<String, Double>? = null,
  // حالة "بانتظار دفع" (pending=true من getPendingPaymentStatus)
  val pending: Boolean? = null,
  val stage: String? = null, // "awaiting_otp" أو "awaiting_review"
  val amount: Double? = null,
  val error: String? = null
) {
  val pendingStage: String? get() = if (pending == true) stage else null
  val pendingAmount: Double? get() = if (pending == true) amount else null
  val isActiveParticipant: Boolean get() = status == "active" && currentValue != null
}

data class BusinessEntitlement(
  val row: Int,
  val date: String,
  val sheetId: String,
  val name: String,
  val weight: String,
  val entitlement: Double,
  val status: String, // available, accepted_awaiting_guarantee, completed
  val orders: Int,
  val guaranteeStatus: String,
  val growthAmount: Double,
  val guaranteeAmount: Double
)

data class ProgressState(val page: String? = null, val screen: String? = null, val space: String? = null)
data class ProgressInfo(val state: ProgressState? = null)

data class AgreementState(val status: String = "", val link: String = "")
data class CashRequestItem(
  val requestedAt: Any? = null,
  val status: String = "",
  val due36: Any? = null,
  val approvedAmount: Any? = null
)
data class BusinessMetrics(val orders: Int = 0, val weight: Double = 0.0, val due36: Double = 0.0, val suggested: Double = 0.0)
data class BusinessRequestsInfo(
  val agreement: AgreementState? = null,
  val cash: List<CashRequestItem> = emptyList(),
  val agreementReceived: Boolean = false,
  val m: BusinessMetrics = BusinessMetrics()
)

data class BusinessItem(
  val sheetId: String,
  val name: String,
  val ticker: String? = null,
  val orders: Int = 0,
  val weight: Double = 0.0,
  val closed: Boolean = false,
  val autoAccept: Boolean = false,
  val entitlements: List<BusinessEntitlement> = emptyList(),
  val requests: BusinessRequestsInfo = BusinessRequestsInfo()
)

data class BusinessPortalInfo(
  val linked: Boolean = true,
  val businesses: List<BusinessItem> = emptyList()
)

data class PendingPayment(
  val row: Int,
  val email: String,
  val amount: Double,
  val sellerEmail: String = "",
  val requestedAt: String = "",
  val txnRef: String = "",
  val submittedAt: String = ""
)

data class PendingSubscription(
  val row: Int,
  val email: String,
  val tier: String,
  val amount: Double,
  val requestedAt: String = "",
  val txnRef: String = "",
  val submittedAt: String = ""
)

data class ParticipantAdminItem(
  val email: String,
  val status: String,
  val entryNAV: String,
  val entryDate: String,
  val sharePrice: String,
  val currentValue: String,
  val pnl: String
)

data class BusinessAdminItem(
  val row: Int,
  val sheetId: String,
  val name: String,
  val email: String,
  val autoAccept: Boolean,
  val orders: Int,
  val closed: Boolean
)

data class AuditLogItem(
  val timestamp: String,
  val actor: String,
  val action: String,
  val details: String
)

data class BankDetails(
  val bankName: String = "بنك الخرطوم",
  val swift: String = "BAKHSDKH",
  val accountNumber: String = "2467362",
  val iban: String = "SD6804024673620001",
  val bban: String = "04024673620001",
  val accountHolder: String = "عمر سيداحمد محمدالحسن محمد",
  val branch: String = "صابرين",
  val currency: String = "الجنيه السوداني SDG"
)

enum class UserRole(val labelAr: String, val apiValue: String) {
  ADMIN("مسؤول النظام (Admin)", "admin"),
  PARTICIPANT("شريك / مستثمر 120 نشاط", "participant"),
  // ✅ جديد: فندكس وماقما ليهم صلاحيات إضافية خاصة بيهم (تقرير الأوراكل، دليل
  // البزنسات) — مش نفس صلاحيات SUBSCRIBER العادية (لافا/سنوي، مطالعة بس بدون أي إضافة)
  FENDEX("عضو ڤندكس (Lavenders Oracle)", "fendex"),
  MAGMA("عضو ماقما", "magma"),
  SUBSCRIBER("مشترك داتا معتمد", "subscriber"),
  VISITOR("زائر (معاينة)", "visitor")
}

// ✅ جديد: نتيجة استدعاء action=login — الشكل الفعلي المُرجَع من doPost في الـ.gs
// (راجع: { token: sessionToken, email: email, role: getUserRole(email) })
data class LoginResult(
  val token: String? = null,
  val email: String? = null,
  val role: String? = null,
  val error: String? = null
)

// ✅ جديد: شكل رد عام موحّد لأي استدعاء POST (buy/sell/verify_payment/admin_decide_*...).
// الباك اند بيرجّع حقول مختلفة حسب الـ action، فكل الحقول اختيارية عمدًا. أي كود
// بيستهلك هذا النوع لازم يفحص "error" الأول قبل أي حاجة تانية (نفس مبدأ dashboard.html).
data class ActionResult(
  val success: Boolean? = null,
  val message: String? = null,
  val error: String? = null,
  val code: Int? = null,
  val status: String? = null,
  val stage: String? = null,
  val amount: Double? = null,
  val tier: String? = null,
  val decision: String? = null,
  val autoAccept: Boolean? = null,
  val guaranteeAmount: Double? = null,
  val contributionAmount: Double? = null,
  val growthAmount: Double? = null,
  val version: Int? = null,
  val shareValue: Double? = null // sellShare → {status:'listed', shareValue}
)

// ✅ جديد: شكل رد action=terms (GET)
data class TermsInfo(
  val tier: String = "",
  val text: String = "",
  val version: Int = 1,
  val accepted: Boolean = false
)

// ✅ جديد: شكل رد action=subscription_status (GET) — stage: none/awaiting_otp/awaiting_review/active
data class SubscriptionStatus(
  val stage: String = "none",
  val tier: String? = null,
  val amount: Double? = null,
  val endDate: String? = null,
  // ✅ جديد: إتاحة كل باقة (متاحة/مكتملة) — بترجع مع كل رد من الباك اند بغض النظر
  // عن المرحلة، عشان شاشة اختيار الباقة تعطّل زرار أي باقة وصلت السقف من الأول.
  val availability: SubscriptionAvailability? = null,
  // ✅ جديد: قائمة الانتظار (stage="waitlisted") — السوق لسه في طور التكوين
  val readyCount: Int? = null,
  val targetCount: Int? = null,
  // ✅ جديد: السوق مكتمل (120 نشاط)؟ يحدد: ما قبل الاشتراك (واتساب) ↔ الاشتراك المباشر
  val marketComplete: Boolean? = null,
  // ✅ جديد: فئة الباقة في قائمة الانتظار ('movement' = الحركة الاقتصادية) + الدولة (تايكون)
  val category: String? = null,
  val country: String? = null,
  // ✅ جديد: stage="franchise" — تقدّم دفع الفرانشايز (أرقام فقط)
  val franchise: FranchiseInfo? = null,
  // ✅ بيانات الحساب البنكي تُعرض في مرحلة awaiting_otp مع نسخ بضغطة
  val bank: BankInfo? = null
)

data class MySubscriptionItem(
  val tier: String = "",
  val tierName: String? = null,
  val stage: String = "",
  val amount: Double? = null,
  val endDate: String? = null,
  val country: String? = null,
  val category: String? = null
)

data class MySubscriptionsResponse(
  val items: List<MySubscriptionItem> = emptyList(),
  val activeCount: Int = 0
)

data class BankInfo(
  @Json(name = "BANK_NAME") val bankName: String? = null,
  @Json(name = "ACCOUNT_HOLDER") val accountHolder: String? = null,
  @Json(name = "ACCOUNT_NUMBER") val accountNumber: String? = null,
  @Json(name = "IBAN") val iban: String? = null,
  @Json(name = "BRANCH") val branch: String? = null
)

data class FranchiseInfo(
  val hasFranchise: Boolean = false,
  val totalUsd: Double = 0.0,
  val paidUsd: Double = 0.0,
  val remainingUsd: Double = 0.0,
  val seatsPaid: Int = 0,
  val totalSeats: Int = 120,
  val status: String = "in_progress",
  val nextAmountUsd: Double = 0.0,
  val pendingStage: String? = null
)

data class SubscriptionAvailability(
  val lava: TierAvailability = TierAvailability(),
  val annual: TierAvailability = TierAvailability(),
  // ✅ جديد: ڤندكس وماقما — عضويات محدودة العدد فعليًا، بيرجع معاها العدد المتبقي
  // الحقيقي (راجع TierAvailability.remaining) لعرض شارة الندرة/الحصرية
  val fendex: TierAvailability = TierAvailability(),
  val magma: TierAvailability = TierAvailability(),
  // ✅ جديد: OMS (سقف مشترك 120) + باقات الحركة الاقتصادية
  @Json(name = "oms_services") val omsServices: TierAvailability = TierAvailability(),
  @Json(name = "oms_products") val omsProducts: TierAvailability = TierAvailability(),
  @Json(name = "oms_vip") val omsVip: TierAvailability = TierAvailability(),
  val reseller: TierAvailability = TierAvailability(),
  val franchise: TierAvailability = TierAvailability(),
  val tycoon: TierAvailability = TierAvailability()
)

data class TierAvailability(
  val available: Boolean = true,
  // ✅ جديد: بترجع بس لڤندكس/ماقما — العدد الحقيقي المتبقي من العضوية (مش
  // متاح/مكتمل بس زي لافا/السنوي، لأن الندرة نفسها هي محرّك الحصرية في الباقتين دول)
  val remaining: Int? = null,
  val max: Int? = null
)

// ✅ جديد: باقة ماقما — دليل الـ120 نشاط مرتبين حسب وزنهم الاستهلاكي الحقيقي
data class MagmaDirectoryResponse(
  val businesses: List<MagmaBusinessEntry> = emptyList(),
  val totalBusinesses: Int = 0,
  val viewedCount: Int = 0
)

data class MagmaBusinessEntry(
  val sheetId: String = "",
  val name: String = "",
  val ticker: String = "",
  val rank: Int = 0,
  val weight: Double = 0.0,
  val category: String = "غير مصنّف",
  val link: String = "",
  val viewed: Boolean = false
)

// ✅ جديد: شكل رد action=month (GET) — history تاريخية لشهر معيّن من Monthly_Snapshots
data class MonthlyHistoryResponse(
  val mode: String = "historical",
  val month: String = "",
  val snapshot: MonthlySnapshot? = null,
  val history: List<HistoryPoint> = emptyList(),
  val error: String? = null,
  val code: Int? = null
)

// ✅ جديد: شكل رد GET بدون action (أو أي رد قوائم عام لف بمفتاح rows) — الباك اند
// بيرجّع { rows: [...] } لكل قوائم الأدمن (admin_pending_payments، admin_participants...)
data class RowsWrapper<T>(val rows: List<T> = emptyList())

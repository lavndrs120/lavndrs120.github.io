package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LavndrDao {

  @Query("SELECT * FROM cached_index_data WHERE id = 'latest' LIMIT 1")
  suspend fun getCachedIndexData(): CachedIndexDataEntity?

  @Query("SELECT * FROM cached_index_data WHERE id = 'latest' LIMIT 1")
  fun observeCachedIndexData(): Flow<CachedIndexDataEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveCachedIndexData(entity: CachedIndexDataEntity)

  @Query("SELECT * FROM cached_participant WHERE email = :email LIMIT 1")
  suspend fun getCachedParticipant(email: String): CachedParticipantEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveCachedParticipant(entity: CachedParticipantEntity)

  @Query("SELECT * FROM cached_business_portal WHERE email = :email LIMIT 1")
  suspend fun getCachedBusinessPortal(email: String): CachedBusinessPortalEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveCachedBusinessPortal(entity: CachedBusinessPortalEntity)

  @Query("SELECT * FROM pending_offline_actions ORDER BY createdAt ASC")
  suspend fun getAllPendingActions(): List<PendingOfflineActionEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun enqueueAction(action: PendingOfflineActionEntity): Long

  @Delete
  suspend fun deletePendingAction(action: PendingOfflineActionEntity)

  @Query("DELETE FROM pending_offline_actions WHERE id = :id")
  suspend fun deletePendingActionById(id: Long)
}

package com.example.data.api

import com.example.data.model.*
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

// ✅ إعادة بناء كاملة (كانت مبنية على Authorization header وهمي غير موجود في الباك
// اند الفعلي). كل endpoint هنا مطابق حرفيًا لما هو موجود في doGet/doPost بملف الـ.gs:
// - GET: الـ action كـ query param، والـ token كـ query param كمان (e.parameter.token)
// - POST: كل الحقول (action/token/email/...) داخل جسم JSON واحد (e.postData.contents)
// - مفيش أي "key"/API_KEY هنا نهائيًا — بالظبط زي dashboard.html، التطبيق يكلم
//   Cloudflare Worker فقط (اللي هو يحقن الـ API key سيرفريًا)، مش الـ.gs مباشرة.
interface LavndrApiService {

  // ─── القراءة (GET) ───

  @GET("/")
  suspend fun getData(
    @Query("action") action: String = "data",
    @Query("token") token: String
  ): Response<LavndrData>

  @GET("/")
  suspend fun getMonth(
    @Query("action") action: String = "month",
    @Query("month") month: String,
    @Query("token") token: String
  ): Response<MonthlyHistoryResponse>

  @GET("/")
  suspend fun getProgress(
    @Query("action") action: String = "my_progress",
    @Query("token") token: String
  ): Response<ProgressInfo>

  @GET("/")
  suspend fun getTerms(
    @Query("action") action: String = "terms",
    @Query("token") token: String,
    @Query("tier") tier: String? = null
  ): Response<TermsInfo>

  @GET("/")
  suspend fun getBankDetails(
    @Query("action") action: String = "bank_details",
    @Query("token") token: String
  ): Response<BankDetails>

  @GET("/")
  suspend fun getParticipant(
    @Query("action") action: String = "participant",
    @Query("email") email: String,
    @Query("token") token: String
  ): Response<ParticipantInfo>

  @GET("/")
  suspend fun getBusinessPortal(
    @Query("action") action: String = "my_business_portal",
    @Query("token") token: String
  ): Response<BusinessPortalInfo>

  @GET("/")
  suspend fun getMarket(
    @Query("action") action: String = "market",
    @Query("token") token: String
  ): Response<List<MarketItem>>

  @GET("/")
  suspend fun getSubscriptionStatus(
    @Query("action") action: String = "subscription_status",
    @Query("token") token: String,
    @Query("tier") tier: String? = null,
    @Query("country") country: String? = null
  ): Response<SubscriptionStatus>

  @GET("/")
  suspend fun getMySubscriptions(
    @Query("action") action: String = "my_subscriptions",
    @Query("token") token: String
  ): Response<MySubscriptionsResponse>

  @GET("/")
  suspend fun getAdminPendingPayments(
    @Query("action") action: String = "admin_pending_payments",
    @Query("token") token: String
  ): Response<RowsWrapper<PendingPayment>>

  @GET("/")
  suspend fun getAdminPendingSubscriptions(
    @Query("action") action: String = "admin_pending_subscriptions",
    @Query("token") token: String
  ): Response<RowsWrapper<PendingSubscription>>

  @GET("/")
  suspend fun getAdminParticipants(
    @Query("action") action: String = "admin_participants",
    @Query("token") token: String
  ): Response<RowsWrapper<ParticipantAdminItem>>

  @GET("/")
  suspend fun getAdminBusinesses(
    @Query("action") action: String = "admin_business_list",
    @Query("token") token: String
  ): Response<RowsWrapper<BusinessAdminItem>>

  @GET("/")
  suspend fun getAdminEntitlements(
    @Query("action") action: String = "admin_entitlements",
    @Query("token") token: String
  ): Response<RowsWrapper<BusinessEntitlement>>

  @GET("/")
  suspend fun getAdminAuditLog(
    @Query("action") action: String = "admin_audit_log",
    @Query("token") token: String
  ): Response<RowsWrapper<AuditLogItem>>

  @GET("/")
  suspend fun getApEarnings(
    @Query("action") action: String = "ap_earnings",
    @Query("token") token: String
  ): Response<RowsWrapper<ApEarning>>

  // ✅ جديد: دليل الـ120 نشاط لمشترك باقة ماقما — حصري، الباك اند بيرفض 403 لغير
  // role=magma/admin
  @GET("/")
  suspend fun getMagmaDirectory(
    @Query("action") action: String = "magma_directory",
    @Query("token") token: String
  ): Response<MagmaDirectoryResponse>

  // ─── الكتابة (POST) — كل الحقول داخل الـ body، بدون استثناء ───
  // كل الأكشنز (login, buy, sell, verify_payment, subscribe, admin_decide_payment,
  // link_business, close_business, set_auto_accept, accept_entitlement,
  // confirm_guarantee, ...) بتتبعت عبر نفس الدالة دي — الباك اند بيميّز بينهم بحقل
  // "action" جوه الـ body نفسه، مش بمسارات مختلفة.
  //
  // ✅ مهم: الـ body هنا نوعه RequestBody جاهز (مش Map مباشرة) عمدًا. Retrofit مع
  // MoshiConverterFactory لا يضمن تسلسلًا (serialization) موثوقًا لـ Map<String, Any?>
  // العامة في كل الحالات (النوع Any غير محدد وقت الترجمة) — فبنبني JSON string بأنفسنا
  // في LavndrRepository عبر Moshi مباشرة (Types.newParameterizedType(Map, String,
  // Any) اللي مضمون تصرفه)، ونمرره كـ RequestBody نصي صريح. هذا يزيل أي اعتماد على
  // سلوك ضمني غير مؤكد من Retrofit's Map handling.
  @POST("/")
  suspend fun postAction(
    @Body body: RequestBody
  ): Response<ActionResult>

  // ✅ نسخة مخصصة لـ login بس، عشان نوع الرد مختلف شكليًا عن ActionResult العام
  // (بيرجّع token/email/role مباشرة، مش error/status). idToken نص طويل جدًا (JWT)
  // لكن حقلين بس (action, idToken)، فـ Map<String, String> هنا آمنة تمامًا (Moshi
  // بتتعامل مع Map<String, String> بشكل مضمون 100% لأن النوع محدد بالكامل).
  @POST("/")
  suspend fun login(
    @Body body: Map<String, String>
  ): Response<LoginResult>
}

package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [
    CachedIndexDataEntity::class,
    CachedParticipantEntity::class,
    CachedBusinessPortalEntity::class,
    PendingOfflineActionEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class LavndrDatabase : RoomDatabase() {
  abstract fun lavndrDao(): LavndrDao

  companion object {
    @Volatile
    private var INSTANCE: LavndrDatabase? = null

    fun getDatabase(context: Context): LavndrDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          LavndrDatabase::class.java,
          "lavndr_production.db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}

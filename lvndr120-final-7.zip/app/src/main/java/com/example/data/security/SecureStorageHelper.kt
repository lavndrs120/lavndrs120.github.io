package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecureStorageHelper {

  private const val TAG = "SecureStorageHelper"
  private const val ENCRYPTED_PREFS_NAME = "lavndr_secure_vault"
  private const val LEGACY_PREFS_NAME = "lavndr_production_prefs"

  fun getEncryptedSharedPreferences(context: Context): SharedPreferences {
    return try {
      val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

      val encryptedPrefs = EncryptedSharedPreferences.create(
        context,
        ENCRYPTED_PREFS_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
      )

      // نقل البيانات تلقائياً من الملف القديم غير المشفر إلى الملف المشفر
      migrateLegacyPrefs(context, encryptedPrefs)
      encryptedPrefs
    } catch (e: Exception) {
      Log.e(TAG, "Failed to initialize EncryptedSharedPreferences, falling back to standard prefs", e)
      context.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)
    }
  }

  private fun migrateLegacyPrefs(context: Context, securePrefs: SharedPreferences) {
    try {
      val legacyPrefs = context.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)
      val allEntries = legacyPrefs.all
      if (allEntries.isNotEmpty()) {
        val editor = securePrefs.edit()
        for ((key, value) in allEntries) {
          if (!securePrefs.contains(key)) {
            when (value) {
              is String -> editor.putString(key, value)
              is Boolean -> editor.putBoolean(key, value)
              is Int -> editor.putInt(key, value)
              is Long -> editor.putLong(key, value)
              is Float -> editor.putFloat(key, value)
            }
          }
        }
        editor.apply()
        // مسح التوكن من الملف القديم لضمان عدم بقائه بنص غير مشفر
        legacyPrefs.edit().remove("auth_token").apply()
      }
    } catch (e: Exception) {
      Log.w(TAG, "Migration of legacy prefs encountered an issue: ${e.message}")
    }
  }
}

package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cached_index_data")
data class CachedIndexDataEntity(
  @PrimaryKey val id: String = "latest",
  val rawJson: String,
  val lastSyncedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_participant")
data class CachedParticipantEntity(
  @PrimaryKey val email: String,
  val rawJson: String,
  val lastSyncedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_business_portal")
data class CachedBusinessPortalEntity(
  @PrimaryKey val email: String,
  val rawJson: String,
  val lastSyncedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pending_offline_actions")
data class PendingOfflineActionEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val actionType: String,
  val payloadJson: String,
  val createdAt: Long = System.currentTimeMillis()
)

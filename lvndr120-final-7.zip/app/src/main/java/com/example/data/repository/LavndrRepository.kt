package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.api.NetworkClient
import com.example.data.auth.LavndrAuthManager
import com.example.data.db.CachedBusinessPortalEntity
import com.example.data.db.CachedIndexDataEntity
import com.example.data.db.CachedParticipantEntity
import com.example.data.db.PendingOfflineActionEntity
import com.example.data.db.LavndrDatabase
import com.example.data.security.SecureStorageHelper
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.*

// ✅ إعادة بناء جوهرية لطبقة المصادقة والشبكة كاملة. الفروق الجوهرية عن النسخة القديمة:
//
// 1) تسجيل الدخول بقى حقيقي (Google Credential Manager → idToken → action=login في
//    الباك اند) بدل تبديل إيميلات ثابتة يدويًا (اللي كان فعليًا تجاوز كامل للمصادقة).
// 2) token بقى query param (GET) أو حقل داخل الـ body (POST) بدل Authorization header
//    وهمي غير موجود في الباك اند أصلاً.
// 3) كل استدعاء POST بقى يتفحص رده الفعلي (error/code) قبل أي تحديث للـ UI state —
//    اتشال الـ "optimistic update" الوهمي اللي كان بيحدّث الشاشة كأن العملية نجحت
//    قبل ما نعرف رد السيرفر أصلاً.
// 4) code=401 (توكن منتهي/غير صالح) بيصفّر الجلسة فورًا ويطلب تسجيل دخول جديد — نفس
//    مبدأ clearSessionAndReset في dashboard.html.
// 5) code=451 (شروط الاستخدام) بيرجّع حالة واضحة للـ UI بدل ما نفترض قبول محلي فقط.
class LavndrRepository(private val context: Context) {

  private val prefs: SharedPreferences =
    SecureStorageHelper.getEncryptedSharedPreferences(context)

  private val database = LavndrDatabase.getDatabase(context)
  private val dao = database.lavndrDao()

  private val moshi = Moshi.Builder()
    .addLast(KotlinJsonAdapterFactory())
    .build()

  // ✅ Adapter صريح لـ Map<String, Any?> — نوع Any مش محدد وقت الترجمة، فلازم نبني
  // الـ JSON Type بالضبط عبر Types.newParameterizedType بدل الاعتماد على استنتاج
  // Retrofit التلقائي (اللي مش مضمون لكل الحالات مع @Body Map مباشرة). بنستخدم هنا
  // Moshi.adapter(Type) — method عادية (مش extension) من كلاس Moshi نفسه، بتاخد
  // Type وترجع JsonAdapter<T> حيث T بتتحدد من نوع المتغيّر المستهدف (target typing)،
  // من غير أي حاجة لـ generic argument صريح على الاستدعاء نفسه. هذا الـ adapter هو
  // المصدر الوحيد لتحويل أي payload POST لنص JSON قبل الإرسال.
  private val mapJsonType: java.lang.reflect.Type =
    Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)

  private val anyMapAdapter: com.squareup.moshi.JsonAdapter<Map<String, Any?>> =
    moshi.adapter(mapJsonType)

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  private val dataAdapter = moshi.adapter(LavndrData::class.java)
  private val participantAdapter = moshi.adapter(ParticipantInfo::class.java)
  private val businessPortalAdapter = moshi.adapter(BusinessPortalInfo::class.java)

  // ─── حالة الجلسة (Session) ───

  private val _authToken = MutableStateFlow(prefs.getString("auth_token", "") ?: "")
  val authToken: StateFlow<String> = _authToken.asStateFlow()

  private val _currentUserEmail = MutableStateFlow(prefs.getString("user_email", "") ?: "")
  val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

  private val _currentRole = MutableStateFlow(
    try {
      UserRole.valueOf(prefs.getString("user_role", UserRole.VISITOR.name) ?: UserRole.VISITOR.name)
    } catch (e: Exception) {
      UserRole.VISITOR
    }
  )
  val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

  // ✅ جديد: هل فيه جلسة مسجّلة أصلاً؟ الـ UI بيستخدمها عشان يقرر يعرض شاشة تسجيل
  // الدخول أو المحتوى الرئيسي.
  private val _isLoggedIn = MutableStateFlow(_authToken.value.isNotBlank() && _currentUserEmail.value.isNotBlank())
  val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

  private val _isSigningIn = MutableStateFlow(false)
  val isSigningIn: StateFlow<Boolean> = _isSigningIn.asStateFlow()

  private val _loginErrorMessage = MutableStateFlow<String?>(null)
  val loginErrorMessage: StateFlow<String?> = _loginErrorMessage.asStateFlow()

  // ✅ جديد: الحقول اللي كانت بتتخزن هنا (hasAcceptedTerms) بقت تُقرأ من رد الباك
  // اند نفسه (action=terms → accepted) مش قرار محلي بحت، عشان توافق موحّد بين كل
  // أجهزة نفس المستخدم — لسه بنحتفظ بنسخة محلية كـ cache سريع بس.

  private val _termsText = MutableStateFlow("")
  val termsText: StateFlow<String> = _termsText.asStateFlow()

  private val _bankDetails = MutableStateFlow(BankDetails())
  val bankDetails: StateFlow<BankDetails> = _bankDetails.asStateFlow()

  // ─── حالة البيانات الحية ───

  private val _data = MutableStateFlow(PreviewDataProvider.getPreviewData())
  val data: StateFlow<LavndrData> = _data.asStateFlow()

  // ✅ جديد: يظهر بوضوح لو role=visitor وcode=402 من الباك اند — نفس منطق
  // showSubscribeGate في dashboard.html
  private val _needsSubscription = MutableStateFlow(false)
  val needsSubscription: StateFlow<Boolean> = _needsSubscription.asStateFlow()

  private val _participantInfo = MutableStateFlow<ParticipantInfo?>(null)
  val participantInfo: StateFlow<ParticipantInfo?> = _participantInfo.asStateFlow()

  private val _businessPortal = MutableStateFlow(BusinessPortalInfo(linked = false))
  val businessPortal: StateFlow<BusinessPortalInfo> = _businessPortal.asStateFlow()

  private val _mySubscriptions = MutableStateFlow<List<MySubscriptionItem>>(emptyList())
  val mySubscriptions: StateFlow<List<MySubscriptionItem>> = _mySubscriptions.asStateFlow()
  // الاشتراك المختار حاليًا (عند وجود أكثر من اشتراك) — يُرسل مع status/verify
  private var selectedTier: String? = null
  private var selectedCountry: String? = null

  private val _subscriptionStatus = MutableStateFlow(SubscriptionStatus())
  val subscriptionStatus: StateFlow<SubscriptionStatus> = _subscriptionStatus.asStateFlow()

  // ✅ جديد: دليل الـ120 نشاط لمشترك باقة ماقما
  private val _magmaDirectory = MutableStateFlow(MagmaDirectoryResponse())
  val magmaDirectory: StateFlow<MagmaDirectoryResponse> = _magmaDirectory.asStateFlow()

  // ✅ جديد: بيانات الشهر التاريخي المختار (action=month) — الشارت الشهري في
  // HomeScreen كان زخرفيًا بالكامل قبل كده (بيغيّر العنوان بس من غير أي بيانات حقيقية)
  private val _selectedMonth = MutableStateFlow<String?>(null)
  val selectedMonth: StateFlow<String?> = _selectedMonth.asStateFlow()

  private val _monthlyHistory = MutableStateFlow<List<HistoryPoint>>(emptyList())
  val monthlyHistory: StateFlow<List<HistoryPoint>> = _monthlyHistory.asStateFlow()

  // ✅ جديد: رسالة الخطأ الفعلية من آخر عملية شراء/بيع/دفع — الـ UI بيعرضها بدل ما
  // يفترض النجاح دايمًا
  private val _lastActionError = MutableStateFlow<String?>(null)
  val lastActionError: StateFlow<String?> = _lastActionError.asStateFlow()

  private val _isSyncing = MutableStateFlow(false)
  val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

  private val _isOnline = MutableStateFlow(true)
  val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

  private val _lastSyncTime = MutableStateFlow(prefs.getString("last_sync_time", "لم تتم المزامنة بعد") ?: "لم تتم المزامنة بعد")
  val lastSyncTime: StateFlow<String> = _lastSyncTime.asStateFlow()

  private val _syncErrorMessage = MutableStateFlow<String?>(null)
  val syncErrorMessage: StateFlow<String?> = _syncErrorMessage.asStateFlow()

  // ─── حالة الأدمن ───

  private val _pendingPayments = MutableStateFlow<List<PendingPayment>>(emptyList())
  val pendingPayments: StateFlow<List<PendingPayment>> = _pendingPayments.asStateFlow()

  private val _pendingSubscriptions = MutableStateFlow<List<PendingSubscription>>(emptyList())
  val pendingSubscriptions: StateFlow<List<PendingSubscription>> = _pendingSubscriptions.asStateFlow()

  private val _adminParticipants = MutableStateFlow<List<ParticipantAdminItem>>(emptyList())
  val adminParticipants: StateFlow<List<ParticipantAdminItem>> = _adminParticipants.asStateFlow()

  private val _adminBusinesses = MutableStateFlow<List<BusinessAdminItem>>(emptyList())
  val adminBusinesses: StateFlow<List<BusinessAdminItem>> = _adminBusinesses.asStateFlow()

  private val _adminEntitlements = MutableStateFlow<List<BusinessEntitlement>>(emptyList())
  val adminEntitlements: StateFlow<List<BusinessEntitlement>> = _adminEntitlements.asStateFlow()

  private val _auditLogs = MutableStateFlow<List<AuditLogItem>>(emptyList())
  val auditLogs: StateFlow<List<AuditLogItem>> = _auditLogs.asStateFlow()

  private val _apEarnings = MutableStateFlow<List<ApEarning>>(emptyList())
  val apEarnings: StateFlow<List<ApEarning>> = _apEarnings.asStateFlow()

  private val _workerUrl = MutableStateFlow(prefs.getString("worker_url", "") ?: "")
  val workerUrl: StateFlow<String> = _workerUrl.asStateFlow()

  // ─── طابور العمليات المؤجلة (Pending Offline Queue) ───
  private val _pendingActionsCount = MutableStateFlow(0)
  val pendingActionsCount: StateFlow<Int> = _pendingActionsCount.asStateFlow()

  private val _pendingActionsList = MutableStateFlow<List<PendingOfflineActionEntity>>(emptyList())
  val pendingActionsList: StateFlow<List<PendingOfflineActionEntity>> = _pendingActionsList.asStateFlow()

  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
  private var autoSyncJob: Job? = null

  init {
    val savedWorker = _workerUrl.value
    if (savedWorker.isNotBlank()) {
      NetworkClient.updateBaseUrl(savedWorker)
    }
    scope.launch {
      loadFromLocalCache()
      loadPendingActions()
      if (_isLoggedIn.value) {
        registerDeviceForPush()
        syncAllData()
        flushPendingOfflineActions()
        startAutoSync()
      }
    }
  }

  fun setWorkerUrl(url: String) {
    val clean = url.trim()
    _workerUrl.value = clean
    prefs.edit().putString("worker_url", clean).apply()
    if (clean.isNotBlank()) {
      NetworkClient.updateBaseUrl(clean)
    }
    if (_isLoggedIn.value) {
      scope.launch { syncAllData() }
    }
  }

  // ─── تسجيل الدخول / الخروج ───

  // ✅ جديد: تسجيل دخول حقيقي بحساب Google. بيستدعي Credential Manager للحصول على
  // idToken، بعدين يبعته لـ action=login في الباك اند اللي بيتحقق من توقيعه فعليًا
  // عبر جوجل (verifyGoogleIdToken) ويرجّع session token (UUID عبر CacheService).
  // ✅ إصلاح جوهري: signInWithGoogle كانت بتستخدم context الداخلي بتاع الـ Repository
  // (application.applicationContext من الـ ViewModel) — لكن CredentialManager.
  // getCredential() يتطلب فعليًا Activity Context عشان يقدر يعرض واجهة اختيار
  // الحساب (bottom sheet مرتبطة بنافذة نشاط حالي). Application Context مش مرتبط
  // بأي نافذة، فكان هيفشل وقت التشغيل. الحل: الدالة بقت تستقبل activityContext كـ
  // parameter صريح، يُمرَّر من الواجهة (LocalContext.current داخل composition
  // نشاط MainActivity)، بدل الاعتماد على context الداخلي.
  fun signInWithGoogle(activityContext: Context) {
    if (_isSigningIn.value) return
    _isSigningIn.value = true
    _loginErrorMessage.value = null
    scope.launch {
      try {
        when (val result = LavndrAuthManager.signIn(activityContext)) {
          is LavndrAuthManager.AuthResult.Success -> {
            val response = NetworkClient.apiService.login(
              mapOf("action" to "login", "idToken" to result.idToken)
            )
            val body = response.body()
            if (response.isSuccessful && body?.token != null && body.email != null) {
              applySession(body.token, body.email, body.role ?: "visitor")
            } else {
              _loginErrorMessage.value = body?.error ?: "فشل تسجيل الدخول — حاول مرة أخرى"
            }
          }
          is LavndrAuthManager.AuthResult.Failure -> {
            _loginErrorMessage.value = result.message
          }
        }
      } catch (e: Exception) {
        Log.e("LavndrRepo", "signInWithGoogle error: ${e.message}")
        _loginErrorMessage.value = "تعذّر الاتصال بالخادم — تحقق من اتصالك بالإنترنت"
      } finally {
        _isSigningIn.value = false
      }
    }
  }

  private fun applySession(token: String, email: String, roleValue: String) {
    _authToken.value = token
    _currentUserEmail.value = email
    _currentRole.value = UserRole.entries.find { it.apiValue == roleValue } ?: UserRole.VISITOR
    _isLoggedIn.value = true
    prefs.edit()
      .putString("auth_token", token)
      .putString("user_email", email)
      .putString("user_role", _currentRole.value.name)
      .apply()
    scope.launch {
      registerDeviceForPush()
      syncAllData()
      startAutoSync()
    }
  }

  // ✅ إشعارات الهاتف: يرسل توكن FCM للخادم ليربطه بإيميل المستخدم (فيصله إشعار اعتماد
  // اشتراكه/دفعته، والأدمن يصله إشعار فوري بأي طلب جديد). يفشل بصمت — الإشعار ميزة إضافية.
  private suspend fun registerDeviceForPush() {
    try {
      val token = kotlinx.coroutines.suspendCancellableCoroutine<String?> { cont ->
        com.google.firebase.messaging.FirebaseMessaging.getInstance().token
          .addOnSuccessListener { if (cont.isActive) cont.resume(it) {} }
          .addOnFailureListener { if (cont.isActive) cont.resume(null) {} }
      } ?: return
      prefs.edit().putString("fcm_token", token).apply()
      executeAction(
        mapOf("action" to "register_device", "token" to _authToken.value, "fcmToken" to token)
      ) {}
    } catch (e: Exception) {
      Log.w("LavndrRepo", "registerDeviceForPush failed: ${e.message}")
    }
  }

  // ✅ جديد: تسجيل خروج كامل — يصفّر كل حالة الجلسة والبيانات المعروضة، نفس مبدأ
  // clearSessionAndReset في dashboard.html. لا يوجد استدعاء "logout" في الباك اند
  // (التوكن مجرد مفتاح CacheService بينتهي من نفسه بعد 6 ساعات)، فالتنظيف كله محلي.
  fun signOut() {
    autoSyncJob?.cancel()
    _authToken.value = ""
    _currentUserEmail.value = ""
    _currentRole.value = UserRole.VISITOR
    _isLoggedIn.value = false
    // ✅ إصلاح: بدون ده، لو المستخدم سجّل خروج وهو في حالة role=visitor (needsSubscription
    // = true)، القيمة كانت تفضل true حتى بعد الخروج — يعني متصفح مجهول جديد (isLoggedIn
    // = false) ممكن يشوف بوابة الاشتراك غلط بدل وضع التصفح التجريبي العادي.
    _needsSubscription.value = false
    _data.value = PreviewDataProvider.getPreviewData()
    _participantInfo.value = null
    _businessPortal.value = BusinessPortalInfo(linked = false)
    _subscriptionStatus.value = SubscriptionStatus()
    _mySubscriptions.value = emptyList()
    selectedTier = null
    selectedCountry = null
    _pendingPayments.value = emptyList()
    _pendingSubscriptions.value = emptyList()
    _adminParticipants.value = emptyList()
    _adminBusinesses.value = emptyList()
    _adminEntitlements.value = emptyList()
    _auditLogs.value = emptyList()
    _apEarnings.value = emptyList()
    prefs.edit()
      .remove("auth_token")
      .remove("user_email")
      .remove("user_role")
      .apply()
  }

  // ✅ جديد: يتفحص لو رد أي استدعاء فيه code=401 (توكن غير صالح/منتهي) ويسجّل خروج
  // فورًا لو كده — بالظبط زي فحص data.code === 401 المتكرر في كل دالة بـ dashboard.html
  private fun handleUnauthorizedIfNeeded(code: Int?): Boolean {
    if (code == 401) {
      signOut()
      _loginErrorMessage.value = "انتهت الجلسة — سجّل الدخول مرة أخرى"
      return true
    }
    return false
  }

  fun clearLastActionError() {
    _lastActionError.value = null
  }

  fun clearLoginError() {
    _loginErrorMessage.value = null
  }

  fun refreshNow() {
    if (!_isLoggedIn.value) return
    scope.launch { syncAllData() }
  }

  // ✅ جديد: يجيب بيانات شهر محدد من Monthly_Snapshots/History (action=month) —
  // month=null يرجّع للعرض الساعي المباشر بدون أي نداء شبكة إضافي.
  fun selectMonth(month: String?) {
    _selectedMonth.value = month
    if (month == null) {
      _monthlyHistory.value = emptyList()
      return
    }
    scope.launch {
      try {
        val response = withContext(Dispatchers.IO) {
          NetworkClient.apiService.getMonth(month = month, token = _authToken.value)
        }
        val body = if (response.isSuccessful) {
          response.body()
        } else {
          // ✅ نفس إصلاح syncAllData/executeAction: لو HTTP status فشل (429 من
          // الـ Worker مثلًا)، response.body() = null ولازم نقرأ errorBody بدلها
          val errorText = try { response.errorBody()?.string() } catch (e: Exception) { null }
          if (!errorText.isNullOrBlank()) {
            try { monthlyHistoryAdapter.fromJson(errorText) } catch (e: Exception) { null }
          } else null
        }
        if (handleUnauthorizedIfNeeded(body?.code)) return@launch
        if (body != null && body.error == null) {
          _monthlyHistory.value = body.history
        } else {
          _monthlyHistory.value = emptyList()
          body?.error?.let { _lastActionError.value = it }
        }
      } catch (e: Exception) {
        Log.w("LavndrRepo", "getMonth error: ${e.message}")
        _monthlyHistory.value = emptyList()
      }
    }
  }

  private fun startAutoSync() {
    autoSyncJob?.cancel()
    autoSyncJob = scope.launch {
      while (isActive) {
        delay(30_000)
        if (_isLoggedIn.value) syncAllData()
      }
    }
  }

  // ─── المزامنة الأساسية ───

  suspend fun syncAllData() {
    if (!_isLoggedIn.value) return
    _isSyncing.value = true
    _syncErrorMessage.value = null
    try {
      val token = _authToken.value
      val response = withContext(Dispatchers.IO) { NetworkClient.apiService.getData(token = token) }

      if (response.isSuccessful && response.body() != null) {
        val liveData = response.body()!!
        if (handleUnauthorizedIfNeeded(liveData.code)) return
        if (liveData.code == 402) {
          // role=visitor — سجّل دخول بنجاح بس لسه ما اشتركش/انضمش.
          _needsSubscription.value = true
          _currentRole.value = UserRole.VISITOR
          _isOnline.value = true
        } else {
          _needsSubscription.value = false
          _data.value = liveData
          // ✅ الدور الفعلي بييجي كمان مع كل رد data (payload.role في الـ.gs) — نحدّثه
          // هنا عشان لو الأدمن غيّر دور المستخدم (مثلاً اعتماد اشتراك) يظهر فورًا
          UserRole.entries.find { it.apiValue == liveData.role }?.let { _currentRole.value = it }
          _isOnline.value = true
          val nowStr = java.text.SimpleDateFormat("HH:mm:ss (yyyy-MM-dd)", Locale.getDefault()).format(Date())
          _lastSyncTime.value = nowStr
          prefs.edit().putString("last_sync_time", nowStr).apply()
          try {
            dao.saveCachedIndexData(CachedIndexDataEntity(rawJson = dataAdapter.toJson(liveData)))
          } catch (e: Exception) {
            Log.e("LavndrRepo", "Error caching index data: ${e.message}")
          }
        }
      } else {
        // ✅ إصلاح جوهري: HTTP status غير 2xx هنا مصدره حصريًا الـ Cloudflare Worker
        // (403 Origin مرفوض، 413 حجم كبير، 429 rate limit، 502 GAS ما رد) — GAS نفسه
        // (ContentService.createTextOutput) بيرجّع 200 دايمًا مهما كان محتوى الرد.
        // قبل كده كنا بنفقد رسالة الخطأ الفعلية (زي "محاولات كتيرة جداً — حاول بعد
        // شوية") ونستبدلها برسالة تقنية عامة ("كود الخطأ: 429 ...") مالهاش فايدة
        // حقيقية للمستخدم. دلوقتي بنحاول نحلل errorBody كـ LavndrData (بما إنها كل
        // حقولها nullable/بقيم افتراضية، error/code هيتقروا صح حتى لو باقي الحقول مش موجودة).
        val errorText = try { response.errorBody()?.string() } catch (e: Exception) { null }
        val parsedError = if (!errorText.isNullOrBlank()) {
          try { dataAdapter.fromJson(errorText)?.error } catch (e: Exception) { null }
        } else null
        _isOnline.value = false
        _syncErrorMessage.value = parsedError ?: "خطأ من الخادم (HTTP ${response.code()}) — حاول تاني بعد لحظات"
      }

      fetchBankDetails()
      fetchSubscriptionStatus()
      if (_currentRole.value == UserRole.PARTICIPANT || _currentRole.value == UserRole.ADMIN) {
        fetchParticipantData()
      }
      fetchBusinessPortalData()
      if (_currentRole.value == UserRole.ADMIN) {
        fetchAdminData()
      }
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Network sync failed, falling back to cache: ${e.message}")
      _isOnline.value = false
      _syncErrorMessage.value = e.localizedMessage ?: "تعذر الاتصال بالخادم"
      loadFromLocalCache()
    } finally {
      _isSyncing.value = false
    }
  }

  private suspend fun fetchParticipantData() {
    val email = _currentUserEmail.value
    if (email.isBlank()) return
    try {
      val response = withContext(Dispatchers.IO) {
        NetworkClient.apiService.getParticipant(email = email, token = _authToken.value)
      }
      if (response.isSuccessful && response.body() != null) {
        val part = response.body()!!
        _participantInfo.value = part
        try {
          dao.saveCachedParticipant(CachedParticipantEntity(email = email, rawJson = participantAdapter.toJson(part)))
        } catch (e: Exception) {
          Log.e("LavndrRepo", "Error caching participant: ${e.message}")
        }
      }
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Participant fetch error: ${e.message}")
    }
  }

  private suspend fun fetchBusinessPortalData() {
    try {
      val response = withContext(Dispatchers.IO) {
        NetworkClient.apiService.getBusinessPortal(token = _authToken.value)
      }
      if (response.isSuccessful && response.body() != null) {
        val bp = response.body()!!
        _businessPortal.value = bp
        try {
          dao.saveCachedBusinessPortal(
            CachedBusinessPortalEntity(email = _currentUserEmail.value, rawJson = businessPortalAdapter.toJson(bp))
          )
        } catch (e: Exception) {
          Log.e("LavndrRepo", "Error caching business portal: ${e.message}")
        }
      }
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Business portal fetch error: ${e.message}")
    }
  }

  // آخر تبويب وصل إليه المستخدم (محفوظ على الخادم حسب الإيميل) — لا يتضمن أي بيانات حيّة
  suspend fun fetchSavedTab(): String? {
    return try {
      val r = withContext(Dispatchers.IO) { NetworkClient.apiService.getProgress(token = _authToken.value) }
      val st = r.body()?.state
      if (r.isSuccessful && st?.page == "app") st.screen else null
    } catch (e: Exception) { null }
  }

  suspend fun saveTab(screen: String, space: String) {
    executeAction(
      mapOf("action" to "save_progress", "token" to _authToken.value,
        "state" to mapOf("page" to "app", "screen" to screen, "space" to space))
    ) { }
  }

  // شروط باقة محددة (لكل مسار وباقة نص خاص بها) — تُجلب عند الحاجة فقط
  suspend fun loadTermsFor(tier: String) {
    _termsText.value = ""
    try {
      val response = withContext(Dispatchers.IO) { NetworkClient.apiService.getTerms(token = _authToken.value, tier = tier) }
      if (response.isSuccessful && response.body() != null) {
        _termsText.value = response.body()!!.text
      }
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Terms fetch error: ${e.message}")
    }
  }

  private suspend fun fetchBankDetails() {
    try {
      val response = withContext(Dispatchers.IO) { NetworkClient.apiService.getBankDetails(token = _authToken.value) }
      if (response.isSuccessful && response.body() != null) {
        _bankDetails.value = response.body()!!
      }
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Bank details fetch error: ${e.message}")
    }
  }

  private suspend fun fetchSubscriptionStatus() {
    try {
      val response = withContext(Dispatchers.IO) {
        NetworkClient.apiService.getSubscriptionStatus(
          token = _authToken.value, tier = selectedTier, country = selectedCountry
        )
      }
      if (response.isSuccessful && response.body() != null) {
        _subscriptionStatus.value = response.body()!!
      }
      val mine = withContext(Dispatchers.IO) { NetworkClient.apiService.getMySubscriptions(token = _authToken.value) }
      if (mine.isSuccessful) _mySubscriptions.value = mine.body()?.items ?: emptyList()
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Subscription status fetch error: ${e.message}")
    }
  }

  private suspend fun fetchAdminData() {
    try {
      val token = _authToken.value
      withContext(Dispatchers.IO) { NetworkClient.apiService.getAdminPendingPayments(token = token) }
        .body()?.let { _pendingPayments.value = it.rows }
      withContext(Dispatchers.IO) { NetworkClient.apiService.getAdminPendingSubscriptions(token = token) }
        .body()?.let { _pendingSubscriptions.value = it.rows }
      withContext(Dispatchers.IO) { NetworkClient.apiService.getAdminParticipants(token = token) }
        .body()?.let { _adminParticipants.value = it.rows }
      withContext(Dispatchers.IO) { NetworkClient.apiService.getAdminBusinesses(token = token) }
        .body()?.let { _adminBusinesses.value = it.rows }
      withContext(Dispatchers.IO) { NetworkClient.apiService.getAdminEntitlements(token = token) }
        .body()?.let { _adminEntitlements.value = it.rows }
      withContext(Dispatchers.IO) { NetworkClient.apiService.getAdminAuditLog(token = token) }
        .body()?.let { _auditLogs.value = it.rows }
      withContext(Dispatchers.IO) { NetworkClient.apiService.getApEarnings(token = token) }
        .body()?.let { _apEarnings.value = it.rows }
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Admin data fetch error: ${e.message}")
    }
  }

  // ✅ جديد: دليل الـ120 نشاط — حصري لمشترك باقة ماقما (الباك اند برضو بيرفض 403
  // لغير role=magma/admin، هنا مجرد استدعاء الشبكة).
  suspend fun loadMagmaDirectory() {
    if (!_isLoggedIn.value) return
    try {
      withContext(Dispatchers.IO) { NetworkClient.apiService.getMagmaDirectory(token = _authToken.value) }
        .body()?.let { _magmaDirectory.value = it }
    } catch (e: Exception) {
      Log.w("LavndrRepo", "Magma directory fetch error: ${e.message}")
    }
  }

  // ✅ جديد: تسجيل "مرة واحدة تكفي" لاطلاع مشترك ماقما على بزنس معيّن، بعدها نحدّث
  // الدليل فورًا عشان العداد/العلامة (✓ تم الاطلاع) تتغيّر في نفس اللحظة.
  suspend fun markMagmaBusinessViewed(sheetId: String): ActionResult {
    return executeAction(
      mapOf("action" to "magma_mark_viewed", "token" to _authToken.value, "sheetId" to sheetId)
    ) { loadMagmaDirectory() }
  }

  private suspend fun loadFromLocalCache() {
    try {
      dao.getCachedIndexData()?.let { cached ->
        dataAdapter.fromJson(cached.rawJson)?.let { _data.value = it }
      }
      if (_currentUserEmail.value.isNotBlank()) {
        dao.getCachedParticipant(_currentUserEmail.value)?.let { cached ->
          participantAdapter.fromJson(cached.rawJson)?.let { _participantInfo.value = it }
        }
        dao.getCachedBusinessPortal(_currentUserEmail.value)?.let { cached ->
          businessPortalAdapter.fromJson(cached.rawJson)?.let { _businessPortal.value = it }
        }
      }
    } catch (e: Exception) {
      Log.e("LavndrRepo", "Error reading local cache: ${e.message}")
    }
  }

  // ─── العمليات الحساسة (اشتراك/دفع) — كل واحدة بتنفّذ فعليًا وتستنى الرد قبل
  // ما تحدّث أي حالة، بدل الـ optimistic update الوهمي القديم ───

  suspend fun buyShare(marketRow: Int? = null): ActionResult {
    val payload = mutableMapOf<String, Any?>(
      "action" to "buy",
      "email" to _currentUserEmail.value,
      "token" to _authToken.value
    )
    if (marketRow != null) payload["marketRow"] = marketRow
    return executeAction(payload, canQueueOffline = true) { syncAllData() }
  }

  suspend fun submitPaymentVerification(otp: String, txnRef: String): ActionResult {
    if (otp.isBlank() || txnRef.isBlank()) {
      return ActionResult(error = "يرجى إدخال رمز التحقق ورقم مرجع المعاملة البنكية")
    }
    val payload = mapOf<String, Any?>(
      "action" to "verify_payment",
      "token" to _authToken.value,
      "otp" to otp,
      "txnRef" to txnRef
    )
    return executeAction(payload, canQueueOffline = true) { syncAllData() }
  }

  suspend fun subscribe(tier: String, country: String = ""): ActionResult {
    val payload = mapOf<String, Any?>(
      "action" to "subscribe",
      "token" to _authToken.value,
      "tier" to tier,
      "country" to country
    )
    return executeAction(payload, canQueueOffline = true) { fetchSubscriptionStatus() }
  }

  // ✅ جديد: زر "ادفع" الوحيد للفرانشايز — يفتح الدفعة التالية بنفس مسار الرمز/المرجع/المراجعة
  suspend fun payFranchise(): ActionResult {
    val payload = mapOf<String, Any?>(
      "action" to "franchise_pay",
      "token" to _authToken.value
    )
    return executeAction(payload, canQueueOffline = false) { fetchSubscriptionStatus() }
  }

  // اختيار اشتراك من قائمة اشتراكاتي (null = الرجوع للقائمة)
  suspend fun selectSubscription(tier: String?, country: String?) {
    selectedTier = tier
    selectedCountry = country
    fetchSubscriptionStatus()
  }

  // زر "اشترك الآن — تابع للدفع" لمن في قائمة الانتظار: يرسل الرمز للإيميل
  suspend fun prepaySubscription(tier: String, country: String = ""): ActionResult {
    val payload = mapOf<String, Any?>(
      "action" to "subscription_prepay",
      "token" to _authToken.value,
      "tier" to tier,
      "country" to country
    )
    selectedTier = tier
    selectedCountry = country.ifBlank { null }
    return executeAction(payload, canQueueOffline = false) { fetchSubscriptionStatus() }
  }

  suspend fun submitSubscriptionVerification(otp: String, txnRef: String): ActionResult {
    if (otp.isBlank() || txnRef.isBlank()) {
      return ActionResult(error = "يرجى إدخال رمز التحقق ورقم المرجع البنكي")
    }
    val payload = mapOf<String, Any?>(
      "action" to "verify_subscription",
      "token" to _authToken.value,
      "otp" to otp,
      "txnRef" to txnRef,
      "tier" to (selectedTier ?: _subscriptionStatus.value.tier),
      "country" to (selectedCountry ?: _subscriptionStatus.value.country ?: "")
    )
    return executeAction(payload, canQueueOffline = true) { fetchSubscriptionStatus() }
  }

  suspend fun sellShare(): ActionResult {
    return executeAction(
      mapOf(
        "action" to "sell",
        "email" to _currentUserEmail.value,
        "token" to _authToken.value
      ),
      canQueueOffline = true
    ) { syncAllData() }
  }

  // الموافقة على شروط باقة محددة (لا توجد موافقة عامة تغطي كل الباقات)
  suspend fun acceptTerms(tier: String): ActionResult {
    return executeAction(mapOf("action" to "accept_terms", "token" to _authToken.value, "tier" to tier)) {}
  }

  // ─── عمليات الأدمن ───

  suspend fun decidePayment(row: Int, decision: String): ActionResult {
    return executeAction(
      mapOf("action" to "admin_decide_payment", "token" to _authToken.value, "row" to row, "decision" to decision)
    ) { fetchAdminData() }
  }

  suspend fun decideSubscription(row: Int, decision: String): ActionResult {
    return executeAction(
      mapOf("action" to "admin_decide_subscription", "token" to _authToken.value, "row" to row, "decision" to decision)
    ) { fetchAdminData() }
  }

  suspend fun linkBusinessToEmail(sheetId: String, email: String, businessName: String): ActionResult {
    return executeAction(
      mapOf(
        "action" to "link_business", "token" to _authToken.value,
        "sheetId" to sheetId, "email" to email, "businessName" to businessName
      )
    ) { fetchAdminData() }
  }

  // ✅ يفرّق بين set_auto_accept (أدمن، لأي بزنس) وset_my_auto_accept (البزنس لنفسه
  // من بورتاله) حسب الدور الحالي — بالظبط زي toggleBusinessAutoAccept القديمة، لكن
  // دلوقتي بيستنى الرد الفعلي.
  suspend fun toggleBusinessAutoAccept(sheetId: String, enabled: Boolean): ActionResult {
    val action = if (_currentRole.value == UserRole.ADMIN) "set_auto_accept" else "set_my_auto_accept"
    return executeAction(
      mapOf("action" to action, "token" to _authToken.value, "sheetId" to sheetId, "enabled" to enabled)
    ) { if (_currentRole.value == UserRole.ADMIN) fetchAdminData() else fetchBusinessPortalData() }
  }

  suspend fun submitAgreementLink(sheetId: String, link: String): ActionResult =
    executeAction(mapOf("action" to "submit_agreement", "token" to _authToken.value, "sheetId" to sheetId, "link" to link)) { fetchBusinessPortalData() }

  suspend fun requestCash(sheetId: String): ActionResult =
    executeAction(mapOf("action" to "request_cash", "token" to _authToken.value, "sheetId" to sheetId)) { fetchBusinessPortalData() }

  suspend fun toggleBusinessClosed(sheetId: String, closed: Boolean): ActionResult {
    val action = if (closed) "close_business" else "reopen_business"
    return executeAction(
      mapOf("action" to action, "token" to _authToken.value, "sheetId" to sheetId)
    ) { fetchAdminData() }
  }

  suspend fun acceptBusinessEntitlement(row: Int): ActionResult {
    return executeAction(
      mapOf("action" to "accept_entitlement", "token" to _authToken.value, "row" to row)
    ) { fetchAdminData() }
  }

  suspend fun confirmGuaranteeReceived(row: Int): ActionResult {
    return executeAction(
      mapOf("action" to "confirm_guarantee", "token" to _authToken.value, "row" to row)
    ) { fetchAdminData() }
  }

  // ✅ نقطة مركزية واحدة لكل استدعاء POST حساس — تنفّذ الطلب فعليًا وتستنى الرد،
  // تتعامل مع 401/451 بشكل موحّد، وتحدّث _lastActionError بدل التجاهل الصامت.
  // الـ onSuccess callback بيسمح لكل دالة تحدّد بنفسها إيه اللي يتحدّث بعد النجاح
  // (مش دايمًا محتاجين syncAllData كامل — أحيانًا كفاية fetchAdminData بس مثلاً).
  private val actionResultAdapter = moshi.adapter(ActionResult::class.java)
  private val monthlyHistoryAdapter = moshi.adapter(MonthlyHistoryResponse::class.java)

  // ✅ إصلاح جوهري: Retrofit بيرجّع response.body() = null دائمًا لو الـ HTTP status
  // مش 2xx — لكن الـ Cloudflare Worker فعليًا بيرجّع status codes غير 2xx في حالات
  // حقيقية ومتوقعة (403 Origin مرفوض، 413 حجم كبير، 429 rate limit، 502 GAS ما رد).
  // كل هذه الحالات بترجع body فعلي وواضح ({error, code}) لكنه كان بيضيع بالكامل
  // ويظهر بدله رسالة عامة "رد غير متوقع من الخادم" تخفي السبب الحقيقي (خصوصًا 429
  // اللي المستخدم محتاج يعرف إنه لازم يستنى شوية، مش إن في خطأ عام غامض).
  private fun parseActionResult(response: retrofit2.Response<ActionResult>): ActionResult {
    response.body()?.let { return it }
    val errorText = try { response.errorBody()?.string() } catch (e: Exception) { null }
    if (!errorText.isNullOrBlank()) {
      try {
        actionResultAdapter.fromJson(errorText)?.let { return it }
      } catch (e: Exception) {
        Log.w("LavndrRepo", "Failed to parse errorBody as ActionResult: ${e.message}")
      }
    }
    return ActionResult(error = "خطأ من الخادم (HTTP ${response.code()}) — حاول تاني")
  }

  suspend fun loadPendingActions() {
    try {
      val actions = dao.getAllPendingActions()
      _pendingActionsList.value = actions
      _pendingActionsCount.value = actions.size
    } catch (e: Exception) {
      Log.e("LavndrRepo", "Failed to load pending actions: ${e.message}")
    }
  }

  suspend fun flushPendingOfflineActions(): Int {
    if (!_isLoggedIn.value || !_isOnline.value) return 0
    val actions = dao.getAllPendingActions()
    var successCount = 0
    for (action in actions) {
      try {
        val payload = anyMapAdapter.fromJson(action.payloadJson) ?: continue
        val requestBody = anyMapAdapter.toJson(payload).toRequestBody(jsonMediaType)
        val response = withContext(Dispatchers.IO) { NetworkClient.apiService.postAction(requestBody) }
        val body = parseActionResult(response)
        if (body.error == null || body.success == true) {
          dao.deletePendingActionById(action.id)
          successCount++
        }
      } catch (e: Exception) {
        Log.w("LavndrRepo", "Failed to flush action #${action.id}: ${e.message}")
      }
    }
    loadPendingActions()
    if (successCount > 0) {
      syncAllData()
    }
    return successCount
  }

  private suspend fun queueOfflineAction(payload: Map<String, Any?>): ActionResult {
    return try {
      val actionName = payload["action"]?.toString() ?: "unknown"
      val jsonStr = anyMapAdapter.toJson(payload)
      dao.enqueueAction(PendingOfflineActionEntity(actionType = actionName, payloadJson = jsonStr))
      loadPendingActions()
      ActionResult(
        success = true,
        message = "تم حفظ العملية في طابور عدم الاتصال وسيتم إرسالها تلقائياً فور توفر الإنترنت 📡"
      )
    } catch (e: Exception) {
      Log.e("LavndrRepo", "Failed to queue offline action: ${e.message}")
      ActionResult(error = "تعذّر حفظ العملية في وضع عدم الاتصال")
    }
  }

  private suspend fun executeAction(
    payload: Map<String, Any?>,
    canQueueOffline: Boolean = false,
    onSuccess: suspend () -> Unit
  ): ActionResult {
    return try {
      val jsonBody = anyMapAdapter.toJson(payload)
      val requestBody = jsonBody.toRequestBody(jsonMediaType)
      val response = withContext(Dispatchers.IO) { NetworkClient.apiService.postAction(requestBody) }
      val body = parseActionResult(response)
      if (handleUnauthorizedIfNeeded(body.code)) {
        return body
      }
      if (body.error != null) {
        _lastActionError.value = body.error
      } else {
        onSuccess()
      }
      body
    } catch (e: Exception) {
      Log.e("LavndrRepo", "executeAction error: ${e.message}")
      if (canQueueOffline) {
        val queuedResult = queueOfflineAction(payload)
        _lastActionError.value = null
        return queuedResult
      }
      val err = ActionResult(error = "تعذّر الاتصال بالخادم — تحقق من اتصالك بالإنترنت")
      _lastActionError.value = err.error
      err
    }
  }
}

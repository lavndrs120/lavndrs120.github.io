package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

enum class NotificationSoundType {
  GENERAL,
  PRICE_TARGET,
  PAYMENT_SUCCESS,
  MARKET_ALERT
}

object NotificationSoundManager {
  private const val TAG = "LavndrSound"
  private const val PREFS_NAME = "lavndr_sound_settings"
  private const val KEY_SOUND_ENABLED = "sound_enabled"
  private const val KEY_VIBRATION_ENABLED = "vibration_enabled"
  private const val KEY_SOUND_STYLE = "sound_style" // "system", "chime", "trader"

  private fun getPrefs(context: Context): SharedPreferences {
    return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  }

  fun isSoundEnabled(context: Context): Boolean {
    return getPrefs(context).getBoolean(KEY_SOUND_ENABLED, true)
  }

  fun setSoundEnabled(context: Context, enabled: Boolean) {
    getPrefs(context).edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
  }

  fun isVibrationEnabled(context: Context): Boolean {
    return getPrefs(context).getBoolean(KEY_VIBRATION_ENABLED, true)
  }

  fun setVibrationEnabled(context: Context, enabled: Boolean) {
    getPrefs(context).edit().putBoolean(KEY_VIBRATION_ENABLED, enabled).apply()
  }

  fun getSoundStyle(context: Context): String {
    return getPrefs(context).getString(KEY_SOUND_STYLE, "trader") ?: "trader"
  }

  fun setSoundStyle(context: Context, style: String) {
    getPrefs(context).edit().putString(KEY_SOUND_STYLE, style).apply()
  }

  /**
   * Plays the designated notification sound & haptic feedback according to user preferences.
   */
  fun play(context: Context, type: NotificationSoundType = NotificationSoundType.GENERAL) {
    if (!isSoundEnabled(context)) {
      if (isVibrationEnabled(context)) {
        triggerVibration(context, type)
      }
      return
    }

    try {
      val style = getSoundStyle(context)

      // 1. Play Tone or Ringtone based on selected audio style
      when (style) {
        "system" -> playSystemRingtone(context)
        "trader" -> playTraderMelody(type)
        else -> {
          playSystemRingtone(context)
          playTraderMelody(type)
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "Failed playing notification sound: ${e.message}")
      playSystemRingtone(context)
    }

    if (isVibrationEnabled(context)) {
      triggerVibration(context, type)
    }
  }

  private fun playSystemRingtone(context: Context) {
    try {
      val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
      val ringtone = RingtoneManager.getRingtone(context.applicationContext, notificationUri)
      if (ringtone != null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
          ringtone.audioAttributes = AudioAttributes.Builder()
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .build()
        }
        ringtone.play()
      }
    } catch (e: Exception) {
      Log.w(TAG, "Could not play system ringtone: ${e.message}")
    }
  }

  private fun playTraderMelody(type: NotificationSoundType) {
    Thread {
      try {
        val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
        when (type) {
          NotificationSoundType.PRICE_TARGET -> {
            // Ascending celebration chime: High double tone
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 180)
            Thread.sleep(200)
            toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 250)
          }
          NotificationSoundType.PAYMENT_SUCCESS -> {
            // Confirmation chord
            toneGen.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 250)
          }
          NotificationSoundType.MARKET_ALERT -> {
            // Distinct alert pulse
            toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200)
          }
          NotificationSoundType.GENERAL -> {
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
          }
        }
        Thread.sleep(300)
        toneGen.release()
      } catch (e: Exception) {
        Log.w(TAG, "ToneGenerator error: ${e.message}")
      }
    }.start()
  }

  private fun triggerVibration(context: Context, type: NotificationSoundType) {
    try {
      val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      } ?: return

      val timings = when (type) {
        NotificationSoundType.PRICE_TARGET -> longArrayOf(0, 150, 100, 250)
        NotificationSoundType.PAYMENT_SUCCESS -> longArrayOf(0, 100, 80, 100)
        else -> longArrayOf(0, 200)
      }

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val effect = VibrationEffect.createWaveform(timings, -1)
        vibrator.vibrate(effect)
      } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(timings, -1)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Vibration failed: ${e.message}")
    }
  }
}

package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.BankDetails
import com.example.data.model.UserRole
import com.example.ui.theme.*
import com.example.util.NotificationSoundManager
import com.example.util.NotificationSoundType
import java.util.Locale

@Composable
fun TermsDialog(
  termsText: String,
  title: String = "شروط الباقة",
  onAccept: () -> Unit,
  onDismiss: () -> Unit
) {
  var isChecked by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = {}) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Text(
          text = title,
          color = LavndrGold,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "LAVNDR120",
          color = LavndrTextDim,
          fontSize = 11.sp,
          modifier = Modifier.padding(bottom = 12.dp)
        )

        // ✅ إصلاح: النص بقى قادم فعليًا من الباك اند (action=terms → getTermsText())
        // بدل نص ثابت مكتوب هنا يدويًا وممكن يختلف عن النسخة الرسمية أو رقم إصدارها
        // (CONFIG.TERMS_VERSION) لو الأدمن غيّرها من السيرفر.
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .background(LavndrVoid, RoundedCornerShape(10.dp))
            .border(1.dp, LavndrGlassBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
        ) {
          Text(
            text = termsText.ifBlank { "جاري تحميل الشروط..." },
            color = LavndrText,
            fontSize = 12.sp,
            lineHeight = 18.sp
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          Checkbox(
            checked = isChecked,
            onCheckedChange = { isChecked = it },
            colors = CheckboxDefaults.colors(
              checkedColor = LavndrGold,
              uncheckedColor = LavndrTextDim,
              checkmarkColor = LavndrVoid
            )
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "قرأت وفهمت وأوافق على الشروط أعلاه",
            color = LavndrText,
            fontSize = 12.sp
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = onAccept,
          enabled = isChecked && termsText.isNotBlank(),
          colors = ButtonDefaults.buttonColors(
            containerColor = LavndrGold,
            contentColor = LavndrVoid
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("accept_terms_button")
        ) {
          Text("موافق ومتابعة", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedButton(
          onClick = onDismiss,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = LavndrTextDim),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("لا أوافق (إلغاء)")
        }
      }
    }
  }
}

@Composable
fun PaymentModal(
  amount: Double,
  stage: String?, // "awaiting_otp", "awaiting_review"
  bankDetails: BankDetails,
  isSubmitting: Boolean,
  errorMessage: String?,
  onSubmitVerification: (otp: String, txnRef: String) -> Unit,
  onDismiss: () -> Unit
) {
  var otpInput by remember { mutableStateOf("") }
  var txnRefInput by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "تفاصيل التحويل البنكي",
            color = LavndrGold,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = LavndrTextDim)
          }
        }

        if (stage == "awaiting_review") {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 24.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(text = "⏳", fontSize = 42.sp)
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "طلبك بانتظار مراجعة الأدمن",
                color = LavndrGold,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "استلمنا رقم المعاملة بقيمة $$amount. يتم تفعيل حصتك تلقائياً بعد مراجعة التحويل البنكي.",
                color = LavndrTextDim,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
              )
            }
          }
        } else {
          Text(
            text = "حوّل ما يعادل $${String.format(Locale.US, "%.2f", amount)} بالجنيه السوداني",
            color = LavndrText,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
          )

          Card(
            colors = CardDefaults.cardColors(containerColor = LavndrVoid),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, LavndrGlassBorder, RoundedCornerShape(12.dp))
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              BankRow(label = "البنك", value = bankDetails.bankName)
              BankRow(label = "اسم الحساب", value = bankDetails.accountHolder)
              BankRow(label = "رقم الحساب", value = bankDetails.accountNumber)
              BankRow(label = "IBAN", value = bankDetails.iban)
              BankRow(label = "BBAN", value = bankDetails.bban)
              BankRow(label = "الفرع", value = bankDetails.branch)
              BankRow(label = "العملة", value = bankDetails.currency)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = "أدخل رمز التحقق المرسل لك مع رقم مرجع المعاملة البنكية:",
            color = LavndrTextDim,
            fontSize = 11.sp
          )
          Spacer(modifier = Modifier.height(8.dp))

          OutlinedTextField(
            value = otpInput,
            onValueChange = { otpInput = it },
            placeholder = { Text("رمز التحقق (6 أرقام)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = LavndrGold,
              unfocusedBorderColor = LavndrGlassBorder,
              focusedTextColor = LavndrText,
              unfocusedTextColor = LavndrText
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("otp_input")
          )

          Spacer(modifier = Modifier.height(8.dp))

          OutlinedTextField(
            value = txnRefInput,
            onValueChange = { txnRefInput = it },
            placeholder = { Text("رقم / مرجع المعاملة (من إشعار البنك)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = LavndrGold,
              unfocusedBorderColor = LavndrGlassBorder,
              focusedTextColor = LavndrText,
              unfocusedTextColor = LavndrText
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("txn_ref_input")
          )

          Spacer(modifier = Modifier.height(14.dp))

          if (errorMessage != null) {
            Text(
              text = errorMessage,
              color = LavndrRed,
              fontSize = 12.sp,
              modifier = Modifier.padding(bottom = 8.dp)
            )
          }

          Button(
            onClick = { onSubmitVerification(otpInput, txnRefInput) },
            enabled = otpInput.isNotBlank() && txnRefInput.isNotBlank() && !isSubmitting,
            colors = ButtonDefaults.buttonColors(
              containerColor = LavndrGold,
              contentColor = LavndrVoid
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("submit_payment_button")
          ) {
            if (isSubmitting) {
              CircularProgressIndicator(modifier = Modifier.size(18.dp), color = LavndrVoid, strokeWidth = 2.dp)
            } else {
              Text("تأكيد الدفعة وإرسالها للمراجعة", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

@Composable
fun SubscriptionModal(
  onSubscribe: (tier: String) -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
    ) {
      Column(
        modifier = Modifier.padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "اشتراك مطالعة بيانات السوق",
            color = LavndrGold,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = LavndrTextDim)
          }
        }
        Text(
          text = "يتيح لك مطالعة أوزان الـ120 نشاط، وترتيب الطلبات والتحليلات المباشرة.",
          color = LavndrTextDim,
          fontSize = 11.sp,
          textAlign = TextAlign.Start,
          modifier = Modifier.padding(bottom = 16.dp)
        )

        // Lava tier
        Card(
          colors = CardDefaults.cardColors(containerColor = LavndrVoid),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, LavndrGlassBorder, RoundedCornerShape(14.dp))
            .padding(12.dp)
        ) {
          Column {
            Text("باقة لافا (24 ساعة)", color = LavndrGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("$1.40 فقط", color = LavndrText, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("وصول كامل لبيانات السوق لمدة 24 ساعة", color = LavndrTextDim, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Button(
              onClick = { onSubscribe("lava") },
              colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("اشترك في لافا ($1.40)", fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Annual tier
        Card(
          colors = CardDefaults.cardColors(containerColor = LavndrVoid),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, LavndrGold, RoundedCornerShape(14.dp))
            .padding(12.dp)
        ) {
          Column {
            Text("الباقة السنوية (12 شهر)", color = LavndrGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("$249.00 / سنة", color = LavndrText, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("توفير كبير مع وصول مستمر لمدة عام كامل", color = LavndrTextDim, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Button(
              onClick = { onSubscribe("annual") },
              colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("اشترك في الباقة السنوية ($249)", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

// ✅ حُذفت: RoleSwitcherDialog و UserLoginDialog كانتا تسمحان بتبديل الدور
// (بما فيه "أدمن") وكتابة إيميل/توكن يدويًا بدون أي تحقق فعلي — تجاوز كامل
// لطبقة المصادقة. الدور الحقيقي بييجي حصريًا من الباك اند (getUserRole عبر
// action=login وaction=data)، والتوكن بييجي حصريًا من تسجيل دخول Google حقيقي
// عبر LavndrAuthManager. راجع GoogleSignInScreen.kt للشاشة البديلة.

// ✅ جديد: قائمة حساب بسيطة — تسجيل خروج حقيقي (يمسح الجلسة محليًا) + وصول
// لإعدادات الـ Worker الفنية (مفيدة وقت التطوير/الاختبار بس). بديل الديالوجات
// الوهمية القديمة.
@Composable
fun AccountMenuDialog(
  email: String,
  roleLabel: String,
  currentRole: UserRole = UserRole.VISITOR,
  isLoggedIn: Boolean = true,
  pendingActionsCount: Int,
  onFlushPendingActions: () -> Unit,
  onSignInClick: () -> Unit = {},
  onSubscribeClick: () -> Unit = {},
  onSignOut: () -> Unit,
  onOpenWorkerSettings: () -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isLoggedIn) "بيانات الحساب" else "حساب الزائر (معاينة)",
            color = LavndrGold,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = LavndrTextDim)
          }
        }

        if (!isLoggedIn) {
          Surface(
            color = LavndrVoid,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, LavndrGlassBorder),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 10.dp)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = "مستويات العضوية والاشتراك:",
                color = LavndrGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "💼 1. الأنشطة التجارية الـ 120:\nمضافة مسبقاً بالنظام. سجّل دخولك بحساب Google المعتمد لتفعيل كامل النظام (الداتا الحقيقية وبوابة البزنس).",
                color = LavndrText,
                fontSize = 11.sp,
                lineHeight = 16.sp
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "💎 2. باقات الانضمام:\nمسار «انضم إلى لاڤندرز» (لافا، ڤندكس، ماقما) ومسار «البناء والحركة الاقتصادية» (OMS، ريسيلر، فرانشايز، تايكون). اختر باقتك وأكمل الدفع.",
                color = LavndrTextDim,
                fontSize = 11.sp,
                lineHeight = 16.sp
              )
            }
          }

          Button(
            onClick = {
              onDismiss()
              onSignInClick()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF1F1F1F)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(
              painter = painterResource(id = R.drawable.ic_google_logo),
              contentDescription = "Google",
              tint = Color.Unspecified,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("تسجيل الدخول بحساب Google", fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(8.dp))

          OutlinedButton(
            onClick = {
              onDismiss()
              onSubscribeClick()
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = LavndrGold),
            border = androidx.compose.foundation.BorderStroke(1.dp, LavndrGold),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("💎 الاشتراك في باقة الداتا (يومي / سنوي)", fontWeight = FontWeight.Bold)
          }
        } else {
          Text(text = email, color = LavndrText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          Text(
            text = roleLabel,
            color = LavndrGold,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
          )

          // بطاقة توضيح الصلاحيات الفعلية للحساب المسجل
          Surface(
            color = LavndrVoid,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 12.dp)
          ) {
            Text(
              text = when (currentRole) {
                UserRole.ADMIN -> "🛡️ صلاحيات مسؤول كاملة: الإشراف الإداري والمالي."
                UserRole.PARTICIPANT -> "💼 شريك معتمد: وصول كامل للداتا الحقيقية + بوابة البزنس."
                UserRole.FENDEX -> "🔮 عضو ڤندكس: داتا السوق الحقيقية + تقارير الأوراكل التنبؤية."
                UserRole.MAGMA -> "🌋 عضو ماقما: داتا السوق الحقيقية + دليل الـ120 نشاط مرتبين حسب وزنهم الاستهلاكي."
                UserRole.SUBSCRIBER -> "🟢 مشترك داتا نشط: مطالعة وتحليل البيانات الحقيقية المباشرة."
                UserRole.VISITOR -> "👁️ متصفح: بدون اشتراك نشط. فعّل باقة الداتا لمطالعة البيانات الحقيقية."
              },
              color = LavndrTextDim,
              fontSize = 11.sp,
              modifier = Modifier.padding(10.dp)
            )
          }

          if (currentRole == UserRole.VISITOR) {
            Button(
              onClick = {
                onDismiss()
                onSubscribeClick()
              },
              colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
              Text("💎 تفعيل اشتراك الداتا (يومي / سنوي)", fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // إعدادات التنبيه الصوتي للإشعارات
        var soundEnabled by remember { mutableStateOf(NotificationSoundManager.isSoundEnabled(context)) }
        var vibrationEnabled by remember { mutableStateOf(NotificationSoundManager.isVibrationEnabled(context)) }

        Surface(
          color = LavndrVoid,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "🔊 التنبيه الصوتي للإشعارات",
                  color = LavndrText,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Medium
                )
                Text(
                  text = if (soundEnabled) "تشغيل نغمات العمليات وتحركات السوق" else "الوضع الصامت للإشعارات",
                  color = if (soundEnabled) LavndrEmerald else LavndrTextFaint,
                  fontSize = 10.sp
                )
              }
              Switch(
                checked = soundEnabled,
                onCheckedChange = {
                  soundEnabled = it
                  NotificationSoundManager.setSoundEnabled(context, it)
                },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = LavndrGold,
                  checkedTrackColor = LavndrGoldDim
                )
              )
            }

            if (soundEnabled) {
              Spacer(modifier = Modifier.height(8.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                OutlinedButton(
                  onClick = {
                    NotificationSoundManager.play(context, NotificationSoundType.PAYMENT_SUCCESS)
                  },
                  shape = RoundedCornerShape(8.dp),
                  border = androidx.compose.foundation.BorderStroke(1.dp, LavndrGold.copy(alpha = 0.5f)),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = LavndrGold),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("🎵 تجربة نغمة الدفع", fontSize = 10.sp)
                }
                OutlinedButton(
                  onClick = {
                    NotificationSoundManager.play(context, NotificationSoundType.PRICE_TARGET)
                  },
                  shape = RoundedCornerShape(8.dp),
                  border = androidx.compose.foundation.BorderStroke(1.dp, LavndrEmerald.copy(alpha = 0.5f)),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = LavndrEmerald),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("🎯 نغمة الهدف", fontSize = 10.sp)
                }
              }
            }
          }
        }

        if (pendingActionsCount > 0) {
          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            color = LavndrGoldDim.copy(alpha = 0.3f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("📡 طابور العمليات المؤجلة", color = LavndrGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("$pendingActionsCount عملية بانتظار الإرسال للسيرفر", color = LavndrTextDim, fontSize = 10.sp)
              }
              IconButton(onClick = onFlushPendingActions) {
                Icon(Icons.Default.Refresh, contentDescription = "Sync Queue", tint = LavndrGold)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = {
            val waUri = android.net.Uri.parse("https://wa.me/201016833923?text=" + android.net.Uri.encode("مرحباً فريق لافندر 120، لدي استفسار من الحساب: $email"))
            val intent = Intent(Intent.ACTION_VIEW, waUri)
            context.startActivity(intent)
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF25D366),
            contentColor = Color.White
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("💬 الدعم الفني والمالي (واتساب)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
          onClick = onOpenWorkerSettings,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("إعدادات الاتصال (Worker)", color = LavndrTextDim)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
          onClick = onSignOut,
          colors = ButtonDefaults.buttonColors(containerColor = LavndrRed.copy(alpha = 0.15f), contentColor = LavndrRed),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("تسجيل الخروج", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun ConfigWorkerDialog(
  currentUrl: String,
  isOnline: Boolean,
  lastSync: String,
  onSave: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var urlInput by remember { mutableStateOf(currentUrl) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text(
          text = "إعدادات الربط السحابي (Cloudflare Worker)",
          color = LavndrGold,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "أدخل رابط الـ Cloudflare Worker المنشور الخاص بك للاتصال المباشر بقاعدة بيانات Google Sheets:",
          color = LavndrTextDim,
          fontSize = 11.sp,
          modifier = Modifier.padding(vertical = 8.dp)
        )

        OutlinedTextField(
          value = urlInput,
          onValueChange = { urlInput = it },
          placeholder = { Text("https://your-worker.workers.dev") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = LavndrGold,
            unfocusedBorderColor = LavndrGlassBorder,
            focusedTextColor = LavndrText,
            unfocusedTextColor = LavndrText
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(text = "حالة الاتصال:", color = LavndrTextDim, fontSize = 11.sp)
          Text(
            text = if (isOnline) "🟢 متصل بالسيرفر" else "🔴 غير متصل (محلي)",
            color = if (isOnline) LavndrEmerald else LavndrRed,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Text(
          text = "آخر مزامنة: $lastSync",
          color = LavndrTextFaint,
          fontSize = 10.sp,
          modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              onSave(urlInput)
              onDismiss()
            },
            colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ واختبار الاتصال")
          }
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء", color = LavndrTextDim)
          }
        }
      }
    }
  }
}

// ✅ حُذفت: UserLoginDialog كانت تسمح بكتابة إيميل + auth token يدويًا وحفظهما
// كجلسة صالحة بدون أي تحقق من السيرفر — نفس فئة الثغرة اللي كانت في RoleSwitcherDialog.
// تسجيل الدخول الحقيقي الوحيد بقى عبر GoogleSignInScreen.kt.

@Composable
private fun BankRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(text = label, color = LavndrTextDim, fontSize = 11.sp)
    Text(text = value, color = LavndrText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
  }
}

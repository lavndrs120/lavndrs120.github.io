package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ComponentWeight
import com.example.data.model.DailyOrderTrend
import com.example.data.model.HistoryPoint
import com.example.data.model.LocationOrder
import com.example.data.model.TopProduct
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun NavLineChart(
  history: List<HistoryPoint>,
  isPositive: Boolean,
  modifier: Modifier = Modifier
) {
  if (history.isEmpty()) return

  var selectedPointIndex by remember { mutableStateOf<Int?>(null) }
  val lineProgression by animateFloatAsState(
    targetValue = 1f,
    animationSpec = tween(1000),
    label = "lineProgression"
  )

  val chartColor = if (isPositive) LavndrEmerald else LavndrRed
  val gradientColor = if (isPositive) Color(0x2E10B981) else Color(0x2EF43F5E)

  Column(modifier = modifier) {
    if (selectedPointIndex != null && selectedPointIndex in history.indices) {
      val pt = history[selectedPointIndex!!]
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "الوقت: ${pt.time}",
          color = LavndrTextDim,
          fontSize = 11.sp
        )
        Text(
          text = "NAV: $${String.format(Locale.US, "%.2f", pt.NAV)}",
          color = chartColor,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp
        )
      }
    }

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .pointerInput(history) {
          detectTapGestures { offset ->
            val step = size.width / (history.size - 1).coerceAtLeast(1)
            val index = (offset.x / step).roundToInt().coerceIn(0, history.size - 1)
            selectedPointIndex = if (selectedPointIndex == index) null else index
          }
        }
        .pointerInput(history) {
          detectDragGestures(
            onDragStart = { offset ->
              val step = size.width / (history.size - 1).coerceAtLeast(1)
              selectedPointIndex = (offset.x / step).roundToInt().coerceIn(0, history.size - 1)
            },
            onDrag = { change, _ ->
              change.consume()
              val step = size.width / (history.size - 1).coerceAtLeast(1)
              selectedPointIndex = (change.position.x / step).roundToInt().coerceIn(0, history.size - 1)
            }
          )
        }
    ) {
      val width = size.width
      val height = size.height

      val values = history.map { it.NAV }
      val minVal = (values.minOrNull() ?: 500.0) * 0.998
      val maxVal = (values.maxOrNull() ?: 520.0) * 1.002
      val range = (maxVal - minVal).coerceAtLeast(1.0)

      // Draw subtle grid lines
      for (i in 1..3) {
        val y = height * (i / 4f)
        drawLine(
          color = LavndrGlassBorder,
          start = Offset(0f, y),
          end = Offset(width, y),
          strokeWidth = 1f
        )
      }

      val points = history.mapIndexed { i, pt ->
        val x = i * (width / (history.size - 1).coerceAtLeast(1))
        val y = height - (((pt.NAV - minVal) / range) * height).toFloat() * lineProgression
        Offset(x, y)
      }

      if (points.size > 1) {
        val path = Path()
        val fillPath = Path()

        path.moveTo(points.first().x, points.first().y)
        fillPath.moveTo(points.first().x, height)
        fillPath.lineTo(points.first().x, points.first().y)

        for (i in 0 until points.size - 1) {
          val p0 = points[i]
          val p1 = points[i + 1]
          val midX = (p0.x + p1.x) / 2
          path.cubicTo(midX, p0.y, midX, p1.y, p1.x, p1.y)
          fillPath.cubicTo(midX, p0.y, midX, p1.y, p1.x, p1.y)
        }

        fillPath.lineTo(points.last().x, height)
        fillPath.close()

        drawPath(
          path = fillPath,
          brush = Brush.verticalGradient(
            colors = listOf(gradientColor, Color.Transparent),
            startY = 0f,
            endY = height
          )
        )

        drawPath(
          path = path,
          color = chartColor,
          style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
      }

      selectedPointIndex?.let { idx ->
        if (idx in points.indices) {
          val sel = points[idx]
          drawLine(
            color = LavndrTextDim,
            start = Offset(sel.x, 0f),
            end = Offset(sel.x, height),
            strokeWidth = 2f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
          )
          drawCircle(
            color = Color.White,
            radius = 6f,
            center = sel
          )
          drawCircle(
            color = chartColor,
            radius = 4f,
            center = sel
          )
        }
      }
    }
  }
}

@Composable
fun TopProductsBarChart(
  products: List<TopProduct>,
  modifier: Modifier = Modifier
) {
  if (products.isEmpty()) return
  val maxCount = (products.maxOfOrNull { it.count } ?: 1).coerceAtLeast(1)

  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
    products.take(6).forEach { product ->
      val progress = (product.count.toFloat() / maxCount).coerceIn(0.05f, 1f)
      val animatedProg by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(800),
        label = "prodProg"
      )

      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = product.name,
            color = LavndrText,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
          )
          Text(
            text = "${product.count.toLocaleString()} طلب",
            color = LavndrEmerald,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .background(LavndrGlassBorder, RoundedCornerShape(3.dp))
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth(animatedProg)
              .fillMaxHeight()
              .background(
                Brush.horizontalGradient(listOf(LavndrEmerald, Color(0xFF34D399))),
                RoundedCornerShape(3.dp)
              )
          )
        }
      }
    }
  }
}

@Composable
fun DailyOrdersTrendBarChart(
  trend: List<DailyOrderTrend>,
  modifier: Modifier = Modifier
) {
  if (trend.isEmpty()) return
  val maxOrders = (trend.maxOfOrNull { it.orders } ?: 1).coerceAtLeast(1)
  var activeTooltip by remember { mutableStateOf<DailyOrderTrend?>(null) }

  Column(modifier = modifier) {
    activeTooltip?.let { t ->
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "التاريخ: ${t.date}",
          color = LavndrGold,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "${t.orders} طلب ${t.topProduct?.let { "• أكثر منتج: $it" } ?: ""}",
          color = LavndrText,
          fontSize = 11.sp
        )
      }
    }

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .pointerInput(trend) {
          detectTapGestures { offset ->
            val barWidth = size.width / trend.size
            val index = (offset.x / barWidth).toInt().coerceIn(0, trend.size - 1)
            activeTooltip = if (activeTooltip == trend[index]) null else trend[index]
          }
        }
    ) {
      val width = size.width
      val height = size.height
      val n = trend.size
      val barWidth = (width / n) * 0.7f
      val spacing = (width / n) * 0.3f

      trend.forEachIndexed { i, item ->
        val barHeight = (item.orders.toFloat() / maxOrders) * height
        val x = (i * (barWidth + spacing)) + (spacing / 2)
        val y = height - barHeight

        val isSelected = activeTooltip == item
        val barBrush = if (isSelected) {
          Brush.verticalGradient(listOf(Color(0xFFFDE68A), LavndrGold))
        } else {
          Brush.verticalGradient(listOf(LavndrGold, Color(0xFFA07828)))
        }

        drawRoundRect(
          brush = barBrush,
          topLeft = Offset(x, y),
          size = Size(barWidth, barHeight),
          cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )
      }
    }
  }
}

@Composable
fun LocationDistributionChart(
  locations: List<LocationOrder>,
  modifier: Modifier = Modifier
) {
  if (locations.isEmpty()) return
  val total = locations.sumOf { it.count }.coerceAtLeast(1)

  val palette = listOf(
    LavndrGold,
    LavndrEmerald,
    LavndrAmber,
    LavndrSapphire,
    LavndrAmethyst,
    Color(0xFFEC4899),
    Color(0xFF14B8A6)
  )

  Column(modifier = modifier) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Doughnut
      Canvas(
        modifier = Modifier
          .size(120.dp)
          .padding(8.dp)
      ) {
        var startAngle = -90f
        val strokeWidth = 24f

        locations.forEachIndexed { i, loc ->
          val sweepAngle = (loc.count.toFloat() / total) * 360f
          val color = palette[i % palette.size]

          drawArc(
            color = color,
            startAngle = startAngle,
            sweepAngle = sweepAngle - 2f,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
          )
          startAngle += sweepAngle
        }
      }

      Spacer(modifier = Modifier.width(16.dp))

      // Legend
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        locations.forEachIndexed { i, loc ->
          val pct = (loc.count.toDouble() / total * 100).roundToInt()
          val color = palette[i % palette.size]
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .background(color, RoundedCornerShape(2.dp))
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = loc.location,
                color = LavndrText,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
            Text(
              text = "$pct%",
              color = LavndrTextDim,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}

private fun Int.toLocaleString(): String {
  return String.format(Locale.US, "%,d", this)
}

/**
 * Recharts-equivalent dynamic interactive line chart for the 120 tracked activities (Consumer Index).
 * Visualizes order count and weight curves across all activities with interactive scrubbing tooltip,
 * smooth cubic bezier curves, gradient area fill, and dynamic metric toggles.
 */
@Composable
fun ConsumerIndexLineChart(
  weights: List<ComponentWeight>,
  sharePrice: Double = 513.0,
  modifier: Modifier = Modifier
) {
  if (weights.isEmpty()) return

  var selectedMetric by remember { mutableStateOf("orders") } // "orders" or "weight"
  var selectedIndex by remember { mutableStateOf<Int?>(null) }

  val lineProgression by animateFloatAsState(
    targetValue = 1f,
    animationSpec = tween(900),
    label = "consumerLineProgression"
  )

  // Top 120 or whatever activities are tracked
  val sortedItems = remember(weights, selectedMetric) {
    weights.take(120)
  }

  val activeItem = selectedIndex?.let { if (it in sortedItems.indices) sortedItems[it] else null }

  Column(modifier = modifier) {
    // Header & Metric Toggle Controls
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "مؤشر المستهلك للأنشطة الـ 120 (Consumer Index)",
          color = LavndrText,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = if (selectedMetric == "orders") "منحنى الطلبات المباشرة لكل نشاط تجاري" else "منحنى الأوزان النسبية والمخصصات المالية",
          color = LavndrTextDim,
          fontSize = 10.sp
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        androidx.compose.material3.FilterChip(
          selected = selectedMetric == "orders",
          onClick = {
            selectedMetric = "orders"
            selectedIndex = null
          },
          label = { Text("الطلبات", fontSize = 10.sp) },
          colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
            selectedContainerColor = LavndrEmeraldDim,
            selectedLabelColor = LavndrEmerald
          )
        )
        androidx.compose.material3.FilterChip(
          selected = selectedMetric == "weight",
          onClick = {
            selectedMetric = "weight"
            selectedIndex = null
          },
          label = { Text("الوزن %", fontSize = 10.sp) },
          colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
            selectedContainerColor = LavndrGoldDim,
            selectedLabelColor = LavndrGold
          )
        )
      }
    }

    // Interactive Tooltip Card (Recharts tooltip equivalent)
    if (activeItem != null) {
      val alloc = (activeItem.weight / 100.0 * sharePrice)
      Surface(
        color = LavndrSurfaceElevated,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, LavndrGlassBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 8.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = LavndrGoldDim,
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = activeItem.ticker,
                color = LavndrGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = activeItem.name,
              color = LavndrText,
              fontSize = 12.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
              text = "📦 ${activeItem.count.toLocaleString()} طلب",
              color = LavndrEmerald,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "⚖️ ${String.format(Locale.US, "%.2f", activeItem.weight)}% ($${String.format(Locale.US, "%.2f", alloc)})",
              color = LavndrGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // Dynamic Line Chart Canvas
    val primaryChartColor = if (selectedMetric == "orders") LavndrEmerald else LavndrGold
    val chartGradientColor = if (selectedMetric == "orders") Color(0x3310B981) else Color(0x33F59E0B)

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
        .pointerInput(sortedItems, selectedMetric) {
          detectTapGestures { offset ->
            val step = size.width / (sortedItems.size - 1).coerceAtLeast(1)
            val index = (offset.x / step).roundToInt().coerceIn(0, sortedItems.size - 1)
            selectedIndex = if (selectedIndex == index) null else index
          }
        }
        .pointerInput(sortedItems, selectedMetric) {
          detectDragGestures(
            onDragStart = { offset ->
              val step = size.width / (sortedItems.size - 1).coerceAtLeast(1)
              selectedIndex = (offset.x / step).roundToInt().coerceIn(0, sortedItems.size - 1)
            },
            onDrag = { change, _ ->
              change.consume()
              val step = size.width / (sortedItems.size - 1).coerceAtLeast(1)
              selectedIndex = (change.position.x / step).roundToInt().coerceIn(0, sortedItems.size - 1)
            }
          )
        }
    ) {
      val width = size.width
      val height = size.height
      val n = sortedItems.size
      if (n < 2) return@Canvas

      val values = sortedItems.map {
        if (selectedMetric == "orders") it.count.toDouble() else it.weight
      }
      val minVal = (values.minOrNull() ?: 0.0) * 0.95
      val maxVal = (values.maxOrNull() ?: 100.0) * 1.05
      val range = (maxVal - minVal).coerceAtLeast(0.001)

      // Draw subtle horizontal grid lines (like Recharts CartesianGrid)
      for (i in 1..4) {
        val y = height * (i / 5f)
        drawLine(
          color = LavndrGlassBorder,
          start = Offset(0f, y),
          end = Offset(width, y),
          strokeWidth = 1f,
          pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
        )
      }

      // Calculate coordinates
      val points = values.mapIndexed { i, v ->
        val x = i * (width / (n - 1).toFloat())
        val y = height - (((v - minVal) / range) * height).toFloat() * lineProgression
        Offset(x, y.coerceIn(4f, height - 4f))
      }

      // Smooth monotone cubic bezier path (like Recharts type="monotone")
      val path = Path()
      val fillPath = Path()

      path.moveTo(points.first().x, points.first().y)
      fillPath.moveTo(points.first().x, height)
      fillPath.lineTo(points.first().x, points.first().y)

      for (i in 0 until points.size - 1) {
        val p0 = points[i]
        val p1 = points[i + 1]
        val midX = (p0.x + p1.x) / 2
        path.cubicTo(midX, p0.y, midX, p1.y, p1.x, p1.y)
        fillPath.cubicTo(midX, p0.y, midX, p1.y, p1.x, p1.y)
      }

      fillPath.lineTo(points.last().x, height)
      fillPath.close()

      // Area fill gradient
      drawPath(
        path = fillPath,
        brush = Brush.verticalGradient(
          colors = listOf(chartGradientColor, Color.Transparent),
          startY = 0f,
          endY = height
        )
      )

      // Line stroke
      drawPath(
        path = path,
        color = primaryChartColor,
        style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
      )

      // Active Tooltip crosshair and dot indicator
      selectedIndex?.let { idx ->
        if (idx in points.indices) {
          val sel = points[idx]
          // Vertical guide line
          drawLine(
            color = Color.White.copy(alpha = 0.5f),
            start = Offset(sel.x, 0f),
            end = Offset(sel.x, height),
            strokeWidth = 1.5f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
          )
          // Glowing point marker
          drawCircle(
            color = primaryChartColor.copy(alpha = 0.35f),
            radius = 10f,
            center = sel
          )
          drawCircle(
            color = Color.White,
            radius = 5.5f,
            center = sel
          )
          drawCircle(
            color = primaryChartColor,
            radius = 3.5f,
            center = sel
          )
        }
      }
    }

    // X-Axis summary labels
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = sortedItems.firstOrNull()?.ticker ?: "#1",
        color = LavndrTextFaint,
        fontSize = 10.sp
      )
      Text(
        text = "المسار التوزيعي لـ ${sortedItems.size} نشاط استهلاكي",
        color = LavndrTextFaint,
        fontSize = 10.sp
      )
      Text(
        text = sortedItems.lastOrNull()?.ticker ?: "#${sortedItems.size}",
        color = LavndrTextFaint,
        fontSize = 10.sp
      )
    }
  }
}

package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FundInfo
import com.example.data.model.LavndrData
import com.example.data.model.ParticipantInfo
import com.example.data.model.MarketItem
import com.example.data.model.UserRole
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MarketScreen(
  data: LavndrData,
  participantInfo: ParticipantInfo?,
  fund: FundInfo,
  settlementCycle: String,
  settlementDate: String,
  currentUserEmail: String,
  currentRole: UserRole,
  onBuyListing: (MarketItem) -> Unit,
  onBuyShare: () -> Unit,
  onSellShare: () -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "السوق الداخلي",
          color = LavndrGold,
          fontSize = 11.sp,
          letterSpacing = 4.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "الحصص المتاحة للتداول",
          color = LavndrText,
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "تداول حصص الصندوق بين المشاركين مباشرة وفق أوزان المؤشر",
          color = LavndrTextDim,
          fontSize = 11.sp,
          textAlign = TextAlign.Center
        )
      }
    }

    // بطاقة حصتك (شراء/بيع) — لأصحاب الـ120
    item {
      FundShareCard(
        data = data,
        participantInfo = participantInfo,
        currentRole = currentRole,
        currentUserEmail = currentUserEmail,
        onBuyShare = onBuyShare,
        onSellShare = onSellShare
      )
    }

    // Market Listings Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, LavndrAmethystDim)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "الحصص المعروضة للبيع",
            color = LavndrAmethyst,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
          )

          if (currentRole == UserRole.SUBSCRIBER) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "🔒 السوق الداخلي وتداول الحصص متاح للمستثمرين الفعليين بالصندوق فقط",
                color = LavndrTextDim,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
              )
            }
          } else if (fund.market.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "لا توجد حصص معروضة للبيع حالياً",
                color = LavndrTextFaint,
                fontSize = 13.sp
              )
            }
          } else {
            fund.market.forEach { item ->
              MarketItemRow(
                item = item,
                isMyListing = item.seller.equals(currentUserEmail, ignoreCase = true),
                onBuyClick = { onBuyListing(item) }
              )
              if (item != fund.market.last()) {
                Divider(color = LavndrGlassBorder, modifier = Modifier.padding(vertical = 8.dp))
              }
            }
          }
        }
      }
    }

    // Fund Status
    item {
      Text(
        text = "بيانات الصندوق والتسوية",
        color = LavndrTextDim,
        fontSize = 12.sp,
        letterSpacing = 2.sp,
        fontWeight = FontWeight.SemiBold
      )
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        FundMetricCard(
          title = "المشاركون النشطون",
          value = "${fund.activeParticipants} / 120",
          modifier = Modifier.weight(1f)
        )
        FundMetricCard(
          title = "إجمالي حجم الصندوق",
          value = "$${String.format(Locale.US, "%,.2f", fund.poolValue)}",
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Settlement Info Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(text = "دورة التسوية القانونية", color = LavndrTextDim, fontSize = 11.sp)
            Text(text = settlementCycle, color = LavndrGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
          }
          Column(horizontalAlignment = Alignment.End) {
            Text(text = "تاريخ تسوية الأوامر", color = LavndrTextDim, fontSize = 11.sp)
            Text(text = settlementDate, color = LavndrText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }
  }
}

@Composable
private fun MarketItemRow(
  item: MarketItem,
  isMyListing: Boolean,
  onBuyClick: () -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = item.seller,
        color = LavndrText,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold
      )
      Text(
        text = "عُرضت في: ${item.listDate} • تسوية T+2",
        color = LavndrTextFaint,
        fontSize = 10.sp
      )
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = "$${String.format(Locale.US, "%.2f", item.shareValue)}",
        color = LavndrAmethyst,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 10.dp)
      )

      if (isMyListing) {
        Surface(
          color = LavndrAmethystDim,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            text = "حصتك",
            color = LavndrAmethyst,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      } else {
        Button(
          onClick = onBuyClick,
          colors = ButtonDefaults.buttonColors(
            containerColor = LavndrGold,
            contentColor = LavndrVoid
          ),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
          modifier = Modifier.testTag("buy_listing_button_${item.row}")
        ) {
          Text("شراء", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun FundMetricCard(title: String, value: String, modifier: Modifier = Modifier) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = title, color = LavndrTextDim, fontSize = 10.sp)
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = value, color = LavndrGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
  }
}

package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.alerts.PriceAlertConfig
import com.example.data.model.HistoryPoint
import com.example.data.model.LavndrData
import com.example.data.model.ParticipantInfo
import com.example.data.model.UserRole
import com.example.ui.components.ConsumerIndexLineChart
import com.example.ui.components.NavLineChart
import com.example.ui.components.PriceAlertDialog
import com.example.ui.components.RechartsSectorTrendChart
import com.example.ui.export.PortfolioPdfGenerator
import com.example.ui.theme.*
import com.example.util.NotificationSoundManager
import com.example.util.NotificationSoundType
import java.util.Locale

@Composable
fun HomeScreen(
  data: LavndrData,
  participantInfo: ParticipantInfo?,
  currentRole: UserRole,
  monthlyHistory: List<HistoryPoint>,
  selectedMonth: String?,
  onSubscribeClick: () -> Unit,
  onSelectMonth: (String?) -> Unit,
  priceAlertConfig: PriceAlertConfig = PriceAlertConfig(),
  onSavePriceAlert: (PriceAlertConfig) -> Unit = {},
  currentUserEmail: String = "",
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val isPositive = !data.index.change.startsWith("-")
  var showPriceAlertDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    // Hero Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "المؤشر الاستهلاكي",
          color = LavndrGold,
          fontSize = 11.sp,
          letterSpacing = 4.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "LAVNDR120",
          color = LavndrGoldLight,
          fontSize = 38.sp,
          fontWeight = FontWeight.ExtraBold,
          letterSpacing = 1.sp
        )
        Text(
          text = "آخر تحديث ${data.timestamp.substringAfter("T").take(5)} • تسوية ${data.settlementCycle}",
          color = LavndrTextDim,
          fontSize = 11.sp
        )
      }
    }

    // NAV Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
        ) {
          Text(
            text = "صافي قيمة الأصول (NAV)",
            color = LavndrTextDim,
            fontSize = 11.sp,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.SemiBold
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "$${data.index.NAV}",
              color = if (isPositive) LavndrEmerald else LavndrRed,
              fontSize = 42.sp,
              fontWeight = FontWeight.Bold
            )

            Surface(
              color = if (isPositive) LavndrEmeraldDim else LavndrRedDim,
              shape = RoundedCornerShape(100.dp)
            ) {
              Text(
                text = "${if (isPositive) "▲ +" else "▼ "}${data.index.change} (${data.index.changePercent}%)",
                color = if (isPositive) LavndrEmerald else LavndrRed,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(18.dp))
          Divider(color = LavndrGlassBorder)
          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
          ) {
            NavMetaItem(label = "الأعلى (High)", value = "$${data.index.dayHigh}")
            NavMetaItem(label = "الأدنى (Low)", value = "$${data.index.dayLow}")
            NavMetaItem(label = "التذبذب (Volatility)", value = "${data.index.volatility}%")
          }

          Spacer(modifier = Modifier.height(14.dp))
          Divider(color = LavndrGlassBorder)
          Spacer(modifier = Modifier.height(10.dp))

          // 🔔 Price Alert Bar
          Surface(
            color = if (priceAlertConfig.isEnabled) LavndrGoldDim.copy(alpha = 0.5f) else LavndrSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { showPriceAlertDialog = true }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (priceAlertConfig.isEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                  contentDescription = "Price Alert",
                  tint = if (priceAlertConfig.isEnabled) LavndrGold else LavndrTextDim,
                  modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (priceAlertConfig.isEnabled) {
                    "تنبيه السعر نشط: ${if (priceAlertConfig.alertWhenAbove) "≥" else "≤"} $${String.format(Locale.US, "%.1f", priceAlertConfig.targetNav)}"
                  } else {
                    "ضبط تنبيه لسعر المؤشر والـ NAV"
                  },
                  color = if (priceAlertConfig.isEnabled) LavndrGold else LavndrTextDim,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium
                )
              }
              Text(
                text = if (priceAlertConfig.isEnabled) "تعديل ⚙️" else "تفعيل 🔔",
                color = LavndrGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // Chart Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          var chartMode by remember { mutableStateOf("nav") } // "nav" or "consumer"

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (chartMode == "consumer") "مؤشر المستهلك — 120 نشاط"
                     else if (selectedMonth != null) "الأداء التاريخي — $selectedMonth"
                     else "NAV — الحركة المباشرة",
              color = LavndrText,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              FilterChip(
                selected = chartMode == "nav" && selectedMonth == null,
                onClick = {
                  chartMode = "nav"
                  onSelectMonth(null)
                },
                label = { Text("NAV", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = LavndrGoldDim,
                  selectedLabelColor = LavndrGold
                )
              )
              FilterChip(
                selected = chartMode == "consumer",
                onClick = { chartMode = "consumer" },
                label = { Text("120 نشاط", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = LavndrEmeraldDim,
                  selectedLabelColor = LavndrEmerald
                )
              )
              FilterChip(
                selected = chartMode == "sectors",
                onClick = { chartMode = "sectors" },
                label = { Text("القطاعات 📊", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = LavndrGoldDim,
                  selectedLabelColor = LavndrGold
                )
              )
              var showMonthPicker by remember { mutableStateOf(false) }
              Box {
                FilterChip(
                  selected = chartMode == "nav" && selectedMonth != null,
                  onClick = {
                    chartMode = "nav"
                    if (data.monthlySnapshots.isEmpty()) {
                      onSelectMonth(null)
                    } else {
                      showMonthPicker = true
                    }
                  },
                  label = { Text("شهري", fontSize = 11.sp) },
                  colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = LavndrGoldDim,
                    selectedLabelColor = LavndrGold
                  )
                )
                DropdownMenu(
                  expanded = showMonthPicker,
                  onDismissRequest = { showMonthPicker = false }
                ) {
                  if (data.monthlySnapshots.isEmpty()) {
                    DropdownMenuItem(
                      text = { Text("لا توجد بيانات شهرية محفوظة بعد") },
                      onClick = { showMonthPicker = false }
                    )
                  }
                  data.monthlySnapshots.forEach { snap ->
                    DropdownMenuItem(
                      text = { Text(snap.month) },
                      onClick = {
                        chartMode = "nav"
                        onSelectMonth(snap.month)
                        showMonthPicker = false
                      }
                    )
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          if (chartMode == "sectors") {
            RechartsSectorTrendChart(
              weights = data.weights,
              monthlySnapshots = data.monthlySnapshots,
              dailyTrends = data.dailyOrderTrend,
              history = data.history,
              sharePrice = data.index.NAV.toDoubleOrNull() ?: 513.0,
              modifier = Modifier.fillMaxWidth()
            )
          } else if (chartMode == "consumer") {
            ConsumerIndexLineChart(
              weights = data.weights,
              sharePrice = data.index.NAV.toDoubleOrNull() ?: 513.0,
              modifier = Modifier.fillMaxWidth()
            )
          } else {
            NavLineChart(
              history = if (selectedMonth != null) monthlyHistory else data.history,
              isPositive = isPositive,
              modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
            )

            if (selectedMonth != null && monthlyHistory.isEmpty()) {
              Text(
                text = "لا توجد نقاط بيانات محفوظة لهذا الشهر",
                color = LavndrTextFaint,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedButton(
            onClick = {
              val currentActiveMonth = selectedMonth ?: (if (data.monthlySnapshots.isNotEmpty()) data.monthlySnapshots.first().month else "الشهر الحالي")
              val targetHistory = if (selectedMonth != null) monthlyHistory else data.history
              val fallbackNav = data.index.NAV.toDoubleOrNull() ?: 513.0
              val startVal = targetHistory.firstOrNull()?.NAV ?: fallbackNav
              val endVal = targetHistory.lastOrNull()?.NAV ?: fallbackNav
              val changeDiff = endVal - startVal
              val changePct = if (startVal != 0.0) String.format(Locale.US, "%.2f", (changeDiff / startVal) * 100) else "0.00"

              val reportContent = """
                📑 تقرير الأداء المالي لمؤشر LAVNDR120:
                • الفترة: $currentActiveMonth
                • سعر الأساس: $$startVal
                • سعر الإغلاق: $$endVal
                • صافي التغير: ${if (changeDiff >= 0.0) "+$$changeDiff (+$changePct%)" else "-$$changeDiff ($changePct%)"}
                • صافي الطلبات المنفذة: ${String.format(Locale.US, "%,d", data.index.netOrders)}
                • الوحدات الصادرة (Units): ${data.index.netUnits}
                • القيمة الإرشادية (IIV): $${data.index.IIV}
                • عدد الأنشطة الممثلة: ${data.weights.size} نشاط تجاري
                • توثيق التدقيق: دورة T+2 معتمدة
              """.trimIndent()

              val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, reportContent)
                type = "text/plain"
              }
              val shareIntent = Intent.createChooser(sendIntent, "تصدير تقرير الأداء المالي")
              context.startActivity(shareIntent)
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("📄 تصدير تقرير الأداء المالي (نصي / PDF)", color = LavndrGold, fontSize = 12.sp)
          }
        }
      }
    }

    // Market Stats Grid
    item {
      Column {
        Text(
          text = "إحصاءات المؤشر والصندوق",
          color = LavndrTextDim,
          fontSize = 12.sp,
          letterSpacing = 2.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          StatCard(
            title = "صافي الطلبات",
            value = String.format(Locale.US, "%,d", data.index.netOrders),
            modifier = Modifier.weight(1f)
          )
          StatCard(
            title = "الوحدات الصادرة",
            value = "${data.index.netUnits}",
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          StatCard(
            title = "Premium / Discount",
            value = "${data.index.premium}%",
            modifier = Modifier.weight(1f)
          )
          StatCard(
            title = "القيمة الإرشادية (IIV)",
            value = "$${data.index.IIV}",
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Direct WhatsApp & Financial Support Card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, LavndrGlassBorder)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "مركز الدعم المالي والمساعدات",
                  color = LavndrText,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
                Text(
                  text = "استفسارات الحصص، التحويلات البنكية، أو أكواد OTP",
                  color = LavndrTextDim,
                  fontSize = 11.sp
                )
              }
              Surface(
                color = LavndrEmerald.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = "24/7",
                  color = LavndrEmerald,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
              onClick = {
                val waUri = android.net.Uri.parse("https://wa.me/201016833923?text=" + android.net.Uri.encode("مرحباً فريق لافندر 120، أحتاج لمساعدة بخصوص الحصص أو التحويلات المالية."))
                val intent = Intent(Intent.ACTION_VIEW, waUri)
                context.startActivity(intent)
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF25D366),
                contentColor = Color.White
              ),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "💬 تواصل مباشر عبر واتساب للدعم",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }

          }
        }
      }
    }
  }

  if (showPriceAlertDialog) {
    PriceAlertDialog(
      currentNav = data.index.NAV.toDoubleOrNull() ?: 513.0,
      initialConfig = priceAlertConfig,
      onSaveConfig = onSavePriceAlert,
      onDismiss = { showPriceAlertDialog = false }
    )
  }
}

@Composable
private fun NavMetaItem(label: String, value: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(text = label, color = LavndrTextFaint, fontSize = 10.sp)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, color = LavndrText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = title, color = LavndrTextFaint, fontSize = 10.sp)
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = value, color = LavndrText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
  }
}

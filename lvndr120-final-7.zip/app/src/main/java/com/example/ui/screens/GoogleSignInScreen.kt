package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@Composable
fun GoogleSignInScreen(
  isSigningIn: Boolean,
  errorMessage: String?,
  onSignInClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF070608))
  ) {
    // صورة الخلفية بدقة 1080x2400 ممتدة بأبعاد الشاشة دون تقريب مفرط
    Image(
      painter = painterResource(id = R.drawable.login_background),
      contentDescription = null,
      contentScale = ContentScale.Crop,
      alignment = Alignment.TopCenter,
      modifier = Modifier.fillMaxSize()
    )

    // تدرج علوي ناعم لشريط الحالة (Status Bar)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(110.dp)
        .align(Alignment.TopCenter)
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color(0xB3000000),
              Color.Transparent
            )
          )
        )
    )

    // تدرج سفلي سينمائي معتم لتوفير تباين فائق ووضوح لزر تسجيل الدخول والنص
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.42f)
        .align(Alignment.BottomCenter)
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color.Transparent,
              Color(0xCC070608),
              Color(0xF5070608),
              Color(0xFF070608)
            )
          )
        )
    )

    // منطقة التحكم وتسجيل الدخول السفلية
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 24.dp)
        .padding(bottom = 28.dp)
    ) {
      if (errorMessage != null) {
        Surface(
          color = LavndrRed.copy(alpha = 0.2f),
          border = BorderStroke(1.dp, LavndrRed.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth(0.92f)
            .padding(bottom = 18.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Warning,
              contentDescription = null,
              tint = LavndrRed,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = errorMessage,
              color = LavndrRed,
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }

      // زر Google الرسمي عالي الوضوح والتباين
      Button(
        onClick = onSignInClick,
        enabled = !isSigningIn,
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.White,
          contentColor = Color(0xFF1F1F1F),
          disabledContainerColor = Color.White.copy(alpha = 0.7f),
          disabledContentColor = Color(0xFF1F1F1F).copy(alpha = 0.7f)
        ),
        shape = RoundedCornerShape(26.dp),
        elevation = ButtonDefaults.buttonElevation(
          defaultElevation = 6.dp,
          pressedElevation = 10.dp
        ),
        modifier = Modifier
          .fillMaxWidth(0.92f)
          .height(52.dp)
          .testTag("google_sign_in_button")
      ) {
        if (isSigningIn) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            color = Color(0xFF4285F4),
            strokeWidth = 2.5.dp
          )
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = "جاري تسجيل الدخول...",
            fontWeight = FontWeight.Medium,
            fontSize = 15.sp,
            color = Color(0xFF1F1F1F)
          )
        } else {
          Icon(
            painter = painterResource(id = R.drawable.ic_google_logo),
            contentDescription = "Google",
            tint = Color.Unspecified,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = "تسجيل الدخول باستخدام Google",
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
            color = Color(0xFF1F1F1F)
          )
        }
      }

      Text(
        text = "سجّل دخولك بنفس حساب Google المستخدم في المنصة",
        color = LavndrTextDim,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 14.dp)
      )
    }
  }
}

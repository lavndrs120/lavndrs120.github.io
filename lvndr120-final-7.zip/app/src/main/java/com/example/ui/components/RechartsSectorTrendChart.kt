package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.ComponentWeight
import com.example.data.model.DailyOrderTrend
import com.example.data.model.HistoryPoint
import com.example.data.model.MonthlySnapshot
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.roundToInt

data class SectorPerformanceDataPoint(
  val timeLabel: String,
  val retail: Double,
  val foodBeverage: Double,
  val services: Double,
  val logistics: Double,
  val healthcare: Double,
  val tech: Double,
  val compositeIndex: Double
)

data class SectorMeta(
  val id: String,
  val nameAr: String,
  val icon: String,
  val colorHex: String,
  val composeColor: Color
)

// ✅ إصلاح جوهري: القائمة القديمة كانت "قطاعات" ثابتة ووهمية بالكامل (تجزئة/أغذية/
// خدمات...) — مفهوم مش موجود أصلاً بالباك اند ولا بأي شيت حقيقي (راجع دليل النشر:
// الأبعاد المعتمدة 3 بس — منتج/تاريخ/موقع، مفيش "قطاع"). الـid هنا بقى مجرد "خانة
// ترتيب" (1 لـ6) للون/الحقل الداخلي بس — الاسم المعروض للمستخدم بقى اسم نشاط حقيقي
// دايمًا، مبني من أكبر 6 أنشطة وزنًا فعليًا في المؤشر (weights الحقيقية).
private val TOP_BUSINESS_SLOT_IDS = listOf("retail", "food", "services", "logistics", "health", "tech")
private val TOP_BUSINESS_SLOT_COLORS = listOf("#F59E0B", "#10B981", "#3B82F6", "#8B5CF6", "#EC4899", "#06B6D4")

private fun buildTopBusinessMetas(weights: List<ComponentWeight>): List<SectorMeta> {
  val top = weights.sortedByDescending { it.weight }.take(6)
  return top.mapIndexed { idx, w ->
    val hex = TOP_BUSINESS_SLOT_COLORS.getOrElse(idx) { "#94A3B8" }
    SectorMeta(
      id = TOP_BUSINESS_SLOT_IDS.getOrElse(idx) { "slot$idx" },
      nameAr = w.name.ifBlank { w.ticker },
      icon = "🏪",
      colorHex = hex,
      composeColor = Color(android.graphics.Color.parseColor(hex))
    )
  }
}

@Composable
fun RechartsSectorTrendChart(
  weights: List<ComponentWeight>,
  monthlySnapshots: List<MonthlySnapshot>,
  dailyTrends: List<DailyOrderTrend>,
  history: List<HistoryPoint>,
  sharePrice: Double,
  modifier: Modifier = Modifier
) {
  var selectedTimeHorizon by remember { mutableStateOf("monthly") } // "daily", "monthly", "composite"
  var selectedSectorId by remember { mutableStateOf<String?>("all") } // "all" or specific sector
  var renderMode by remember { mutableStateOf("recharts") } // "recharts" (WebView) or "canvas" (Native)
  var isWebLoading by remember { mutableStateOf(false) }

  // ✅ تسميات حقيقية (أكبر 6 أنشطة وزنًا) + بيانات حقيقية 100% (NAV/طلبات فعلية) —
  // بدون أي رقم مخترع. راجع buildTopBusinessMetas و generateSectorTrendPoints تحت.
  val topMetas = remember(weights) { buildTopBusinessMetas(weights) }
  val trendPoints = remember(weights, monthlySnapshots, dailyTrends, history, selectedTimeHorizon) {
    generateSectorTrendPoints(weights, monthlySnapshots, dailyTrends, history, selectedTimeHorizon, sharePrice)
  }

  // ✅ لسه مفيش طلبات حقيقية كفاية لحساب أي وزن — نعرض حالة فاضية صادقة بدل ما
  // نخترع أرقام تعبئة الفراغ
  if (topMetas.isEmpty()) {
    Card(
      modifier = modifier.fillMaxWidth(),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated),
      border = BorderStroke(1.dp, LavndrGlassBorder)
    ) {
      Column(
        modifier = Modifier.padding(28.dp).fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(text = "📊", fontSize = 28.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "لا توجد بيانات كافية بعد لعرض اتجاه الأنشطة — هتظهر أول ما يبدأ تسجيل طلبات حقيقية",
          color = LavndrTextDim,
          fontSize = 12.sp,
          textAlign = TextAlign.Center
        )
      }
    }
    return
  }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated),
    border = BorderStroke(1.dp, LavndrGlassBorder)
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      // 1. Title Header & Render Mode Switcher
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = LavndrGoldDim,
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "RECHARTS",
                color = LavndrGold,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
              )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "اتجاه أداء أكبر الأنشطة وزنًا بالمؤشر",
              color = LavndrText,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Text(
            text = "أكبر ${topMetas.size} نشاط وزنًا حاليًا — موزّعين على NAV/الطلبات الحقيقية",
            color = LavndrTextDim,
            fontSize = 11.sp
          )
        }

        // Switcher between Recharts (Web SVG) and Native Compose
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(LavndrSurface)
            .border(0.5.dp, LavndrGlassBorder, RoundedCornerShape(100.dp))
            .padding(2.dp),
          horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
          Surface(
            color = if (renderMode == "recharts") LavndrGoldDim else Color.Transparent,
            shape = RoundedCornerShape(100.dp),
            modifier = Modifier.clickable { renderMode = "recharts" }
          ) {
            Text(
              text = "Recharts",
              color = if (renderMode == "recharts") LavndrGold else LavndrTextFaint,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
          Surface(
            color = if (renderMode == "canvas") LavndrGoldDim else Color.Transparent,
            shape = RoundedCornerShape(100.dp),
            modifier = Modifier.clickable { renderMode = "canvas" }
          ) {
            Text(
              text = "Native",
              color = if (renderMode == "canvas") LavndrGold else LavndrTextFaint,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 2. Horizon & Filter Controls
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Time horizon filter chips
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          listOf(
            "monthly" to "شهري (تاريخي)",
            "daily" to "يومي (30 يوم)",
            "composite" to "المؤشر العام"
          ).forEach { (key, label) ->
            FilterChip(
              selected = selectedTimeHorizon == key,
              onClick = { selectedTimeHorizon = key },
              label = { Text(label, fontSize = 10.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = LavndrGoldDim,
                selectedLabelColor = LavndrGold,
                containerColor = LavndrSurface
              )
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Sector Legend & Quick Toggle Chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        FilterChip(
          selected = selectedSectorId == "all",
          onClick = { selectedSectorId = "all" },
          label = { Text("الكل (120 نشاط)", fontSize = 10.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = LavndrGoldDim,
            selectedLabelColor = LavndrGold,
            containerColor = LavndrSurface
          )
        )
        topMetas.take(3).forEach { sector ->
          FilterChip(
            selected = selectedSectorId == sector.id,
            onClick = { selectedSectorId = if (selectedSectorId == sector.id) "all" else sector.id },
            label = { Text("${sector.icon} ${sector.nameAr.take(7)}", fontSize = 10.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = sector.composeColor.copy(alpha = 0.2f),
              selectedLabelColor = sector.composeColor,
              containerColor = LavndrSurface
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 3. Chart Rendering
      if (renderMode == "recharts") {
        // Authentic Recharts in WebView
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0D0D18))
        ) {
          RechartsWebViewComponent(
            dataPoints = trendPoints,
            metas = topMetas,
            selectedSectorId = selectedSectorId,
            timeHorizon = selectedTimeHorizon,
            onLoadingChange = { isWebLoading = it },
            modifier = Modifier.fillMaxSize()
          )

          if (isWebLoading) {
            CircularProgressIndicator(
              color = LavndrGold,
              strokeWidth = 2.dp,
              modifier = Modifier
                .size(24.dp)
                .align(Alignment.Center)
            )
          }
        }
      } else {
        // Native Compose Canvas with Recharts Aesthetic
        RechartsNativeCanvasComponent(
          dataPoints = trendPoints,
          metas = topMetas,
          selectedSectorId = selectedSectorId,
          modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Sector Legend Summary Footer
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
      ) {
        topMetas.forEach { meta ->
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(meta.composeColor)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = meta.nameAr.substringBefore(" "),
              color = LavndrTextFaint,
              fontSize = 9.sp
            )
          }
        }
      }
    }
  }
}

/**
 * ✅ إصلاح جوهري: الدالة القديمة كانت تخترع كل رقم فيها بالكامل — نسب قطاعات ثابتة
 * (0.28/0.24/0.18...)، معامل نمو وهمي (growthFactor مبني على fallback مخترع
 * 500.0 + idx*8.5)، ومنحنى يومي مصطنع (sharePrice * (0.92 + idx*0.007)) بغض النظر
 * عن أي بيانات حقيقية، وفي حالة عدم توفر أي بيانات كانت تعرض "6 شهور" وهمية بالكامل
 * (يناير-يونيو بأرقام تصاعدية مخترعة). كل ده كان بيتعرض للمستخدم كأنه تحليل حقيقي.
 *
 * الإصلاح: توزيع حقيقي 100% — الوزن الحالي الفعلي لأكبر 6 أنشطة (من weights الحيّة)
 * مُسقط على تاريخ حقيقي فعلي حسب الفترة المختارة:
 * - شهري  → NAV الشهري الحقيقي من Monthly_Snapshots
 * - يومي  → عدد الطلبات اليومي الحقيقي من DailyOrderStats
 * - المؤشر العام → تاريخ NAV الساعي الحقيقي (History)
 * لو مفيش تاريخ حقيقي كفاية لأي فترة، بنعرض نقطة واحدة بس بالوزن الحالي الحقيقي —
 * صادق وواضح إنها "الآن" بدل اختراع أي تاريخ.
 */
private fun generateSectorTrendPoints(
  weights: List<ComponentWeight>,
  monthlySnapshots: List<MonthlySnapshot>,
  dailyTrends: List<DailyOrderTrend>,
  history: List<HistoryPoint>,
  horizon: String,
  sharePrice: Double
): List<SectorPerformanceDataPoint> {
  val topWeights = weights.sortedByDescending { it.weight }.take(6)
  if (topWeights.isEmpty()) return emptyList()
  val fractions = topWeights.map { it.weight / 100.0 }

  fun splitReal(compositeValue: Double, timeLabel: String): SectorPerformanceDataPoint {
    val vals = fractions.map { it * compositeValue }
    return SectorPerformanceDataPoint(
      timeLabel = timeLabel,
      retail = vals.getOrElse(0) { 0.0 },
      foodBeverage = vals.getOrElse(1) { 0.0 },
      services = vals.getOrElse(2) { 0.0 },
      logistics = vals.getOrElse(3) { 0.0 },
      healthcare = vals.getOrElse(4) { 0.0 },
      tech = vals.getOrElse(5) { 0.0 },
      compositeIndex = compositeValue
    )
  }

  return when {
    horizon == "monthly" && monthlySnapshots.isNotEmpty() ->
      monthlySnapshots.mapNotNull { snap -> snap.NAV.toDoubleOrNull()?.let { splitReal(it, snap.month) } }
    horizon == "daily" && dailyTrends.isNotEmpty() ->
      dailyTrends.takeLast(14).map { d -> splitReal(d.orders.toDouble(), d.date.takeLast(5)) }
    horizon == "composite" && history.isNotEmpty() ->
      history.map { h -> splitReal(h.NAV, h.time) }
    else ->
      listOf(splitReal(sharePrice, "الآن"))
  }
}

/**
 * Embedded Recharts chart running React/SVG Recharts engine inside Android WebView
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun RechartsWebViewComponent(
  dataPoints: List<SectorPerformanceDataPoint>,
  metas: List<SectorMeta>,
  selectedSectorId: String?,
  timeHorizon: String,
  onLoadingChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  val htmlContent = remember(dataPoints, metas, selectedSectorId, timeHorizon) {
    buildRechartsHtml(dataPoints, metas, selectedSectorId)
  }

  AndroidView(
    modifier = modifier.testTag("recharts_webview"),
    factory = { ctx ->
      WebView(ctx).apply {
        layoutParams = ViewGroup.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT,
          ViewGroup.LayoutParams.MATCH_PARENT
        )
        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = true
          useWideViewPort = true
          loadWithOverviewMode = true
          cacheMode = WebSettings.LOAD_NO_CACHE
          setSupportZoom(false)
        }
        setBackgroundColor(android.graphics.Color.parseColor("#0D0D18"))
        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
          override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            onLoadingChange(true)
          }
          override fun onPageFinished(view: WebView?, url: String?) {
            onLoadingChange(false)
          }
        }
        loadDataWithBaseURL("https://cdn.jsdelivr.net", htmlContent, "text/html", "UTF-8", null)
      }
    },
    update = { webView ->
      webView.loadDataWithBaseURL("https://cdn.jsdelivr.net", htmlContent, "text/html", "UTF-8", null)
    }
  )
}

/**
 * Builds standalone HTML with embedded responsive SVG Recharts engine
 */
private fun buildRechartsHtml(
  dataPoints: List<SectorPerformanceDataPoint>,
  metas: List<SectorMeta>,
  selectedSectorId: String?
): String {
  // ✅ أسماء وألوان حقيقية (أكبر 6 أنشطة وزنًا فعليًا) بدل قائمة "قطاعات" مُكوَّدة —
  // بنهرّب علامات الاقتباس من اسم النشاط (بيانات مُدخلة من شيت حقيقي) قبل حقنها
  // كـ JS، نفس مبدأ esc() في dashboard.html، لمنع أي كسر لهيكل الـ JSON/JS.
  val sectorsJs = metas.joinToString(separator = ",", prefix = "[", postfix = "]") { m ->
    val safeName = m.nameAr.replace("\\", "").replace("\"", "").replace("<", "").take(14)
    """{"id":"${m.id}","name":"$safeName","color":"${m.colorHex}"}"""
  }
  val jsonArray = StringBuilder("[")
  dataPoints.forEachIndexed { i, pt ->
    jsonArray.append(
      """{"time":"${pt.timeLabel}","retail":${String.format(Locale.US, "%.1f", pt.retail)},"food":${String.format(Locale.US, "%.1f", pt.foodBeverage)},"services":${String.format(Locale.US, "%.1f", pt.services)},"logistics":${String.format(Locale.US, "%.1f", pt.logistics)},"health":${String.format(Locale.US, "%.1f", pt.healthcare)},"tech":${String.format(Locale.US, "%.1f", pt.tech)},"index":${String.format(Locale.US, "%.1f", pt.compositeIndex)}}"""
    )
    if (i < dataPoints.size - 1) jsonArray.append(",")
  }
  jsonArray.append("]")

  return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    body { background: #0D0D18; color: #E2E8F0; overflow: hidden; height: 100vh; width: 100vw; display: flex; flex-direction: column; }
    #chart-container { flex: 1; width: 100%; height: 100%; position: relative; padding: 10px 14px 10px 10px; }
    svg { width: 100%; height: 100%; overflow: visible; }
    .grid-line { stroke: #1E1E34; stroke-dasharray: 4 4; stroke-width: 1; }
    .axis-text { fill: #64748B; font-size: 10px; font-weight: 500; }
    .trend-line { fill: none; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round; transition: stroke-dashoffset 0.8s ease; }
    .active-dot { r: 5; stroke-width: 2.5; stroke: #0D0D18; }
    .tooltip-box {
      position: absolute; display: none; background: rgba(23, 23, 40, 0.95);
      border: 1px solid #33334D; border-radius: 8px; padding: 8px 12px;
      font-size: 11px; pointer-events: none; backdrop-filter: blur(8px);
      box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5); z-index: 100; min-width: 130px;
    }
    .tooltip-title { font-weight: bold; color: #D4AF37; margin-bottom: 4px; border-bottom: 1px solid #282844; padding-bottom: 2px; }
    .tooltip-row { display: flex; justify-content: space-between; gap: 8px; margin-top: 2px; }
    .crosshair { stroke: #D4AF37; stroke-width: 1; stroke-dasharray: 2 2; display: none; }
  </style>
</head>
<body>
  <div id="chart-container">
    <div id="tooltip" class="tooltip-box"></div>
    <svg id="chart-svg"></svg>
  </div>

  <script>
    const data = $jsonArray;
    const selectedSector = "${selectedSectorId ?: "all"}";
    const sectors = $sectorsJs;

    function render() {
      const container = document.getElementById('chart-container');
      const svg = document.getElementById('chart-svg');
      const tooltip = document.getElementById('tooltip');
      const width = container.clientWidth;
      const height = container.clientHeight;
      svg.setAttribute('viewBox', `0 0 ${'$'}{width} ${'$'}{height}`);
      svg.innerHTML = '';

      if (data.length === 0) return;

      const padL = 40, padR = 20, padT = 20, padB = 30;
      const chartW = width - padL - padR;
      const chartH = height - padT - padB;

      // Determine active sectors
      const activeSectors = selectedSector === 'all' 
        ? sectors 
        : sectors.filter(s => s.id === selectedSector);

      // Find min and max
      let maxVal = 0, minVal = Infinity;
      data.forEach(d => {
        activeSectors.forEach(s => {
          const v = d[s.id];
          if (v > maxVal) maxVal = v;
          if (v < minVal) minVal = v;
        });
      });
      if (maxVal === 0) maxVal = 100;
      if (minVal === Infinity) minVal = 0;
      maxVal = maxVal * 1.08;
      minVal = Math.max(0, minVal * 0.92);

      // 1. Grid Lines & Y Axis
      const gridCount = 4;
      for (let i = 0; i <= gridCount; i++) {
        const y = padT + (chartH / gridCount) * i;
        const val = Math.round(maxVal - ((maxVal - minVal) / gridCount) * i);
        
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', padL);
        line.setAttribute('y1', y);
        line.setAttribute('x2', width - padR);
        line.setAttribute('y2', y);
        line.setAttribute('class', 'grid-line');
        svg.appendChild(line);

        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', padL - 8);
        text.setAttribute('y', y + 3);
        text.setAttribute('text-anchor', 'end');
        text.setAttribute('class', 'axis-text');
        text.textContent = '$' + val;
        svg.appendChild(text);
      }

      // 2. X Axis Labels & Points Calculation
      const stepX = data.length > 1 ? chartW / (data.length - 1) : chartW;
      const points = data.map((d, i) => {
        const x = padL + i * stepX;
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', x);
        text.setAttribute('y', height - 10);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('class', 'axis-text');
        text.textContent = d.time;
        svg.appendChild(text);
        return { x, ...d };
      });

      // 3. Draw Monotone Bézier Curves (Recharts style)
      activeSectors.forEach(sec => {
        let pathD = '';
        points.forEach((p, idx) => {
          const normY = (p[sec.id] - minVal) / (maxVal - minVal || 1);
          const y = padT + chartH * (1 - normY);

          if (idx === 0) {
            pathD += `M ${'$'}{p.x},${'$'}{y}`;
          } else {
            const prev = points[idx - 1];
            const prevNormY = (prev[sec.id] - minVal) / (maxVal - minVal || 1);
            const prevY = padT + chartH * (1 - prevNormY);
            const cx1 = prev.x + (p.x - prev.x) / 2;
            const cx2 = prev.x + (p.x - prev.x) / 2;
            pathD += ` C ${'$'}{cx1},${'$'}{prevY} ${'$'}{cx2},${'$'}{y} ${'$'}{p.x},${'$'}{y}`;
          }
        });

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', pathD);
        path.setAttribute('class', 'trend-line');
        path.setAttribute('stroke', sec.color);
        svg.appendChild(path);
      });

      // 4. Interactive Crosshair & Tooltip handler
      const crosshair = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      crosshair.setAttribute('y1', padT);
      crosshair.setAttribute('y2', padT + chartH);
      crosshair.setAttribute('class', 'crosshair');
      svg.appendChild(crosshair);

      function handleMove(clientX) {
        const rect = container.getBoundingClientRect();
        const touchX = clientX - rect.left;
        let closestIdx = 0, closestDist = Infinity;
        points.forEach((p, idx) => {
          const dist = Math.abs(p.x - touchX);
          if (dist < closestDist) {
            closestDist = dist;
            closestIdx = idx;
          }
        });

        const activePt = points[closestIdx];
        crosshair.setAttribute('x1', activePt.x);
        crosshair.setAttribute('x2', activePt.x);
        crosshair.style.display = 'block';

        // Update Tooltip
        let rowsHtml = `<div class="tooltip-title">${'$'}{activePt.time}</div>`;
        activeSectors.forEach(s => {
          rowsHtml += `<div class="tooltip-row"><span style="color:${'$'}{s.color}">● ${'$'}{s.name}</span><strong>$${'$'}{activePt[s.id]}</strong></div>`;
        });
        tooltip.innerHTML = rowsHtml;
        tooltip.style.display = 'block';

        const tipWidth = 140;
        let tipLeft = activePt.x - tipWidth / 2;
        if (tipLeft < 10) tipLeft = 10;
        if (tipLeft + tipWidth > width - 10) tipLeft = width - tipWidth - 10;
        tooltip.style.left = tipLeft + 'px';
        tooltip.style.top = (padT + 10) + 'px';
      }

      container.addEventListener('mousemove', (e) => handleMove(e.clientX));
      container.addEventListener('touchmove', (e) => {
        if (e.touches && e.touches[0]) handleMove(e.touches[0].clientX);
      });
      container.addEventListener('mouseleave', () => {
        crosshair.style.display = 'none';
        tooltip.style.display = 'none';
      });
      container.addEventListener('touchend', () => {
        setTimeout(() => {
          crosshair.style.display = 'none';
          tooltip.style.display = 'none';
        }, 2000);
      });
    }

    window.addEventListener('resize', render);
    setTimeout(render, 50);
  </script>
</body>
</html>
""";
}

/**
 * Native Jetpack Compose Canvas counterpart with authentic Recharts aesthetic
 */
@Composable
private fun RechartsNativeCanvasComponent(
  dataPoints: List<SectorPerformanceDataPoint>,
  metas: List<SectorMeta>,
  selectedSectorId: String?,
  modifier: Modifier = Modifier
) {
  if (dataPoints.isEmpty()) return

  var selectedIndex by remember { mutableStateOf<Int?>(null) }
  val activeSectors = remember(selectedSectorId, metas) {
    if (selectedSectorId == null || selectedSectorId == "all") metas
    else metas.filter { it.id == selectedSectorId }
  }

  val activePoint = selectedIndex?.let { dataPoints.getOrNull(it) }

  Column(modifier = modifier) {
    // Interactive Tooltip Header (Recharts style)
    if (activePoint != null) {
      Surface(
        color = LavndrSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(0.5.dp, LavndrGlassBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 5.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(text = "الفترة: ${activePoint.timeLabel}", color = LavndrGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            activeSectors.take(3).forEach { s ->
              val valAmount = when (s.id) {
                "retail" -> activePoint.retail
                "food" -> activePoint.foodBeverage
                "services" -> activePoint.services
                "logistics" -> activePoint.logistics
                "health" -> activePoint.healthcare
                else -> activePoint.tech
              }
              Text(
                text = "${s.icon} $${String.format(Locale.US, "%.0f", valAmount)}",
                color = s.composeColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // Canvas
    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .pointerInput(dataPoints) {
          detectTapGestures { offset ->
            val step = size.width / (dataPoints.size - 1).coerceAtLeast(1)
            val idx = (offset.x / step).roundToInt().coerceIn(0, dataPoints.size - 1)
            selectedIndex = if (selectedIndex == idx) null else idx
          }
        }
        .pointerInput(dataPoints) {
          detectDragGestures(
            onDragStart = { offset ->
              val step = size.width / (dataPoints.size - 1).coerceAtLeast(1)
              selectedIndex = (offset.x / step).roundToInt().coerceIn(0, dataPoints.size - 1)
            },
            onDrag = { change, _ ->
              val step = size.width / (dataPoints.size - 1).coerceAtLeast(1)
              selectedIndex = (change.position.x / step).roundToInt().coerceIn(0, dataPoints.size - 1)
            },
            onDragEnd = { }
          )
        }
    ) {
      val w = size.width
      val h = size.height
      val padL = 10.dp.toPx()
      val padR = 10.dp.toPx()
      val padT = 15.dp.toPx()
      val padB = 20.dp.toPx()

      val chartW = w - padL - padR
      val chartH = h - padT - padB

      var maxVal = 0.0
      var minVal = Double.MAX_VALUE
      dataPoints.forEach { pt ->
        activeSectors.forEach { s ->
          val v = when (s.id) {
            "retail" -> pt.retail
            "food" -> pt.foodBeverage
            "services" -> pt.services
            "logistics" -> pt.logistics
            "health" -> pt.healthcare
            else -> pt.tech
          }
          if (v > maxVal) maxVal = v
          if (v < minVal) minVal = v
        }
      }
      if (maxVal == 0.0) maxVal = 100.0
      if (minVal == Double.MAX_VALUE) minVal = 0.0
      maxVal *= 1.08
      minVal = (minVal * 0.92).coerceAtLeast(0.0)

      // 1. Cartesian Grid (Dashed horizontal lines)
      val gridLines = 4
      val dashPathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
      for (i in 0..gridLines) {
        val y = padT + (chartH / gridLines) * i
        drawLine(
          color = Color(0xFF1E1E34),
          start = Offset(padL, y),
          end = Offset(w - padR, y),
          strokeWidth = 1.dp.toPx(),
          pathEffect = dashPathEffect
        )
      }

      // 2. Draw Sectors Curves
      val stepX = if (dataPoints.size > 1) chartW / (dataPoints.size - 1) else chartW

      activeSectors.forEach { sec ->
        val path = Path()
        dataPoints.forEachIndexed { idx, pt ->
          val v = when (sec.id) {
            "retail" -> pt.retail
            "food" -> pt.foodBeverage
            "services" -> pt.services
            "logistics" -> pt.logistics
            "health" -> pt.healthcare
            else -> pt.tech
          }
          val normY = (v - minVal) / (maxVal - minVal).coerceAtLeast(0.001)
          val y = padT + chartH * (1.0 - normY).toFloat()
          val x = padL + idx * stepX

          if (idx == 0) {
            path.moveTo(x, y)
          } else {
            val prevPt = dataPoints[idx - 1]
            val prevV = when (sec.id) {
              "retail" -> prevPt.retail
              "food" -> prevPt.foodBeverage
              "services" -> prevPt.services
              "logistics" -> prevPt.logistics
              "health" -> prevPt.healthcare
              else -> prevPt.tech
            }
            val prevNormY = (prevV - minVal) / (maxVal - minVal).coerceAtLeast(0.001)
            val prevY = padT + chartH * (1.0 - prevNormY).toFloat()
            val prevX = padL + (idx - 1) * stepX

            val cx1 = prevX + (x - prevX) / 2f
            val cx2 = prevX + (x - prevX) / 2f
            path.cubicTo(cx1, prevY, cx2, y, x, y)
          }
        }

        drawPath(
          path = path,
          color = sec.composeColor,
          style = Stroke(width = 2.5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )
      }

      // 3. Scrubbing Indicator & Crosshair
      if (selectedIndex != null && selectedIndex!! in dataPoints.indices) {
        val selX = padL + selectedIndex!! * stepX
        drawLine(
          color = LavndrGold,
          start = Offset(selX, padT),
          end = Offset(selX, padT + chartH),
          strokeWidth = 1.5.dp.toPx(),
          pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
        )

        drawCircle(
          color = LavndrGold,
          radius = 5.dp.toPx(),
          center = Offset(selX, padT + chartH / 2f)
        )
      }
    }
  }
}

package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserRole
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class LavndrTab(val titleAr: String, val icon: String) {
  HOME("الرئيسية", "◎"),
  MARKET("السوق", "⇅"),
  // ✅ جديد: دليل الـ120 نشاط — حصري لمشترك باقة ماقما بس
  MAGMA_DIRECTORY("الدليل", "🌋"),
  COMPONENTS("المكونات", "▦"),
  HISTORY("الأرشيف", "◷"),
  BUSINESS("البزنس", "🏪"),
  ADMIN("الأدمن", "🛡️")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LavndrApp(
  viewModel: LavndrViewModel = viewModel()
) {
  val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
  val isSigningIn by viewModel.isSigningIn.collectAsStateWithLifecycle()
  val loginErrorMessage by viewModel.loginErrorMessage.collectAsStateWithLifecycle()
  val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
  // ✅ Activity Context (لا Application Context) — مطلوب فعليًا من CredentialManager
  // لعرض واجهة اختيار حساب Google. LocalContext.current هنا مضمون إنه Activity
  // context لأن LavndrApp() بتتنادى من جوه MainActivity.setContent { } مباشرة.
  val activityContext = LocalContext.current
  val pendingActionsCount by viewModel.pendingActionsCount.collectAsStateWithLifecycle()

  // ✅ جديد: تسجيل الدخول بقى اختياري بالكامل — أي حد (حتى بدون تسجيل دخول خالص)
  // يقدر يتصفح الواجهات الرئيسية بداتا تجريبية واضحة (PreviewDataProvider،
  // mode="preview"، role="visitor" افتراضيًا من الريبو). شاشة تسجيل الدخول بقت
  // overlay اختياري (showLoginScreen) يتفتح من قائمة الحساب أو من بانر "بيانات
  // تجريبية" — مش بوابة إجبارية أول ما التطبيق يفتح، ومفيش أي "return" هنا بعد كده.
  var showLoginScreen by remember { mutableStateOf(false) }
  var pendingIntentAfterLogin by remember { mutableStateOf<String?>(null) }

  val needsSubscription by viewModel.needsSubscription.collectAsStateWithLifecycle()
  val subscriptionStatusForGate by viewModel.subscriptionStatus.collectAsStateWithLifecycle()
  val mySubscriptions by viewModel.mySubscriptions.collectAsStateWithLifecycle()

  // ✅ جديد: role=visitor (سجّل دخول بس لسه ما اشتركش) بقى مش بوابة إجبارية —
  // نفس مبدأ "زائر مجهول" بالظبط: يفضل يتصفح بداتا تجريبية، مع بانر ثابت وخيار
  // اختياري لفتح شاشة الاشتراك (subscriptionGateDismissed). القيمة ترجع false
  // تلقائيًا كل مرة needsSubscription تتفعل من جديد (دخول جديد بحساب مش مشترك).
  var subscriptionGateDismissed by remember { mutableStateOf(false) }
  LaunchedEffect(needsSubscription) {
    if (needsSubscription) subscriptionGateDismissed = false
  }
  // ✅ يقفل شاشة تسجيل الدخول تلقائيًا لما الدخول ينجح، وينفّذ أي نية معلّقة (مثلاً
  // المستخدم كان زائر مجهول وضغط "اشترك"، فبعد الدخول نفتحله بوابة الاشتراك تلقائيًا)
  LaunchedEffect(isLoggedIn) {
    if (isLoggedIn) {
      showLoginScreen = false
      if (pendingIntentAfterLogin == "subscribe") {
        subscriptionGateDismissed = false
      }
      pendingIntentAfterLogin = null
    }
  }

  var selectedTab by remember { mutableStateOf(LavndrTab.HOME) }
  // سجل التبويبات: زر الرجوع يعيد خطوة خطوة قبل الخروج من التطبيق
  val tabStack = remember { mutableStateListOf<LavndrTab>() }
  var progressRestored by remember { mutableStateOf(false) }
  val progressPrefs = LocalContext.current.getSharedPreferences("lavndr_progress", android.content.Context.MODE_PRIVATE)
  var showTermsModal by remember { mutableStateOf(false) }
  // الدفع/شراء الحصة (لأصحاب الـ120 فقط)
  var showPaymentModal by remember { mutableStateOf(false) }
  var paymentModalAmount by remember { mutableDoubleStateOf(513.0) }
  var paymentModalMarketRow by remember { mutableStateOf<Int?>(null) }
  var isSubmittingPayment by remember { mutableStateOf(false) }
  var paymentModalError by remember { mutableStateOf<String?>(null) }
  // فضاء الدخول: "market" = السوق الداخلي فقط (افتراضي لأصحاب الـ120) | "data" = لوحة بيانات اشتراكه الآخر
  var activeSpace by rememberSaveable { mutableStateOf("market") }
  var spaceChosen by rememberSaveable { mutableStateOf(false) }
  // شروط كل باقة: الباقة المطلوب الموافقة على شروطها + ما يُنفَّذ بعد الموافقة
  var termsTier by remember { mutableStateOf<String?>(null) }
  var termsRetry by remember { mutableStateOf<(() -> Unit)?>(null) }
  var showConfigWorker by remember { mutableStateOf(false) }
  var showAccountMenu by remember { mutableStateOf(false) }

  val data by viewModel.data.collectAsStateWithLifecycle()
  val participantInfo by viewModel.participantInfo.collectAsStateWithLifecycle()
  val businessPortal by viewModel.businessPortal.collectAsStateWithLifecycle()
  val magmaDirectory by viewModel.magmaDirectory.collectAsStateWithLifecycle()
  val currentUserEmail by viewModel.currentUserEmail.collectAsStateWithLifecycle()
  val termsText by viewModel.termsText.collectAsStateWithLifecycle()
  val bankDetails by viewModel.bankDetails.collectAsStateWithLifecycle()
  val lastActionError by viewModel.lastActionError.collectAsStateWithLifecycle()
  val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
  val monthlyHistory by viewModel.monthlyHistory.collectAsStateWithLifecycle()

  // ✅ جديد: دليل ماقما بيتحمّل تلقائيًا أول ما الدور يبقى magma فعليًا — مش لازم
  // ينتظر المستخدم يضغط على التاب الأول مرة
  LaunchedEffect(currentRole) {
    if (currentRole == UserRole.MAGMA) viewModel.loadMagmaDirectory()
  }

  val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
  val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
  val lastSyncTime by viewModel.lastSyncTime.collectAsStateWithLifecycle()
  val syncErrorMessage by viewModel.syncErrorMessage.collectAsStateWithLifecycle()
  val priceAlertConfig by viewModel.priceAlertConfig.collectAsStateWithLifecycle()

  val pendingPayments by viewModel.pendingPayments.collectAsStateWithLifecycle()
  val pendingSubscriptions by viewModel.pendingSubscriptions.collectAsStateWithLifecycle()
  val adminParticipants by viewModel.adminParticipants.collectAsStateWithLifecycle()
  val adminBusinesses by viewModel.adminBusinesses.collectAsStateWithLifecycle()
  val adminEntitlements by viewModel.adminEntitlements.collectAsStateWithLifecycle()
  val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
  val apEarnings by viewModel.apEarnings.collectAsStateWithLifecycle()
  val workerUrl by viewModel.workerUrl.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  // ✅ جديد: أي خطأ من عملية حساسة (شراء/بيع/اعتماد أدمن...) بيتعرض كـ snackbar
  // فورًا بدل ما يختفي بصمت زي النسخة القديمة.
  LaunchedEffect(lastActionError) {
    lastActionError?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearLastActionError()
    }
  }

  // إتاحة تبويب "البزنس" فقط لو المستخدم فعليًا مربوط بزنس (linked=true من
  // my_business_portal) — بدل ما يكون دور منفصل وهمي (BUSINESS_OWNER) زي قبل.
  val visibleTabs = remember(businessPortal.linked, currentRole, activeSpace) {
    val marketOnly = currentRole == UserRole.PARTICIPANT && activeSpace != "data"
    LavndrTab.entries.filter { tab ->
      if (marketOnly) return@filter tab == LavndrTab.MARKET || (tab == LavndrTab.BUSINESS && businessPortal.linked)
      when (tab) {
        LavndrTab.MARKET -> currentRole == UserRole.ADMIN
        LavndrTab.BUSINESS -> businessPortal.linked
        LavndrTab.ADMIN -> currentRole == UserRole.ADMIN
        LavndrTab.MAGMA_DIRECTORY -> currentRole == UserRole.MAGMA
        else -> true
      }
    }
  }
  LaunchedEffect(visibleTabs) {
    if (selectedTab !in visibleTabs && visibleTabs.isNotEmpty()) {
      selectedTab = visibleTabs.first()
    }
  }

  androidx.activity.compose.BackHandler(enabled = tabStack.isNotEmpty()) {
    val prev = tabStack.removeAt(tabStack.lastIndex)
    if (prev in visibleTabs) selectedTab = prev
  }
  // استعادة آخر مكان توقف عنده المستخدم (حسب إيميله) بعد معرفة التبويبات المسموحة له
  LaunchedEffect(isLoggedIn, currentUserEmail, visibleTabs) {
    if (!isLoggedIn || currentUserEmail.isBlank() || progressRestored || visibleTabs.isEmpty()) return@LaunchedEffect
    progressRestored = true
    val local = progressPrefs.getString("tab_" + currentUserEmail.lowercase(), null)
    val apply: (String?) -> Unit = { name ->
      LavndrTab.entries.firstOrNull { it.name == name }?.takeIf { it in visibleTabs }?.let { selectedTab = it }
    }
    apply(local)
    viewModel.loadSavedTab { apply(it ?: local) }
  }
  LaunchedEffect(selectedTab, progressRestored) {
    if (progressRestored && isLoggedIn && currentUserEmail.isNotBlank()) {
      progressPrefs.edit().putString("tab_" + currentUserEmail.lowercase(), selectedTab.name).apply()
      viewModel.saveTab(selectedTab.name, activeSpace)
    }
  }

  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val pulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(1000, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseAlpha"
  )

  val rotationAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(1000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotation"
  )

  // يفتح شروط الباقة المحددة ثم ينفّذ retry بعد الموافقة
  fun requireTerms(tier: String, retry: () -> Unit) {
    termsTier = tier
    termsRetry = retry
    viewModel.loadTermsFor(tier)
    showTermsModal = true
  }

  // يبدأ شراء حصة فعلي (لأصحاب الـ120): 451 ← اتفاقية لاڤندرز لإدارة البزنسات ثم يُعاد الطلب
  fun startBuyFlow(marketRow: Int?, shareValue: Double) {
    isSubmittingPayment = true
    paymentModalError = null
    viewModel.buyShare(marketRow) { result ->
      isSubmittingPayment = false
      if (result.code == 451) {
        requireTerms("business_agreement") { startBuyFlow(marketRow, shareValue) }
      } else if (result.error != null) {
        scope.launch { snackbarHostState.showSnackbar(result.error) }
      } else {
        paymentModalAmount = result.amount ?: shareValue
        paymentModalMarketRow = marketRow
        showPaymentModal = true
      }
    }
  }

  Scaffold(
    containerColor = LavndrVoid,
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      Column {
        TopAppBar(
          title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background((if (isOnline) LavndrEmerald else LavndrRed).copy(alpha = pulseAlpha))
              )
              Spacer(modifier = Modifier.width(6.dp))
              Column {
                Text(
                  text = "LAVNDR120",
                  color = LavndrGold,
                  fontWeight = FontWeight.Black,
                  fontSize = 16.sp,
                  letterSpacing = 1.sp
                )
                Text(
                  text = if (isOnline) "مباشر" else "بيانات مخزنة",
                  color = if (isOnline) LavndrEmerald else LavndrRed,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Medium
                )
              }
            }
          },
          actions = {
            IconButton(
              onClick = {
                viewModel.refreshNow()
                scope.launch {
                  snackbarHostState.showSnackbar(
                    message = "جاري جلب أحدث البيانات من السيرفر...",
                    duration = SnackbarDuration.Short
                  )
                }
              }
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Refresh",
                tint = if (isSyncing) LavndrGold else LavndrTextDim,
                modifier = if (isSyncing) Modifier.rotate(rotationAngle) else Modifier
              )
            }

            // ✅ الشريحة دي بقت تفتح قائمة حساب حقيقية (تسجيل خروج + عرض الدور
            // الفعلي القادم من السيرفر)، مش ديالوج تبديل دور وهمي
            Surface(
              color = LavndrSurfaceElevated,
              shape = RoundedCornerShape(100.dp),
              modifier = Modifier
                .clickable { showAccountMenu = true }
                .border(1.dp, LavndrGlassBorder, RoundedCornerShape(100.dp))
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.AccountCircle,
                  contentDescription = "User Account",
                  tint = LavndrGold,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isLoggedIn) currentUserEmail.substringBefore("@").take(12) else "زائر",
                  color = LavndrText,
                  fontSize = 11.sp
                )
              }
            }

            Spacer(modifier = Modifier.width(4.dp))

            Surface(
              color = if (isLoggedIn) LavndrGoldDim else LavndrGold,
              shape = RoundedCornerShape(100.dp)
            ) {
              Text(
                text = if (isLoggedIn) currentRole.labelAr.take(10) else "دخول",
                color = if (isLoggedIn) LavndrGold else LavndrVoid,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = LavndrVoid.copy(alpha = 0.95f),
            titleContentColor = LavndrGold
          )
        )

        AnimatedVisibility(visible = !isOnline && syncErrorMessage != null) {
          Surface(
            color = LavndrRed.copy(alpha = 0.15f),
            modifier = Modifier
              .fillMaxWidth()
              .border(0.5.dp, LavndrRed.copy(alpha = 0.4f))
          ) {
            Text(
              text = "تعذر الاتصال المباشر بالسيرفر (${syncErrorMessage?.take(40)})",
              color = LavndrRed,
              fontSize = 11.sp,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }
        }

        // ✅ جديد: بانر ثابت وصادق يوضّح إن الداتا المعروضة تجريبية — يظهر لغير
        // المسجلين دخول (متصفح مجهول) ولمين سجل دخول بس مش مشترك (role=visitor).
        // data.mode يرجع "preview" في الحالتين لأن الريبو أصلاً بيسيب _data كما هي
        // (PreviewDataProvider) طول ما مفيش دخول حقيقي ناجح (participant/subscriber/admin).
        AnimatedVisibility(visible = data.mode != "live") {
          Surface(
            color = LavndrGoldDim,
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                if (!isLoggedIn) showLoginScreen = true else subscriptionGateDismissed = false
              }
              .border(0.5.dp, LavndrGold.copy(alpha = 0.4f))
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (!isLoggedIn)
                  "🔍 بيانات تجريبية للعرض فقط — اضغط لتسجيل الدخول ورؤية بيانات LAVNDR120 الحقيقية"
                else
                  "🔒 حسابك غير مشترك — بيانات تجريبية معروضة، اضغط للاشتراك ورؤية البيانات الحقيقية",
                color = LavndrGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
              )
              Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = LavndrGold,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    },
    bottomBar = {
      NavigationBar(
        containerColor = LavndrVoid.copy(alpha = 0.95f),
        contentColor = LavndrText,
        tonalElevation = 0.dp,
        modifier = Modifier.border(1.dp, LavndrGlassBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
      ) {
        visibleTabs.forEach { tab ->
          val isSelected = selectedTab == tab
          NavigationBarItem(
            selected = isSelected,
            onClick = { if (tab != selectedTab) { tabStack.add(selectedTab); if (tabStack.size > 20) tabStack.removeAt(0); selectedTab = tab } },
            icon = {
              Text(text = tab.icon, fontSize = 18.sp, color = if (isSelected) LavndrGold else LavndrTextFaint)
            },
            label = {
              Text(
                text = tab.titleAr,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) LavndrGold else LavndrTextFaint
              )
            },
            colors = NavigationBarItemDefaults.colors(
              indicatorColor = LavndrGoldDim,
              selectedIconColor = LavndrGold,
              unselectedIconColor = LavndrTextFaint
            )
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (selectedTab) {
        LavndrTab.HOME -> {
          HomeScreen(
            data = data,
            participantInfo = participantInfo,
            currentRole = currentRole,
            monthlyHistory = monthlyHistory,
            selectedMonth = selectedMonth,
            onSubscribeClick = {
              if (isLoggedIn) {
                subscriptionGateDismissed = false
              } else {
                pendingIntentAfterLogin = "subscribe"
                showLoginScreen = true
              }
            },
            onSelectMonth = { month -> viewModel.selectMonth(month) },
            priceAlertConfig = priceAlertConfig,
            onSavePriceAlert = { viewModel.savePriceAlert(it) },
            currentUserEmail = currentUserEmail
          )
        }
        LavndrTab.MARKET -> {
          MarketScreen(
            data = data,
            participantInfo = participantInfo,
            fund = data.fund,
            settlementCycle = data.settlementCycle,
            settlementDate = data.settlementDate,
            currentUserEmail = currentUserEmail,
            currentRole = currentRole,
            onBuyListing = { item -> startBuyFlow(marketRow = item.row, shareValue = item.shareValue) },
            onBuyShare = { startBuyFlow(marketRow = null, shareValue = 513.0) },
            onSellShare = {
              viewModel.sellShare { result ->
                val msg = result.error ?: "تم تقديم طلب البيع إلى السيرفر بنجاح"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            }
          )
        }
        LavndrTab.MAGMA_DIRECTORY -> {
          MagmaDirectoryScreen(
            directory = magmaDirectory,
            onOpenBusiness = { sheetId, link ->
              viewModel.markMagmaBusinessViewed(sheetId)
              activityContext.startActivity(
                android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(link))
              )
            }
          )
        }
        LavndrTab.COMPONENTS -> {
          ComponentsScreen(
            weights = data.weights,
            topProducts = data.topProducts,
            dailyTrend = data.dailyOrderTrend,
            locations = data.ordersByLocation,
            sharePrice = data.fund.sharePrice,
            timestamp = data.timestamp,
            monthlySnapshots = data.monthlySnapshots,
            history = data.history
          )
        }
        LavndrTab.HISTORY -> {
          HistoryScreen(snapshots = data.monthlySnapshots)
        }
        LavndrTab.BUSINESS -> {
          BusinessPortalScreen(
            portalInfo = businessPortal,
            currentUserEmail = currentUserEmail,
            onToggleAutoAccept = { sheetId, enabled ->
              viewModel.toggleAutoAccept(sheetId, enabled) { result ->
                result.error?.let { scope.launch { snackbarHostState.showSnackbar(it) } }
              }
            },
            onSubmitAgreement = { sheetId, link ->
              viewModel.submitAgreement(sheetId, link) { result ->
                scope.launch { snackbarHostState.showSnackbar(result.error ?: "تم رفع الرابط — بانتظار مراجعة الإدارة") }
              }
            },
            onRequestCash = { sheetId ->
              viewModel.requestCash(sheetId) { result ->
                scope.launch { snackbarHostState.showSnackbar(result.error ?: "تم إرسال طلب الكاش للإدارة") }
              }
            }
          )
        }
        LavndrTab.ADMIN -> {
          AdminScreen(
            pendingPayments = pendingPayments,
            pendingSubscriptions = pendingSubscriptions,
            participants = adminParticipants,
            businesses = adminBusinesses,
            entitlements = adminEntitlements,
            auditLogs = auditLogs,
            apEarnings = apEarnings,
            adminEmail = currentUserEmail,
            onApprovePayment = { row ->
              viewModel.decidePayment(row, "approved") { result ->
                val msg = result.error ?: "تم اعتماد الدفعة وإرسال التحديث للسيرفر"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            },
            onRejectPayment = { row ->
              viewModel.decidePayment(row, "rejected") { result ->
                val msg = result.error ?: "تم رفض الدفعة"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            },
            onApproveSubscription = { row ->
              viewModel.decideSubscription(row, "approved") { result ->
                val msg = result.error ?: "تم اعتماد الاشتراك"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            },
            onRejectSubscription = { row ->
              viewModel.decideSubscription(row, "rejected") { result ->
                val msg = result.error ?: "تم رفض الاشتراك"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            },
            onLinkBusiness = { sheetId, email, name ->
              viewModel.linkBusiness(sheetId, email, name) { result ->
                val msg = result.error ?: "تم ربط البزنس بنجاح"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            },
            onToggleAutoAccept = { sheetId, enabled ->
              viewModel.toggleAutoAccept(sheetId, enabled) { result ->
                result.error?.let { scope.launch { snackbarHostState.showSnackbar(it) } }
              }
            },
            onToggleClosed = { sheetId, closed ->
              viewModel.toggleClosed(sheetId, closed) { result ->
                result.error?.let { scope.launch { snackbarHostState.showSnackbar(it) } }
              }
            },
            onAcceptEntitlement = { row ->
              viewModel.acceptEntitlement(row) { result ->
                val msg = result.error ?: "تم تقديم قبول الاستحقاق — مطلوب شيك ضمان بقيمة $${result.guaranteeAmount ?: ""}"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            },
            onConfirmGuarantee = { row ->
              viewModel.confirmGuarantee(row) { result ->
                val msg = result.error ?: "تم تأكيد استلام خطاب الضمان"
                scope.launch { snackbarHostState.showSnackbar(msg) }
              }
            }
          )
        }
      }
    }
  }

  // Terms Modal — شروط الباقة المحددة فقط (لكل مسار وباقة نص خاص)
  if (showTermsModal && termsTier != null) {
    TermsDialog(
      termsText = termsText,
      title = "شروط الباقة",
      onAccept = {
        val tier = termsTier ?: ""
        viewModel.acceptTerms(tier) { result ->
          if (result.error != null) {
            scope.launch { snackbarHostState.showSnackbar(result.error) }
          } else {
            showTermsModal = false
            val retry = termsRetry
            termsTier = null
            termsRetry = null
            retry?.invoke()
          }
        }
      },
      onDismiss = { showTermsModal = false; termsTier = null; termsRetry = null }
    )
  }

  // Payment Modal (شراء حصة — لأصحاب الـ120)
  if (showPaymentModal) {
    PaymentModal(
      amount = paymentModalAmount,
      stage = participantInfo?.pendingStage ?: "awaiting_otp",
      bankDetails = bankDetails,
      isSubmitting = isSubmittingPayment,
      errorMessage = paymentModalError,
      onSubmitVerification = { otp, txnRef ->
        isSubmittingPayment = true
        paymentModalError = null
        viewModel.submitPaymentVerification(otp, txnRef) { result ->
          isSubmittingPayment = false
          if (result.error != null) {
            paymentModalError = result.error
          } else {
            showPaymentModal = false
            scope.launch { snackbarHostState.showSnackbar("تم إرسال بيانات التحويل إلى الإدارة للمراجعة والاعتماد") }
          }
        }
      },
      onDismiss = { showPaymentModal = false; paymentModalError = null }
    )
  }

  // نافذة اشتراكاتي لمن له أكثر من اشتراك (مشارك الـ120 الذي له اشتراك بيانات آخر)
  if (isLoggedIn && currentRole == UserRole.PARTICIPANT && mySubscriptions.size >= 2 && !spaceChosen) {
    SubscriptionChooserDialog(
      items = mySubscriptions,
      onPick = { item ->
        activeSpace = if (item.tier.startsWith("oms_")) "market" else "data"
        spaceChosen = true
      },
      onDismiss = { spaceChosen = true }
    )
  }

  // Config Cloudflare Worker Dialog (إعداد فني اختياري — للتطوير/الاختبار فقط)
  if (showConfigWorker) {
    ConfigWorkerDialog(
      currentUrl = workerUrl,
      isOnline = isOnline,
      lastSync = lastSyncTime,
      onSave = {
        viewModel.setWorkerUrl(it)
        scope.launch { snackbarHostState.showSnackbar("تم حفظ الرابط وتحديث الاتصال") }
      },
      onDismiss = { showConfigWorker = false }
    )
  }

  // Account menu (تسجيل خروج + إعدادات فنية)
  if (showAccountMenu) {
    AccountMenuDialog(
      email = currentUserEmail,
      roleLabel = currentRole.labelAr,
      currentRole = currentRole,
      isLoggedIn = isLoggedIn,
      pendingActionsCount = pendingActionsCount,
      onFlushPendingActions = {
        viewModel.flushPendingOfflineActions { count ->
          scope.launch {
            snackbarHostState.showSnackbar(
              if (count > 0) "تم إرسال $count عملية مؤجلة بنجاح!" else "لا توجد عمليات مؤجلة للإرسال"
            )
          }
        }
      },
      onSignInClick = {
        showAccountMenu = false
        showLoginScreen = true
      },
      onSubscribeClick = {
        showAccountMenu = false
        if (isLoggedIn) {
          subscriptionGateDismissed = false
        } else {
          // ✅ الاشتراك محتاج توكن حقيقي — زائر مجهول لازم يسجل دخول الأول، وبعد
          // النجاح بوابة الاشتراك تتفتح تلقائيًا (راجع LaunchedEffect(isLoggedIn) فوق)
          pendingIntentAfterLogin = "subscribe"
          showLoginScreen = true
        }
      },
      onSignOut = {
        showAccountMenu = false
        viewModel.signOut()
      },
      onOpenWorkerSettings = {
        showAccountMenu = false
        showConfigWorker = true
      },
      onDismiss = { showAccountMenu = false }
    )
  }

  // ✅ جديد: شاشة تسجيل الدخول بقت overlay اختياري (Dialog) بدل بوابة إجبارية —
  // تتفتح من قائمة الحساب أو من بانر "بيانات تجريبية"، وتتقفل تلقائيًا لما الدخول ينجح.
  if (showLoginScreen) {
    Dialog(
      onDismissRequest = { showLoginScreen = false; pendingIntentAfterLogin = null },
      properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        GoogleSignInScreen(
          isSigningIn = isSigningIn,
          errorMessage = loginErrorMessage,
          onSignInClick = { viewModel.signInWithGoogle(activityContext) }
        )
        IconButton(
          onClick = { showLoginScreen = false; pendingIntentAfterLogin = null; viewModel.clearLoginError() },
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(24.dp)
        ) {
          Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = LavndrTextDim)
        }
      }
    }
  }

  // ✅ جديد: بوابة الاشتراك بقت overlay اختياري قابل للإغلاق (تصفح كزائر) بدل ما
  // تمنع أي تصفح خالص — المستخدم يقدر يقفلها ويرجع يشوف الداتا التجريبية، والبانر
  // الثابت فوق بيفضل يفتحها تاني في أي وقت.
  if (isLoggedIn && needsSubscription && !subscriptionGateDismissed) {
    Dialog(
      onDismissRequest = { subscriptionGateDismissed = true },
      properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
      SubscriptionGateScreen(
        subscriptionStatus = subscriptionStatusForGate,
        userEmail = currentUserEmail,
        onSubscribe = { tier, country, onError ->
          fun go() {
            viewModel.subscribe(tier, country) { r ->
              if (r.code == 451) { requireTerms(tier) { go() }; return@subscribe }
              (r.message ?: r.error)?.let(onError)
              viewModel.refreshNow()
            }
          }
          go()
        },
        onPayFranchise = { onError ->
          fun go() {
            viewModel.payFranchise { r ->
              if (r.code == 451) { requireTerms("franchise") { go() }; return@payFranchise }
              r.error?.let(onError)
              viewModel.refreshNow()
            }
          }
          go()
        },
        onSubmitOtp = { otp, txnRef -> viewModel.submitSubscriptionVerification(otp, txnRef) { viewModel.refreshNow() } },
        onRefreshStatus = { viewModel.refreshNow() },
        onDismiss = { subscriptionGateDismissed = true },
        mySubscriptions = mySubscriptions,
        onSelectSubscription = { t, c -> viewModel.selectSubscription(t, c) },
        onPrepay = { tier, country, onError ->
          fun go() {
            viewModel.prepaySubscription(tier, country) { r ->
              if (r.code == 451) { requireTerms(tier) { go() }; return@prepaySubscription }
              r.error?.let(onError)
              viewModel.refreshNow()
            }
          }
          go()
        }
      )
    }
  }
}

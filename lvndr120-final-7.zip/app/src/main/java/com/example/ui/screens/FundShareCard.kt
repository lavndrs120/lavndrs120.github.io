package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LavndrData
import com.example.data.model.ParticipantInfo
import com.example.data.model.UserRole
import com.example.ui.export.PortfolioPdfGenerator
import com.example.ui.theme.*

// بطاقة «قيمة حصتك في الصندوق» — شراء/بيع الحصة. تظهر لأصحاب الـ120 فقط داخل السوق الداخلي.
@Composable
fun FundShareCard(
  data: LavndrData,
  participantInfo: ParticipantInfo?,
  currentRole: UserRole,
  currentUserEmail: String,
  onBuyShare: () -> Unit,
  onSellShare: () -> Unit
) {
  val context = LocalContext.current
      Column {
        Text(
          text = "قيمة حصتك في الصندوق",
          color = LavndrTextDim,
          fontSize = 12.sp,
          letterSpacing = 2.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.padding(bottom = 6.dp)
        )

        val stageLabels = listOf("🔒 التداول مقفول", "🟢 تداول أساسي", "🟢 تداول نشط", "🏆 نضج كامل")
        val stage = data.fund.tradingStage.coerceIn(0, 3)
        Text(
          text = "${stageLabels[stage]} — أبطأ نشاط تجاري: ${data.fund.minBusinessOrders} طلب",
          color = LavndrGold,
          fontSize = 11.sp,
          modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            if (currentRole == UserRole.SUBSCRIBER) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(text = "📡", fontSize = 32.sp)
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = "أنت في باقة مطالعة بيانات السوق",
                    color = LavndrGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "شراء وتملك حصة فعلية بالصندوق متاح للمستثمرين المعتمدين.",
                    color = LavndrTextDim,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                  )
                }
              }
            } else if (participantInfo?.pendingStage != null) {
              // Pending payment state
              Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(text = "⏳", fontSize = 36.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = if (participantInfo.pendingStage == "awaiting_review")
                    "طلبك بانتظار مراجعة الأدمن ($${participantInfo.pendingAmount ?: 513.0})"
                  else "بانتظار تأكيد التحويل البنكي ($${participantInfo.pendingAmount ?: 513.0})",
                  color = LavndrGold,
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                  onClick = onBuyShare,
                  colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("إكمال تفاصيل الدفع والـ OTP", fontWeight = FontWeight.Bold)
                }
              }
            } else if (participantInfo?.status == "active" || participantInfo?.status == "selling") {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "القيمة الحالية", color = LavndrEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                      color = LavndrEmeraldDim,
                      shape = RoundedCornerShape(100.dp)
                    ) {
                      Text(
                        text = "1 حصة",
                        color = LavndrEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }
                  Text(
                    text = "$${participantInfo.currentValue}",
                    color = LavndrEmerald,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(text = "سعر الدخول", color = LavndrTextDim, fontSize = 11.sp)
                  Text(
                    text = "$${participantInfo.sharePrice ?: "—"}",
                    color = LavndrText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                  if (!participantInfo.entryDate.isNullOrBlank()) {
                    Text(text = "منذ ${participantInfo.entryDate}", color = LavndrTextFaint, fontSize = 10.sp)
                  }
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              val isPnlPos = !(participantInfo.pnl?.startsWith("-") ?: false)
              Card(
                colors = CardDefaults.cardColors(
                  containerColor = if (isPnlPos) LavndrEmeraldDim else LavndrRedDim
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(text = "الربح / الخسارة", color = LavndrTextDim, fontSize = 11.sp)
                    Text(
                      text = "${participantInfo.pnlPercent}%",
                      color = if (isPnlPos) LavndrEmerald else LavndrRed,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                  Text(
                    text = "$${participantInfo.pnl}",
                    color = if (isPnlPos) LavndrEmerald else LavndrRed,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              if (participantInfo.status == "selling") {
                Text(
                  text = "✓ حصتك معروضة حالياً بالسوق الداخلي بانتظار مشترٍ",
                  color = LavndrAmethyst,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.fillMaxWidth()
                )
              } else {
                Button(
                  onClick = onSellShare,
                  colors = ButtonDefaults.buttonColors(containerColor = LavndrRedDim, contentColor = LavndrRed),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.fillMaxWidth().testTag("sell_share_button")
                ) {
                  Text("عرض الحصة للبيع بالسوق الداخلي", fontWeight = FontWeight.Bold)
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = {
                    val shareText = """
                      📊 بطاقة ملكية استثمارية في LAVNDR120:
                      • المؤشر: أداء 120 نشاط تجاري
                      • القيمة الحالية للحصة: $${participantInfo.currentValue}
                      • العائد المحقق: ${participantInfo.pnlPercent}% ($${participantInfo.pnl})
                      • الحالة: ${if (participantInfo.status == "selling") "معروضة للبيع بالسوق الداخلي" else "نشطة ومستثمرة"}
                      • الدورة المحاسبية: T+2
                    """.trimIndent()
                    val sendIntent = Intent().apply {
                      action = Intent.ACTION_SEND
                      putExtra(Intent.EXTRA_TEXT, shareText)
                      type = "text/plain"
                    }
                    val shareIntent = Intent.createChooser(sendIntent, "مشاركة بيانات الحصة الاستثمارية")
                    context.startActivity(shareIntent)
                  },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("مشاركة النص", color = LavndrGold, fontSize = 11.sp)
                }

                Button(
                  onClick = {
                    PortfolioPdfGenerator.generateAndShareStatement(
                      context = context,
                      userEmail = currentUserEmail,
                      participantInfo = participantInfo,
                      fundInfo = data.fund,
                      weights = data.weights
                    )
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = LavndrGoldDim, contentColor = LavndrGold),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier
                    .weight(1.3f)
                    .testTag("export_pdf_statement_button")
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("كشف رسمي (PDF)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            } else {
              // Not yet a participant
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = "انضم كشريك مستثمر في أداء 120 نشاط تجاري",
                  color = LavndrText,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.SemiBold,
                  textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                  onClick = onBuyShare,
                  colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.fillMaxWidth().testTag("buy_share_button")
                ) {
                  Text("اشتري حصة بالصندوق — $513", fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
}

package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ComponentWeight
import com.example.data.model.DailyOrderTrend
import com.example.data.model.HistoryPoint
import com.example.data.model.LocationOrder
import com.example.data.model.MonthlySnapshot
import com.example.data.model.TopProduct
import com.example.ui.components.ConsumerIndexLineChart
import com.example.ui.components.DailyOrdersTrendBarChart
import com.example.ui.components.LocationDistributionChart
import com.example.ui.components.RechartsSectorTrendChart
import com.example.ui.components.TopProductsBarChart
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ComponentsScreen(
  weights: List<ComponentWeight>,
  topProducts: List<TopProduct>,
  dailyTrend: List<DailyOrderTrend>,
  locations: List<LocationOrder>,
  sharePrice: Double,
  timestamp: String,
  monthlySnapshots: List<MonthlySnapshot> = emptyList(),
  history: List<HistoryPoint> = emptyList(),
  modifier: Modifier = Modifier
) {
  var searchQuery by remember { mutableStateOf("") }
  var showChartsSection by remember { mutableStateOf(true) }
  val context = LocalContext.current

  val filteredWeights = remember(searchQuery, weights) {
    if (searchQuery.isBlank()) weights
    else {
      val q = searchQuery.trim().lowercase()
      weights.filter { it.name.lowercase().contains(q) || it.ticker.lowercase().contains(q) }
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    // Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "مكونات المؤشر",
          color = LavndrGold,
          fontSize = 11.sp,
          letterSpacing = 4.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "الأوزان وتحليلات الطلبات",
          color = LavndrText,
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "${weights.size} نشاط تجاري مسجل • آخر تحديث: ${timestamp.replace("T", " ")}",
          color = LavndrTextDim,
          fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
          onClick = {
            val top5 = weights.take(5).joinToString("\n") { "• ${it.ticker} (${it.name}): ${it.weight}%" }
            val summaryText = """
              📋 نظرة عامة على مكونات مؤشر LAVNDR120:
              • إجمالي الأنشطة: ${weights.size} نشاط
              • أعلى المكونات وزنًا:
              $top5
              • تاريخ التحديث: ${timestamp.replace("T", " ")}
            """.trimIndent()
            val sendIntent = Intent().apply {
              action = Intent.ACTION_SEND
              putExtra(Intent.EXTRA_TEXT, summaryText)
              type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, "مشاركة تقرير مكونات المؤشر")
            context.startActivity(shareIntent)
          },
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
          modifier = Modifier.height(34.dp)
        ) {
          Text("مشاركة ملخص الأوزان والمكونات", color = LavndrGold, fontSize = 11.sp)
        }
      }
    }

    // Toggle analytics vs pure list
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "التحليلات المعتمدة للطلبات (3 أبعاد)",
          color = LavndrTextDim,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )
        TextButton(onClick = { showChartsSection = !showChartsSection }) {
          Text(if (showChartsSection) "إخفاء الرسوم" else "عرض الرسوم", color = LavndrGold, fontSize = 12.sp)
        }
      }
    }

    if (showChartsSection) {
      // 0. Recharts Sector Investment Trend Visualization (120 Tracked Activities)
      item {
        RechartsSectorTrendChart(
          weights = weights,
          monthlySnapshots = monthlySnapshots,
          dailyTrends = dailyTrend,
          history = history,
          sharePrice = sharePrice,
          modifier = Modifier.fillMaxWidth()
        )
      }

      // 0.1 Consumer Index Dynamic Line Chart (120 Tracked Activities)
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            ConsumerIndexLineChart(
              weights = weights,
              sharePrice = sharePrice,
              modifier = Modifier.fillMaxWidth()
            )
          }
        }
      }

      // 1. Top Ordered Products
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "1. أكثر المنتجات طلباً (حسب المنتج)",
              color = LavndrEmerald,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(bottom = 12.dp)
            )
            TopProductsBarChart(
              products = topProducts,
              modifier = Modifier.fillMaxWidth()
            )
          }
        }
      }

      // 2. Daily Orders Trend
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "2. اتجاه الطلبات اليومي (حسب التاريخ - آخر 30 يوم)",
              color = LavndrGold,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(bottom = 8.dp)
            )
            DailyOrdersTrendBarChart(
              trend = dailyTrend,
              modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
            )
          }
        }
      }

      // 3. Orders by Location
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "3. توزيع الطلبات الجغرافي (حسب الموقع)",
              color = LavndrSapphire,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(bottom = 8.dp)
            )
            LocationDistributionChart(
              locations = locations,
              modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
            )
          }
        }
      }
    }

    // Search bar for components
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("ابحث عن نشاط تجاري أو رمز...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = LavndrTextDim) },
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = LavndrGold,
          unfocusedBorderColor = LavndrGlassBorder,
          focusedTextColor = LavndrText,
          unfocusedTextColor = LavndrText
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("component_search_input")
      )
    }

    // Components List Header
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("النشاط التجاري والرمز", color = LavndrTextDim, fontSize = 11.sp)
        Text("الوزن والتخصيص ($)", color = LavndrTextDim, fontSize = 11.sp)
      }
    }

    // Components List
    itemsIndexed(filteredWeights, key = { _, item -> item.sheetId }) { index, item ->
      ComponentRowItem(
        rank = index + 1,
        item = item,
        sharePrice = sharePrice
      )
    }
  }
}

@Composable
private fun ComponentRowItem(
  rank: Int,
  item: ComponentWeight,
  sharePrice: Double
) {
  val alloc = (item.weight / 100.0 * sharePrice)
  val badgeColor = when {
    item.weight >= 8.0 -> LavndrGold
    item.weight >= 3.0 -> LavndrSapphire
    else -> LavndrTextDim
  }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Text(
          text = "$rank",
          color = LavndrTextFaint,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.width(24.dp)
        )

        Surface(
          color = badgeColor.copy(alpha = 0.15f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = item.ticker,
            color = badgeColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Text(
            text = item.name,
            color = LavndrText,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = "${item.count} طلب مسجل",
            color = LavndrTextDim,
            fontSize = 10.sp
          )
        }
      }

      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "${String.format(Locale.US, "%.1f", item.weight)}%",
          color = badgeColor,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "$${String.format(Locale.US, "%.2f", alloc)}",
          color = LavndrTextDim,
          fontSize = 10.sp
        )
      }
    }
  }
}

package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LavndrColorScheme = darkColorScheme(
  primary = LavndrGold,
  onPrimary = Color(0xFF04040A),
  primaryContainer = LavndrGoldDim,
  onPrimaryContainer = LavndrGoldLight,
  secondary = LavndrSapphire,
  onSecondary = Color.White,
  secondaryContainer = LavndrSapphireDim,
  onSecondaryContainer = Color(0xFF93C5FD),
  tertiary = LavndrEmerald,
  onTertiary = Color(0xFF04040A),
  tertiaryContainer = LavndrEmeraldDim,
  onTertiaryContainer = Color(0xFF6EE7B7),
  background = LavndrVoid,
  onBackground = LavndrText,
  surface = LavndrSurface,
  onSurface = LavndrText,
  surfaceVariant = LavndrSurfaceElevated,
  onSurfaceVariant = LavndrTextDim,
  error = LavndrRed,
  onError = Color.White,
  errorContainer = LavndrRedDim,
  onErrorContainer = Color(0xFFFDA4AF),
  outline = LavndrGlassBorder,
  outlineVariant = LavndrGlassBorderBright
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = LavndrColorScheme,
    typography = Typography,
    content = content
  )
}


package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MagmaBusinessEntry
import com.example.data.model.MagmaDirectoryResponse
import com.example.ui.theme.*
import java.util.Locale

// ✅ جديد: دليل الـ120 نشاط الحصري لمشترك باقة ماقما — مرتبين حسب وزنهم الاستهلاكي
// الحقيقي بالمؤشر. كل نشاط بس اسمه/فئته/ترتيبه ورابط خارجي (يدخله الأدمن يدويًا)،
// بدون أي بيانات عملاء أو طلبات خام — نفس مبدأ خصوصية الأبعاد المعتمدة بالنظام.
@Composable
fun MagmaDirectoryScreen(
  directory: MagmaDirectoryResponse,
  onOpenBusiness: (sheetId: String, link: String) -> Unit,
  modifier: Modifier = Modifier
) {
  val businesses = directory.businesses
  val total = if (directory.totalBusinesses > 0) directory.totalBusinesses else businesses.size
  val progress = if (total > 0) directory.viewedCount.toFloat() / total.toFloat() else 0f

  LazyColumn(
    modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp)
  ) {
    item {
      Column(
        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "🌋 عضوية ماقما",
          color = Color(0xFFFDBA74),
          fontSize = 11.sp,
          letterSpacing = 2.sp
        )
        Text(
          text = "دليل السوق الكامل",
          color = LavndrGold,
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(top = 4.dp, bottom = 6.dp)
        )
        Text(
          text = "السوق مش اللي تعرفه. السوق هو اللي تقدر تختاره.",
          color = Color(0xFFFDBA74),
          fontSize = 11.sp,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(bottom = 10.dp)
        )
        Text(
          text = "اطّلعت على ${directory.viewedCount} من $total نشاط (${(progress * 100).toInt()}%)",
          color = LavndrTextDim,
          fontSize = 12.sp
        )
      }
    }
    item {
      LinearProgressIndicator(
        progress = { progress },
        modifier = Modifier.fillMaxWidth().height(8.dp).padding(bottom = 8.dp),
        color = Color(0xFFF97316),
        trackColor = LavndrGlassBorder,
        strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
      )
    }

    if (businesses.isEmpty()) {
      item {
        Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
          Text(
            text = "لسه مفيش بيانات كفاية لعرض الدليل",
            color = LavndrTextFaint,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
          )
        }
      }
    } else {
      items(businesses, key = { it.sheetId }) { business ->
        MagmaBusinessCard(business = business, onClick = {
          if (business.link.isNotBlank()) onOpenBusiness(business.sheetId, business.link)
        })
      }
    }
  }
}

@Composable
private fun MagmaBusinessCard(business: MagmaBusinessEntry, onClick: () -> Unit) {
  val hasLink = business.link.isNotBlank()
  Card(
    onClick = onClick,
    enabled = hasLink,
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (hasLink) LavndrSurfaceElevated else LavndrSurfaceElevated.copy(alpha = 0.6f)
    )
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .background(LavndrGoldDim, RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
      ) {
        Text("🏪", fontSize = 16.sp)
      }
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "#${business.rank} ${business.name}",
            color = LavndrText,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
          )
          if (business.viewed) {
            Text(
              text = "  ✓ تم الاطلاع",
              color = LavndrEmerald,
              fontSize = 10.sp
            )
          }
        }
        Text(
          text = "${business.category} · وزن ${String.format(Locale.US, "%.2f", business.weight)}% بالسوق",
          color = LavndrTextDim,
          fontSize = 11.sp,
          modifier = Modifier.padding(top = 2.dp)
        )
      }
      if (hasLink) {
        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = LavndrGold)
      } else {
        Text("بدون رابط", color = LavndrTextFaint, fontSize = 10.sp)
      }
    }
  }
}

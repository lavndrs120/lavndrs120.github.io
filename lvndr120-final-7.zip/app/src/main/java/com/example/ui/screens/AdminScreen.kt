package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun AdminScreen(
  pendingPayments: List<PendingPayment>,
  pendingSubscriptions: List<PendingSubscription>,
  participants: List<ParticipantAdminItem>,
  businesses: List<BusinessAdminItem>,
  entitlements: List<BusinessEntitlement>,
  auditLogs: List<AuditLogItem>,
  apEarnings: List<ApEarning>,
  adminEmail: String,
  onApprovePayment: (row: Int) -> Unit,
  onRejectPayment: (row: Int) -> Unit,
  onApproveSubscription: (row: Int) -> Unit,
  onRejectSubscription: (row: Int) -> Unit,
  onLinkBusiness: (sheetId: String, email: String, name: String) -> Unit,
  onToggleAutoAccept: (sheetId: String, enabled: Boolean) -> Unit,
  onToggleClosed: (sheetId: String, closed: Boolean) -> Unit,
  onAcceptEntitlement: (row: Int) -> Unit,
  onConfirmGuarantee: (row: Int) -> Unit,
  modifier: Modifier = Modifier
) {
  var linkSheetId by remember { mutableStateOf("") }
  // ✅ جديد: تتبع الصفوف قيد المعالجة حاليًا — الباك اند نفسه محمي فعليًا بقفل
  // (LockService.getScriptLock في decideAdminPayment/decideAdminSubscription)
  // وفحص currentStatus، فمفيش خطر مالي حقيقي من ضغطة مزدوجة. لكن من غير حماية
  // هنا، ضغطتين سريعتين كانتا هتؤديا لظهور رسالة خطأ مربكة ("اتقرر فيه بالفعل")
  // لعملية نجحت فعليًا في المرة الأولى — هذا تحسين تجربة استخدام بحت.
  var processingPaymentRows by remember { mutableStateOf(setOf<Int>()) }
  var processingSubscriptionRows by remember { mutableStateOf(setOf<Int>()) }
  // ✅ حماية بأولوية أعلى: accept_entitlement/confirm_guarantee في الباك اند
  // (markEntitlementAccepted/confirmGuaranteeReceived) بلا LockService.getScriptLock()
  // إطلاقًا (بعكس decideAdminPayment/decideAdminSubscription) — يعني نظريًا ضغطتين
  // شبه متزامنتين ممكن الاتنين يقرآ نفس currentStatus قبل ما أي واحد يكتب، فينفذوا
  // مرتين (تكرار creditApIncentive في confirmGuaranteeReceived تحديدًا = مضاعفة حافز
  // الـAP فعليًا). هذه حماية على مستوى العميل بس — الإصلاح الجذري لازم يكون في الـ.gs
  // نفسه (إضافة نفس القفل)، لكن ده بره نطاق تطبيق الأندرويد.
  var processingEntitlementRows by remember { mutableStateOf(setOf<Int>()) }

  // ✅ إصلاح: أي تحديث لقائمة pendingPayments (نجاح أو فشل العملية، الاثنين
  // بيسببوا استدعاء fetchAdminData من جوه الـ Repository) لازم يصفّي أي صف
  // مش موجود فيها بقى من processingPaymentRows — وإلا لو العملية فشلت (زي "هذا
  // الطلب اتقرر فيه بالفعل" من ضغطة سابقة)، الزر كان هيفضل معطّل للأبد لأن مفيش
  // أي إشارة نجاح توصله يشيل نفسه من قائمة "قيد المعالجة".
  LaunchedEffect(pendingPayments) {
    val currentRows = pendingPayments.map { it.row }.toSet()
    processingPaymentRows = processingPaymentRows.intersect(currentRows)
  }
  LaunchedEffect(pendingSubscriptions) {
    val currentRows = pendingSubscriptions.map { it.row }.toSet()
    processingSubscriptionRows = processingSubscriptionRows.intersect(currentRows)
  }
  LaunchedEffect(entitlements) {
    val currentAvailableOrAwaiting = entitlements
      .filter { it.status == "available" || it.status == "accepted_awaiting_guarantee" }
      .map { it.row }.toSet()
    processingEntitlementRows = processingEntitlementRows.intersect(currentAvailableOrAwaiting)
  }
  var linkBusinessName by remember { mutableStateOf("") }
  var linkEmail by remember { mutableStateOf("") }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    // Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "لوحة تحكم المسؤول (ADMIN)",
          color = LavndrGold,
          fontSize = 11.sp,
          letterSpacing = 4.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "إدارة الصندوق والمدفوعات",
          color = LavndrText,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "الأدمن: $adminEmail",
          color = LavndrTextDim,
          fontSize = 11.sp
        )
      }
    }

    // 1. AP Cumulative Incentive
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "🏷️ حافز الـAP التراكمي (رمزي 5%)",
            color = LavndrGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
          )
          apEarnings.forEach { ap ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = "${ap.name} (${ap.code})", color = LavndrText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(text = "ميسر إنشاء/استرداد السلة (AP)", color = LavndrTextDim, fontSize = 10.sp)
              }
              Text(
                text = "$${String.format(Locale.US, "%.2f", ap.earnings)}",
                color = LavndrGold,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // 2. Pending Payments
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "💳 دفعات بانتظار المراجعة",
              color = LavndrGold,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
            Surface(color = LavndrGoldDim, shape = RoundedCornerShape(100.dp)) {
              Text(
                text = "${pendingPayments.size}",
                color = LavndrGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          if (pendingPayments.isEmpty()) {
            Text("لا توجد دفعات بانتظار المراجعة", color = LavndrTextFaint, fontSize = 12.sp, modifier = Modifier.padding(vertical = 12.dp))
          } else {
            pendingPayments.forEach { pay ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = LavndrVoid)
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(text = pay.email, color = LavndrText, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "$${pay.amount}", color = LavndrEmerald, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                  }
                  Text(text = "مرجع المعاملة: ${pay.txnRef.ifBlank { "—" }}", color = LavndrGold, fontSize = 11.sp)
                  Text(text = "طلب في: ${pay.requestedAt}", color = LavndrTextDim, fontSize = 10.sp)

                  Spacer(modifier = Modifier.height(8.dp))

                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val isProcessing = pay.row in processingPaymentRows
                    // ✅ طبقة أمان إضافية: مهلة احتياطية 8 ثواني تعيد تفعيل الزر
                    // تلقائيًا حتى لو فشلت العملية (وبالتالي الصف لسه موجود في
                    // pendingPayments فمفيش تغيير يشيله عبر الـ LaunchedEffect
                    // الأساسية فوق) — الباك اند نفسه (LockService + فحص currentStatus)
                    // هو خط الحماية الحقيقي ضد التنفيذ المزدوج الفعلي، هذا مجرد UX.
                    LaunchedEffect(isProcessing) {
                      if (isProcessing) {
                        kotlinx.coroutines.delay(8000)
                        processingPaymentRows = processingPaymentRows - pay.row
                      }
                    }
                    Button(
                      onClick = {
                        processingPaymentRows = processingPaymentRows + pay.row
                        onApprovePayment(pay.row)
                      },
                      enabled = !isProcessing,
                      colors = ButtonDefaults.buttonColors(containerColor = LavndrEmerald, contentColor = LavndrVoid),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.weight(1f).testTag("approve_payment_${pay.row}")
                    ) {
                      if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = LavndrVoid, strokeWidth = 2.dp)
                      } else {
                        Text("اعتماد الدفعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                    Button(
                      onClick = {
                        processingPaymentRows = processingPaymentRows + pay.row
                        onRejectPayment(pay.row)
                      },
                      enabled = !isProcessing,
                      colors = ButtonDefaults.buttonColors(containerColor = LavndrRed, contentColor = Color.White),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.weight(1f).testTag("reject_payment_${pay.row}")
                    ) {
                      if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                      } else {
                        Text("رفض", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 3. Pending Subscriptions
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "📡 اشتراكات لافا/سنوي بانتظار المراجعة",
              color = LavndrGold,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
            Surface(color = LavndrGoldDim, shape = RoundedCornerShape(100.dp)) {
              Text(
                text = "${pendingSubscriptions.size}",
                color = LavndrGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          if (pendingSubscriptions.isEmpty()) {
            Text("لا توجد اشتراكات بانتظار المراجعة", color = LavndrTextFaint, fontSize = 12.sp, modifier = Modifier.padding(vertical = 12.dp))
          } else {
            pendingSubscriptions.forEach { sub ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = LavndrVoid)
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(text = sub.email, color = LavndrText, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "$${sub.amount} (${sub.tier})", color = LavndrGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                  }
                  Text(text = "مرجع التحويل: ${sub.txnRef.ifBlank { "—" }}", color = LavndrGold, fontSize = 11.sp)
                  Spacer(modifier = Modifier.height(8.dp))

                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val isProcessingSub = sub.row in processingSubscriptionRows
                    LaunchedEffect(isProcessingSub) {
                      if (isProcessingSub) {
                        kotlinx.coroutines.delay(8000)
                        processingSubscriptionRows = processingSubscriptionRows - sub.row
                      }
                    }
                    Button(
                      onClick = {
                        processingSubscriptionRows = processingSubscriptionRows + sub.row
                        onApproveSubscription(sub.row)
                      },
                      enabled = !isProcessingSub,
                      colors = ButtonDefaults.buttonColors(containerColor = LavndrEmerald, contentColor = LavndrVoid),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.weight(1f)
                    ) {
                      if (isProcessingSub) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = LavndrVoid, strokeWidth = 2.dp)
                      } else {
                        Text("اعتماد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                    Button(
                      onClick = {
                        processingSubscriptionRows = processingSubscriptionRows + sub.row
                        onRejectSubscription(sub.row)
                      },
                      enabled = !isProcessingSub,
                      colors = ButtonDefaults.buttonColors(containerColor = LavndrRed, contentColor = Color.White),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.weight(1f)
                    ) {
                      if (isProcessingSub) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                      } else {
                        Text("رفض", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 4. Business Linking & Management
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "🔗 ربط البزنسات بالإيميلات",
            color = LavndrGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = linkSheetId,
            onValueChange = { linkSheetId = it },
            placeholder = { Text("SheetID (مثال: ID-1)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = LavndrGold,
              unfocusedBorderColor = LavndrGlassBorder,
              focusedTextColor = LavndrText,
              unfocusedTextColor = LavndrText
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = linkBusinessName,
            onValueChange = { linkBusinessName = it },
            placeholder = { Text("اسم النشاط التجاري") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = LavndrGold,
              unfocusedBorderColor = LavndrGlassBorder,
              focusedTextColor = LavndrText,
              unfocusedTextColor = LavndrText
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = linkEmail,
            onValueChange = { linkEmail = it },
            placeholder = { Text("إيميل صاحب النشاط") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = LavndrGold,
              unfocusedBorderColor = LavndrGlassBorder,
              focusedTextColor = LavndrText,
              unfocusedTextColor = LavndrText
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(10.dp))

          Button(
            onClick = {
              if (linkSheetId.isNotBlank() && linkEmail.isNotBlank()) {
                onLinkBusiness(linkSheetId, linkEmail, linkBusinessName)
                linkSheetId = ""
                linkBusinessName = ""
                linkEmail = ""
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("ربط / تحديث النشاط التجاري", fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(12.dp))

          businesses.take(8).forEach { b ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
              shape = RoundedCornerShape(8.dp),
              colors = CardDefaults.cardColors(containerColor = LavndrVoid)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = b.name, color = LavndrText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text(text = "SheetID: ${b.sheetId} • ${b.email.ifBlank { "⚠️ غير مربوط" }}", color = if (b.email.isBlank()) LavndrRed else LavndrTextDim, fontSize = 10.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  FilledTonalButton(
                    onClick = { onToggleAutoAccept(b.sheetId, !b.autoAccept) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                  ) {
                    Text(if (b.autoAccept) "✓ تلقائي" else "يدوي", fontSize = 10.sp)
                  }
                  FilledTonalButton(
                    onClick = { onToggleClosed(b.sheetId, !b.closed) },
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = if (b.closed) LavndrEmeraldDim else LavndrRedDim),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                  ) {
                    Text(if (b.closed) "إعادة فتح" else "إغلاق", fontSize = 10.sp, color = if (b.closed) LavndrEmerald else LavndrRed)
                  }
                }
              }
            }
          }
        }
      }
    }

    // 5. Business Entitlements
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "🏪 استحقاقات البزنسات وشيكات الضمان",
            color = LavndrGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(10.dp))

          entitlements.forEach { ent ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = LavndrVoid)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(text = ent.name, color = LavndrText, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                  Text(text = "استحقاق: $${ent.entitlement}", color = LavndrEmerald, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                  text = "شيك المطالبة: $${ent.guaranteeAmount} (مساهمة $${ent.entitlement} + نمو 36%: $${ent.growthAmount})",
                  color = LavndrGold,
                  fontSize = 10.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                when (ent.status) {
                  "available" -> {
                    val isProcessingEnt = ent.row in processingEntitlementRows
                    LaunchedEffect(isProcessingEnt) {
                      if (isProcessingEnt) {
                        kotlinx.coroutines.delay(8000)
                        processingEntitlementRows = processingEntitlementRows - ent.row
                      }
                    }
                    Button(
                      onClick = {
                        processingEntitlementRows = processingEntitlementRows + ent.row
                        onAcceptEntitlement(ent.row)
                      },
                      enabled = !isProcessingEnt,
                      colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.fillMaxWidth()
                    ) {
                      if (isProcessingEnt) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = LavndrVoid, strokeWidth = 2.dp)
                      } else {
                        Text("تسجيل قبول البزنس (فتح مطالبة الضمان)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                  "accepted_awaiting_guarantee" -> {
                    val isProcessingEnt = ent.row in processingEntitlementRows
                    LaunchedEffect(isProcessingEnt) {
                      if (isProcessingEnt) {
                        kotlinx.coroutines.delay(8000)
                        processingEntitlementRows = processingEntitlementRows - ent.row
                      }
                    }
                    Button(
                      onClick = {
                        processingEntitlementRows = processingEntitlementRows + ent.row
                        onConfirmGuarantee(ent.row)
                      },
                      enabled = !isProcessingEnt,
                      colors = ButtonDefaults.buttonColors(containerColor = LavndrEmerald, contentColor = LavndrVoid),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.fillMaxWidth()
                    ) {
                      if (isProcessingEnt) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = LavndrVoid, strokeWidth = 2.dp)
                      } else {
                        Text("تأكيد استلام شيك الضمان فعلياً", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                  else -> {
                    Text(text = "✓ مكتمل وتم التحويل", color = LavndrEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }
    }

    // 6. Audit Log
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "📋 سجل التدقيق (Audit Log)",
            color = LavndrGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(8.dp))

          auditLogs.take(6).forEach { log ->
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(text = log.action, color = LavndrText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = log.timestamp, color = LavndrTextFaint, fontSize = 9.sp)
              }
              Text(text = "${log.actor} • ${log.details}", color = LavndrTextDim, fontSize = 10.sp)
              Divider(color = LavndrGlassBorder, modifier = Modifier.padding(top = 4.dp))
            }
          }
        }
      }
    }
  }
}

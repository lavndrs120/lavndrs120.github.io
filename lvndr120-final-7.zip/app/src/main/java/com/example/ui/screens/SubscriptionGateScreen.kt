package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import com.example.data.model.BankInfo
import com.example.data.model.MySubscriptionItem
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FranchiseInfo
import com.example.data.model.SubscriptionAvailability
import com.example.data.model.TierAvailability
import com.example.data.model.SubscriptionStatus
import com.example.ui.theme.*

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close

// ✅ جديد: اسم الباقة بالعربي — بديل موحّد عن `tier == "lava" ? أ : ب` المتكرر
private fun tierNameAr(tier: String?): String = when (tier) {
  "lava" -> "لافا (24 ساعة)"
  "annual" -> "الباقة السنوية (12 شهر)"
  "fendex" -> "ڤندكس — Lavenders Oracle"
  "magma" -> "ماقما"
  "oms_services" -> "OMS — براند خدمات"
  "oms_products" -> "OMS — براند منتجات"
  "oms_vip" -> "OMS VIP"
  "reseller" -> "RESELLER"
  "franchise" -> "FRANCHISE (دفعة الحجز)"
  "franchise_installment" -> "FRANCHISE — دفعة"
  "tycoon" -> "TYCOON"
  else -> tier ?: ""
}

// ✅ جديد: بوابة الاشتراك — تظهر كمودال اختياري أو عند طلب الاشتراك
@Composable
fun SubscriptionGateScreen(
  subscriptionStatus: SubscriptionStatus,
  userEmail: String? = null,
  onSubscribe: (tier: String, country: String, onError: (String) -> Unit) -> Unit,
  onPayFranchise: (onError: (String) -> Unit) -> Unit = {},
  onSubmitOtp: (otp: String, txnRef: String) -> Unit,
  onRefreshStatus: () -> Unit,
  onDismiss: (() -> Unit)? = null,
  mySubscriptions: List<MySubscriptionItem> = emptyList(),
  onSelectSubscription: (tier: String?, country: String?) -> Unit = { _, _ -> },
  onPrepay: (tier: String, country: String, onError: (String) -> Unit) -> Unit = { _, _, _ -> },
  modifier: Modifier = Modifier
) {
  // أكثر من اشتراك: تظهر نافذة اختيار مرة واحدة لكل فتح، ويمكن العودة لها بزر "اشتراكاتي"
  var chooserOpen by rememberSaveable { mutableStateOf(mySubscriptions.size >= 2) }
  var chooserHandled by rememberSaveable { mutableStateOf(false) }
  LaunchedEffect(mySubscriptions.size) {
    if (mySubscriptions.size >= 2 && !chooserHandled) chooserOpen = true
  }
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(LavndrVoid)
      .verticalScroll(rememberScrollState())
      .padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    if (onDismiss != null) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = LavndrTextDim)
        }
      }
    } else {
      Spacer(modifier = Modifier.height(20.dp))
    }
    Text(
      text = "LAVNDR120",
      color = LavndrGold,
      fontWeight = FontWeight.Black,
      fontSize = 28.sp,
      letterSpacing = 2.sp
    )
    Text(
      text = "المؤشر الاستهلاكي",
      color = LavndrTextDim,
      fontSize = 11.sp,
      letterSpacing = 3.sp,
      modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
    )

    if (chooserOpen && mySubscriptions.size >= 2) {
      SubscriptionChooser(mySubscriptions) { item ->
        chooserHandled = true
        chooserOpen = false
        onSelectSubscription(item.tier, item.country)
      }
    } else {
    if (mySubscriptions.size >= 2) {
      TextButton(onClick = { chooserOpen = true }) {
        Text("اشتراكاتي (${mySubscriptions.size})", color = LavndrGold, fontSize = 12.sp)
      }
    }
    when (subscriptionStatus.stage) {
      "awaiting_otp" -> AwaitingOtpSection(subscriptionStatus, userEmail, onSubmitOtp)
      "awaiting_review" -> AwaitingReviewSection(onRefreshStatus)
      "waitlisted" ->
        if (subscriptionStatus.category == "movement") PreSubscribedSection(subscriptionStatus, userEmail, onRefreshStatus)
        else WaitlistedSection(subscriptionStatus, onRefreshStatus, onPrepay)
      "franchise" -> subscriptionStatus.franchise?.let { FranchiseSection(it, onPayFranchise) }
      "active" ->
        if (subscriptionStatus.tier in listOf("reseller", "tycoon", "oms_services", "oms_products", "oms_vip"))
          MembershipActiveSection(subscriptionStatus, userEmail)
        else PickerSection(subscriptionStatus, onSubscribe, true)
      else -> PickerSection(subscriptionStatus, onSubscribe, true)
    }
    }
  }
}

private fun stageNameAr(stage: String): String = when (stage) {
  "active" -> "نشط ✓"
  "waitlisted" -> "في قائمة الانتظار"
  "awaiting_otp" -> "بانتظار إتمام الدفع"
  "awaiting_review" -> "قيد المراجعة"
  "franchise" -> "دفعات الفرانشايز"
  else -> stage
}

// نافذة اختيار الاشتراك — لمن لديه أكثر من باقة
@Composable
private fun SubscriptionChooser(items: List<MySubscriptionItem>, onPick: (MySubscriptionItem) -> Unit) {
  Text("اشتراكاتك", color = LavndrGold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
  Text(
    "اختر الاشتراك الذي تريد متابعته",
    color = LavndrTextDim, fontSize = 12.sp,
    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
  )
  items.forEach { item ->
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 10.dp)
        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
        .border(BorderStroke(1.dp, LavndrGlassBorder), RoundedCornerShape(12.dp))
        .clickable { onPick(item) }
        .padding(14.dp)
    ) {
      Text(item.tierName ?: tierNameAr(item.tier), color = LavndrText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
      Text(stageNameAr(item.stage), color = LavndrGold, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
      if (!item.endDate.isNullOrBlank()) {
        Text("ينتهي: ${item.endDate}", color = LavndrTextFaint, fontSize = 11.sp)
      }
    }
  }
}

// ══════════════════════════════════════════════════════════════
// LAVENDERS — مسارا الاشتراك: Join Up LAVENDERS + Join the Economic Movement
// خطوات منفصلة عمدًا: مسارات ← بطاقات (رغبة) ← تفاصيل ← دفع (OTP) ← تأكيد.
// ══════════════════════════════════════════════════════════════
private const val WHATSAPP_NUMBER = "249914985264"
private const val REFUND_DAYS = 21

private data class OfferVariant(val tier: String, val label: String, val price: String, val period: String, val note: String? = null)

private data class GateOffer(
  val key: String,
  val path: String,                 // "joinup" | "movement"
  val icon: String,
  val title: String,
  val eyebrow: String,
  val short: String,
  val body: String,
  val variants: List<OfferVariant>,
  val cta: String,
  val gradient: List<Color>,
  val border: List<Color>,
  val accent: Color,
  val needsCountry: Boolean = false
)

private val GateOffers: List<GateOffer> = listOf(
  GateOffer(
    key = "oms", path = "movement", icon = "📲", title = "OMS", eyebrow = "للبزنسات والبراندات فقط",
    short = "نظام إدارة الطلبات — خليك لاصق في هواتف عملائك بلمسة.",
    body = "ما الذي يحدث لما تمحو المسافات؟\n• تمحو الفجوة\n• تمحو الزمن\n— بلمسة.\n\nنظام إدارة الطلبات OMS يعمل من الويب وعلى أندرويد لتبقى ملتصقًا في هواتف المستفيدين من خدمتك أو منتجك.",
    variants = listOf(
      OfferVariant("oms_services", "براند خدمات", "429", "اشتراك"),
      OfferVariant("oms_products", "براند منتجات", "492", "اشتراك"),
      OfferVariant("oms_vip", "OMS VIP", "942", "اشتراك",
        "لبراند منتجات أو خدمات. القيمة مقسّمة إلى جزأين: قيمة التطبيق \$429 + مقعد المشارك \$513.")
    ),
    cta = "ابدأ اشتراك OMS",
    gradient = listOf(Color(0xFF08202A), Color(0xFF050F14)),
    border = listOf(Color(0xFF2DD4BF), Color(0xFF0F4C5C), Color(0xFF2DD4BF)),
    accent = Color(0xFF99F6E4)
  ),
  GateOffer(
    key = "lava", path = "joinup", icon = "🌋", title = "لاڤا", eyebrow = "داتا السوق",
    short = "لاڤا هي داتا السوق نفسها — مش لازم تكون من الـ120.",
    body = "ماذا لو ما بقيت تشوف السوق من الخارج بس؟\nلاڤندرز بدأت بـ120 بزنس وبراند، ولما اجتمعت الطلبات ظهر سوق له حركة ومؤشر استهلاكي وداتا بتتكوّن مع كل حركة. سمّينا الداتا دي لاڤا.\n\nلاڤا مش تقرير بتقرأه، ولا أرقام بتتفرج عليها — لاڤا هي داتا السوق. الـ120 بيكوّنوا السوق، وإنت تقدر تدخل وتستخدم اللاڤا.\n(للمطالعة فقط.)",
    variants = listOf(
      OfferVariant("lava", "يوم واحد", "1.4", "/ يوم"),
      OfferVariant("annual", "سنة كاملة", "249", "/ سنة")
    ),
    cta = "اشترك في لاڤا",
    gradient = listOf(Color(0xFF12121C), Color(0xFF0A0A12)),
    border = listOf(Color(0x66FFFFFF), Color(0x1AFFFFFF)),
    accent = Color(0xFFC9A84C)
  ),
  GateOffer(
    key = "fendex", path = "joinup", icon = "🔮", title = "ڤندكس", eyebrow = "LAVENDERS ORACLE — 120 ڤندر فقط",
    short = "احمِ اللاڤا بالامتلاك، وخذ تقرير الأوراكل التنبؤي.",
    body = "احمِ اللاڤا بالامتلاك، واحصل على تقرير الأوراكل التنبؤي.\nامتلك داتا تحليل السوق، واكشف سلوك المستهلك بعيدًا عن أيدي 1,000 مشترك.\nاحصل على تنبؤ السوق وسلوك المستهلك قبل أن يصبح ما تعرفه متاحًا للجميع.\n\nامتلك الأمس. افهم اليوم. واحتكر المستقبل.",
    variants = listOf(OfferVariant("fendex", "سنة كاملة", "1,287", "/ سنة")),
    cta = "إنضم للڤندكس",
    gradient = listOf(Color(0xFF1A1230), Color(0xFF0D0A1A)),
    border = listOf(Color(0xFFC9A84C), Color(0xFF6B21A8), Color(0xFFC9A84C)),
    accent = Color(0xFFF0D080)
  ),
  GateOffer(
    key = "magma", path = "joinup", icon = "🌋", title = "ماقما", eyebrow = "عضوية محدودة لـ500 فقط",
    short = "السوق مش اللي تعرفه — السوق هو اللي تقدر تختاره.",
    body = "لاڤندرز ما بدأت لتضيف لك متجرًا آخر — بدأت لتجمع لك السوق: 120 بزنس وبراند.\nبدل ما تكون مرتبط بما تعرفه بس، الآن عندك مجال أن تعرف أكثر، وترى أكثر، وتختار أكثر.\n\nبـ100\$ في السنة تفتح لنفسك بابًا إلى سوق كامل. المكان محدود، والفرصة ليست للجميع.",
    variants = listOf(OfferVariant("magma", "سنة كاملة", "100", "/ سنة")),
    cta = "ادخل ماقما",
    gradient = listOf(Color(0xFF2A1408), Color(0xFF170A05)),
    border = listOf(Color(0xFFF97316), Color(0xFF7C2D12), Color(0xFFF97316)),
    accent = Color(0xFFFDBA74)
  ),
  GateOffer(
    key = "reseller", path = "movement", icon = "🧩", title = "RESELLER", eyebrow = "38 مقعدًا فقط",
    short = "8 تطبيقات تقدمها لـ8 بزنسات مختلفة.",
    body = "أنت كـ Reseller ما بتبيع لعميل واحد — عندك 8 تطبيقات تقدر تقدمها لـ8 بزنسات مختلفة.\n\nقيمة التطبيق: \$169.35\nقيمة حزمة الـ8 تطبيقات: \$1,354.8\n\nتقدر تقدمها للمستهلكين بالقيمة التي تفضلها، بداية من:\n• \$440.3 لبراندات الخدمات\n• \$503.3 لبراندات المنتجات\n\nالمطلوب منك: تجيب البزنسات المناسبة وتقدم لها الحل. ونحن نوفر لك المنظومة الجاهزة للتشغيل.",
    variants = listOf(OfferVariant("reseller", "عضوية الريسيلر", "1,354.8", "8 تطبيقات")),
    cta = "ابدأ كـ Reseller",
    gradient = listOf(Color(0xFF07241A), Color(0xFF050F0B)),
    border = listOf(Color(0xFF34D399), Color(0xFFC9A84C), Color(0xFF34D399)),
    accent = Color(0xFF6EE7B7)
  ),
  GateOffer(
    key = "franchise", path = "movement", icon = "🏛️", title = "FRANCHISE", eyebrow = "19 صاحب امتياز فقط",
    short = "ابنِ سوقك الخاص من 120 بزنس وبراند.",
    body = "مع امتياز لاڤندرز بتبني سوقك الخاص من 120 بزنس وبراند، كل بزنس عنده تطبيق طلبات خاص به، والـ120 تطبيق مربوطين داخل مؤشر سوق واحد.\n\nنوفر لك: ✓ منظومة كاملة جاهزة للتشغيل ✓ تدريب عملي ✓ دعم فني وتشغيلي مستمر\n\nقيمة امتلاك المنظومة \$2,709 — ولتسهيل بناء سوقك لا تدفعها دفعة واحدة. تبدأ بحجز \$90، ثم تكمل بدفعات حسب تقدّم بناء سوقك (\$22.58 لكل بزنس وبراند). تقدر تقدمها للمستهلكين بالقيمة التي تفضلها بداية من \$452 لبراندات الخدمات و\$515 لبراندات المنتجات.",
    variants = listOf(OfferVariant("franchise", "ابدأ بحجز \$90", "2,709", "إجمالي (دفعات)")),
    cta = "احجز امتيازك",
    gradient = listOf(Color(0xFF07241A), Color(0xFF050F0B)),
    border = listOf(Color(0xFF34D399), Color(0xFFC9A84C), Color(0xFF34D399)),
    accent = Color(0xFF6EE7B7)
  ),
  GateOffer(
    key = "tycoon", path = "movement", icon = "👑", title = "TYCOON", eyebrow = "تايكون واحد لكل دولة",
    short = "قُد 20 سوقًا حيًّا في دولتك.",
    body = "امتلك وكالة لاڤندرز لتقود الرحلة إلى خير الوجود.\nبقيمة \$51,480 فقط تسمح لـ2,400 بزنس وبراند أن ينتظموا في سوق موحد — 20 سوقًا، في كل سوق 120 بزنس وبراند — وتشوف حركة السوق قدامك لحظة بلحظة.\n\nتايكون واحد لكل دولة. ومن التأسيس وحتى استقرار النظام السنوي، تحصد ما يصل إلى 10 أضعاف قيمة الوكالة — نعم، حتى \$514,800.",
    variants = listOf(OfferVariant("tycoon", "تايكون الدولة", "51,480", "وكالة")),
    cta = "كن تايكون دولتك",
    gradient = listOf(Color(0xFF1A1230), Color(0xFF0D0A1A)),
    border = listOf(Color(0xFFC9A84C), Color(0xFF6B21A8), Color(0xFFC9A84C)),
    accent = Color(0xFFF0D080),
    needsCountry = true
  )
)

private fun availabilityFor(av: SubscriptionAvailability?, tier: String): TierAvailability? = when (tier) {
  "lava" -> av?.lava
  "annual" -> av?.annual
  "fendex" -> av?.fendex
  "magma" -> av?.magma
  "oms_services" -> av?.omsServices
  "oms_products" -> av?.omsProducts
  "oms_vip" -> av?.omsVip
  "reseller" -> av?.reseller
  "franchise" -> av?.franchise
  "tycoon" -> av?.tycoon
  else -> null
}

private fun preSubscriptionWhatsAppUrl(tier: String, email: String?, country: String?): String {
  val name = GateOffers.firstOrNull { o -> o.variants.any { it.tier == tier } }?.title ?: tier
  val lines = mutableListOf(
    "مرحبًا، أنا مهتم بالانضمام إلى «الحركة الاقتصادية» في LAVENDERS.",
    "Hello, I am interested in joining the LAVENDERS Economic Movement.",
    "",
    "العضوية / Membership: $name",
    "حالة الاشتراك / Status: Pre-subscription (ما قبل الاشتراك)"
  )
  if (!email.isNullOrBlank()) lines.add("البريد / Email: $email")
  if (!country.isNullOrBlank()) lines.add("الدولة / Country: $country")
  lines.add("")
  lines.add("أرغب في الحصول على الإجراءات المطلوبة لإكمال اشتراكي.")
  lines.add("I would like to receive the procedures required to complete my subscription.")
  return "https://wa.me/$WHATSAPP_NUMBER?text=" + java.net.URLEncoder.encode(lines.joinToString("\n"), "UTF-8").replace("+", "%20")
}

private fun helpWhatsAppUrl(tier: String?, email: String?): String {
  val txt = "مرحبًا، أحتاج مساعدة بخصوص اشتراك ${tierNameAr(tier)}" + (if (!email.isNullOrBlank()) " ($email)" else "") + "."
  return "https://wa.me/$WHATSAPP_NUMBER?text=" + java.net.URLEncoder.encode(txt, "UTF-8").replace("+", "%20")
}

// ✅ UX: مؤشر خطوات ثابت (اختر ← التفاصيل ← الدفع ← التأكيد)
@Composable
private fun GateSteps(active: Int) {
  val labels = listOf("اختر", "التفاصيل", "الدفع", "التأكيد")
  Row(
    modifier = Modifier.fillMaxWidth().padding(bottom = 22.dp),
    horizontalArrangement = Arrangement.Center,
    verticalAlignment = Alignment.CenterVertically
  ) {
    labels.forEachIndexed { i, label ->
      val n = i + 1
      val on = n == active
      val done = n < active
      Box(
        modifier = Modifier.size(22.dp).clip(RoundedCornerShape(100.dp)).background(
          when { on -> LavndrGold; done -> LavndrGold.copy(alpha = 0.25f); else -> Color.White.copy(alpha = 0.07f) }
        ),
        contentAlignment = Alignment.Center
      ) {
        Text(if (done) "✓" else "$n", color = if (on) LavndrVoid else if (done) LavndrGold else LavndrTextFaint, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
      }
      Text(label, color = if (on) LavndrText else LavndrTextFaint, fontSize = 10.5.sp,
        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(horizontal = 4.dp))
      if (n < 4) Box(modifier = Modifier.width(12.dp).height(1.dp).background(Color.White.copy(alpha = 0.12f)))
    }
  }
}

// صف بيان بنكي مع زر نسخ
@Composable
private fun BankRow(label: String, value: String?) {
  if (value.isNullOrBlank()) return
  val clipboard = LocalClipboardManager.current
  var copied by remember { mutableStateOf(false) }
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    OutlinedButton(
      onClick = { clipboard.setText(AnnotatedString(value)); copied = true },
      shape = RoundedCornerShape(8.dp),
      border = BorderStroke(1.dp, LavndrGlassBorder),
      contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
    ) { Text(if (copied) "تم النسخ ✓" else "نسخ", color = LavndrTextDim, fontSize = 11.sp) }
    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f).padding(start = 8.dp)) {
      Text(label, color = LavndrTextFaint, fontSize = 10.sp)
      Text(value, color = LavndrText, fontSize = 13.sp)
    }
  }
}

@Composable
private fun BankCard(bank: BankInfo) {
  Column(
    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
      .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(14.dp))
      .border(1.dp, LavndrGlassBorder, RoundedCornerShape(14.dp))
      .padding(horizontal = 14.dp, vertical = 6.dp)
  ) {
    BankRow("البنك", bank.bankName)
    BankRow("اسم صاحب الحساب", bank.accountHolder)
    BankRow("رقم الحساب", bank.accountNumber)
    BankRow("IBAN", bank.iban)
    BankRow("الفرع", bank.branch)
    Text(
      "القيمة بالدولار، والتحويل الفعلي بالجنيه السوداني (SDG) بما يعادلها يوم التحويل.",
      color = LavndrTextFaint, fontSize = 10.5.sp, lineHeight = 16.sp, modifier = Modifier.padding(vertical = 8.dp)
    )
  }
}

@Composable
private fun RefundNote() {
  Text(
    text = "↩︎ استرداد نقدي: يمكنك طلب استرداد مبلغك خلال $REFUND_DAYS يومًا (3 أسابيع) وفق إجراءات الاسترداد المعتمدة.",
    color = LavndrTextFaint,
    fontSize = 10.5.sp,
    lineHeight = 16.sp,
    textAlign = TextAlign.Center,
    modifier = Modifier.padding(top = 10.dp)
  )
}

@Composable
private fun PickerSection(
  status: SubscriptionStatus,
  onSubscribe: (tier: String, country: String, onError: (String) -> Unit) -> Unit,
  isLoggedIn: Boolean
) {
  val av = status.availability
  val marketComplete = status.marketComplete ?: false
  // الشاشة الحالية: null = المسارات | "joinup"/"movement" = بطاقات المسار | مفتاح عرض = تفاصيل
  var path by rememberSaveable { mutableStateOf<String?>(null) }
  var offerKey by rememberSaveable { mutableStateOf<String?>(null) }
  var variantTier by rememberSaveable { mutableStateOf<String?>(null) }

  val offer = GateOffers.firstOrNull { it.key == offerKey }
  when {
    offer != null -> OfferDetails(
      offer = offer, variantTier = variantTier, av = av, preSubscription = offer.path == "movement" && !marketComplete,
      onVariant = { variantTier = it },
      onBack = { offerKey = null; variantTier = null },
      onSubscribe = onSubscribe
    )
    path != null -> PathCards(
      pathKey = path!!, av = av, marketComplete = marketComplete,
      onOpen = { key -> offerKey = key; variantTier = null },
      onBack = { path = null }
    )
    else -> PathHub(onOpen = { path = it })
  }
}

@Composable
private fun PathHub(onOpen: (String) -> Unit) {
  GateSteps(1)
  Text(
    text = "LAVENDERS منظومة واحدة. اختر كيف تريد أن تكون جزءًا منها:",
    color = LavndrTextDim, fontSize = 13.sp, textAlign = TextAlign.Center,
    modifier = Modifier.padding(bottom = 6.dp)
  )
  Text(
    text = "Join Up = دخول إلى السوق وبياناته وأدواته  ·  الحركة الاقتصادية = المشاركة في بناء السوق",
    color = LavndrTextFaint, fontSize = 11.sp, textAlign = TextAlign.Center,
    modifier = Modifier.padding(bottom = 20.dp)
  )
  PathTile(
    icon = "🔗", title = "Join Up LAVENDERS",
    sub = "ادخل السوق: بيانات، ذكاء، وأدوات الأعمال.",
    border = listOf(Color(0x66FFFFFF), Color(0x1AFFFFFF)), gradient = listOf(Color(0xFF12121C), Color(0xFF0A0A12)),
    accent = LavndrGold, onClick = { onOpen("joinup") }
  )
  Spacer(modifier = Modifier.height(16.dp))
  PathTile(
    icon = "🌍", title = "Join the Economic Movement",
    sub = "شارك في بناء السوق. أنت لا تشتري منتجًا — أنت تنضم إلى حركة تبني سوقًا.",
    border = listOf(Color(0xFF34D399), Color(0xFFC9A84C), Color(0xFF34D399)), gradient = listOf(Color(0xFF07241A), Color(0xFF050F0B)),
    accent = Color(0xFF6EE7B7), onClick = { onOpen("movement") }
  )
}

@Composable
private fun PathTile(icon: String, title: String, sub: String, border: List<Color>, gradient: List<Color>, accent: Color, onClick: () -> Unit) {
  Box(
    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
      .background(Brush.linearGradient(border)).padding(2.dp)
      .clickable(onClick = onClick)
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
        .background(Brush.verticalGradient(gradient)).padding(20.dp)
    ) {
      Text(icon, fontSize = 30.sp)
      Spacer(modifier = Modifier.height(6.dp))
      Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
      Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 12.5.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 6.dp))
      Text("استكشف ←", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
    }
  }
}

@Composable
private fun PathCards(pathKey: String, av: SubscriptionAvailability?, marketComplete: Boolean, onOpen: (String) -> Unit, onBack: () -> Unit) {
  val isMovement = pathKey == "movement"
  GateSteps(1)
  TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("← المسارات", color = LavndrTextDim, fontSize = 12.sp) }
  Text(
    text = if (isMovement) "Join the Economic Movement" else "Join Up LAVENDERS",
    color = LavndrGold, fontSize = 18.sp, fontWeight = FontWeight.Black
  )
  Text(
    text = if (isMovement) "شارك في بناء السوق." else "ادخل السوق: بيانات، ذكاء، وأدوات الأعمال.",
    color = LavndrTextDim, fontSize = 12.5.sp, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
  )
  GateOffers.filter { it.path == pathKey }.forEach { o ->
    val first = o.variants.first()
    val t = availabilityFor(av, first.tier)
    val rem = t?.remaining
    val max = t?.max
    val available = t?.available ?: true
    Box(
      modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
        .background(Brush.linearGradient(o.border)).padding(2.dp)
        .clickable { onOpen(o.key) }
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
          .background(Brush.verticalGradient(o.gradient)).padding(18.dp)
      ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(o.eyebrow, color = o.accent, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text("${o.icon} ${o.title}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
          }
          Text("$" + o.variants.joinToString(" / ") { it.price }, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
        }
        Text(o.short, color = Color.White.copy(alpha = 0.85f), fontSize = 12.5.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp))
        if (rem != null && max != null && available) {
          Surface(
            color = LavndrRed.copy(alpha = 0.18f), shape = RoundedCornerShape(100.dp),
            border = BorderStroke(1.dp, LavndrRed.copy(alpha = 0.4f)), modifier = Modifier.padding(top = 8.dp)
          ) {
            Text("🔥 باقي $rem مكان من $max", color = Color(0xFFFCA5A5), fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
          }
        }
        Text("التفاصيل ←", color = o.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
      }
    }
    Spacer(modifier = Modifier.height(14.dp))
  }
  if (isMovement) {
    if (!marketComplete) {
      Text("السوق قيد البناء حاليًا — الانضمام الآن يتم بنظام «ما قبل الاشتراك».", color = LavndrTextFaint, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
  }
}

@Composable
private fun OfferDetails(
  offer: GateOffer, variantTier: String?, av: SubscriptionAvailability?, preSubscription: Boolean,
  onVariant: (String) -> Unit, onBack: () -> Unit,
  onSubscribe: (tier: String, country: String, onError: (String) -> Unit) -> Unit
) {
  val sel = offer.variants.firstOrNull { it.tier == variantTier } ?: offer.variants.first()
  val t = availabilityFor(av, sel.tier)
  val available = t?.available ?: true
  val rem = t?.remaining
  val max = t?.max
  var country by rememberSaveable { mutableStateOf("") }
  var error by remember { mutableStateOf<String?>(null) }
  var sending by remember { mutableStateOf(false) }

  GateSteps(2)
  TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
    Text(if (offer.path == "movement") "← Join the Economic Movement" else "← Join Up LAVENDERS", color = LavndrTextDim, fontSize = 12.sp)
  }
  Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(offer.border)).padding(2.dp)) {
    Column(
      modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
        .background(Brush.verticalGradient(offer.gradient)).padding(20.dp)
    ) {
      Text(offer.eyebrow, color = offer.accent, fontSize = 10.sp, letterSpacing = 1.5.sp)
      Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Text("${offer.icon} ${offer.title}", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
        Column(horizontalAlignment = Alignment.End) {
          Text("$" + sel.price, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
          Text(sel.period, color = offer.accent, fontSize = 10.sp)
        }
      }
      if (offer.variants.size > 1) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          offer.variants.forEach { v ->
            val on = v.tier == sel.tier
            OutlinedButton(
              onClick = { onVariant(v.tier) },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, if (on) offer.accent else LavndrGlassBorder),
              colors = ButtonDefaults.outlinedButtonColors(containerColor = if (on) Color.White.copy(alpha = 0.08f) else Color.Transparent)
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(v.label, color = if (on) Color.White else LavndrTextDim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("$" + v.price, color = if (on) Color.White else LavndrTextDim, fontSize = 14.sp, fontWeight = FontWeight.Black)
              }
            }
          }
        }
      }
      sel.note?.let { Text(it, color = offer.accent, fontSize = 11.5.sp, lineHeight = 18.sp, modifier = Modifier.padding(vertical = 4.dp)) }
      if (sel.tier == "oms_vip") {
        Column(
          modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp)).padding(12.dp)
        ) {
          Text("تفصيل قيمة OMS VIP — \$942", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          Text("• قيمة التطبيق: \$429", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
          Text("• مقعد المشارك: \$513", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
        }
      }
      Text(offer.body, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, lineHeight = 22.sp, modifier = Modifier.padding(vertical = 12.dp))
      if (rem != null && max != null && available) {
        Surface(
          color = LavndrRed.copy(alpha = 0.18f), shape = RoundedCornerShape(100.dp),
          border = BorderStroke(1.dp, LavndrRed.copy(alpha = 0.4f))
        ) {
          Text("🔥 باقي $rem مكان من $max", color = Color(0xFFFCA5A5), fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
        }
      }
      if (offer.needsCountry) {
        OutlinedTextField(
          value = country, onValueChange = { country = it.take(60) },
          placeholder = { Text("الدولة (مطلوب — تايكون واحد لكل دولة)") },
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = offer.accent, unfocusedBorderColor = LavndrGlassBorder,
            focusedTextColor = LavndrText, unfocusedTextColor = LavndrText
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        )
      }
      Button(
        onClick = {
          error = null; sending = true
          onSubscribe(sel.tier, country.trim()) { msg -> error = msg; sending = false }
        },
        enabled = available && !sending && (!offer.needsCountry || country.trim().length >= 2),
        colors = ButtonDefaults.buttonColors(
          containerColor = offer.accent, contentColor = offer.gradient.first(),
          disabledContainerColor = Color.White.copy(alpha = 0.08f), disabledContentColor = LavndrTextFaint
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
      ) {
        Text(
          text = when {
            !available -> "🔒 اكتملت العضوية — مفيش أماكن حاليًا"
            preSubscription -> "ما قبل الاشتراك — احجز مكانك"
            else -> offer.cta
          },
          fontWeight = FontWeight.Black
        )
      }
      if (preSubscription && available) {
        Text(
          "السوق ما زال قيد البناء — طلبك يُسجَّل كـ«ما قبل اشتراك»، ثم نكمل معك إجراءات الاشتراك عبر واتساب.",
          color = Color.White.copy(alpha = 0.8f), fontSize = 11.5.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 10.dp)
        )
      }
      error?.let { Text(it, color = LavndrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
      RefundNote()
    }
  }
}

// ✅ ما قبل الاشتراك (الحركة الاقتصادية): الطلب اتحفظ ← واتساب برسالة جاهزة تحدد العضوية
@Composable
private fun PreSubscribedSection(status: SubscriptionStatus, userEmail: String?, onRefreshStatus: () -> Unit) {
  val uriHandler = LocalUriHandler.current
  val ready = status.readyCount ?: 0
  val target = status.targetCount ?: 120
  val progress = if (target > 0) (ready.toFloat() / target.toFloat()).coerceIn(0f, 1f) else 0f
  val tier = status.tier ?: ""
  Text(text = "✅", fontSize = 40.sp)
  Spacer(modifier = Modifier.height(12.dp))
  Text(
    text = "تم تسجيل طلب «ما قبل الاشتراك» — ${tierNameAr(status.tier)}",
    color = Color(0xFF6EE7B7), fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
  )
  Text(
    text = "طلبك محفوظ. الخطوة التالية: أكمل الإجراءات معنا عبر واتساب — الرسالة جاهزة وتتضمن العضوية التي اخترتها.",
    color = LavndrTextDim, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 19.sp,
    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
  )
  Button(
    onClick = { uriHandler.openUri(preSubscriptionWhatsAppUrl(tier, userEmail, status.country)) },
    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366), contentColor = Color(0xFF04210F)),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) { Text("متابعة عبر واتساب", fontWeight = FontWeight.Black, fontSize = 15.sp) }
  Spacer(modifier = Modifier.height(14.dp))
  Column(
    modifier = Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp)).padding(12.dp)
  ) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("تقدّم بناء السوق", color = LavndrTextFaint, fontSize = 11.sp)
      Text("$ready / $target", color = LavndrTextFaint, fontSize = 11.sp)
    }
    Spacer(modifier = Modifier.height(6.dp))
    LinearProgressIndicator(
      progress = { progress },
      modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(100.dp)),
      color = LavndrGold, trackColor = LavndrGlassBorder
    )
  }
  Text("عند اكتمال السوق ينتقل الاشتراك تلقائيًا إلى الدفع المباشر.", color = LavndrTextFaint, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
  RefundNote()
  Spacer(modifier = Modifier.height(10.dp))
  OutlinedButton(onClick = onRefreshStatus) { Text("تحقق تاني", color = LavndrTextDim) }
}

// ✅ شاشة الفرانشايز الرقمية: أرقام + زر "ادفع" فقط (بدون مدخلات)
@Composable
private fun FranchiseSection(fr: FranchiseInfo, onPay: (onError: (String) -> Unit) -> Unit) {
  var error by remember { mutableStateOf<String?>(null) }
  val progress = if (fr.totalUsd > 0) (fr.paidUsd / fr.totalUsd).toFloat().coerceIn(0f, 1f) else 0f
  val done = fr.status == "completed"
  Text("🏛️ FRANCHISE", color = Color(0xFF6EE7B7), fontSize = 11.sp, letterSpacing = 2.sp)
  Text("امتياز لاڤندرز", color = LavndrText, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    Column(modifier = Modifier.weight(1f).background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)).padding(12.dp)) {
      Text("المدفوع", color = LavndrTextFaint, fontSize = 10.sp)
      Text("$" + fr.paidUsd.toString().removeSuffix(".0"), color = Color(0xFF6EE7B7), fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
    Column(modifier = Modifier.weight(1f).background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)).padding(12.dp)) {
      Text("المتبقي", color = LavndrTextFaint, fontSize = 10.sp)
      Text("$" + fr.remainingUsd.toString().removeSuffix(".0"), color = LavndrGold, fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
  }
  Spacer(modifier = Modifier.height(14.dp))
  Column(modifier = Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp)).padding(12.dp)) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("المقاعد المدفوعة", color = LavndrTextFaint, fontSize = 11.sp)
      Text("${fr.seatsPaid} / ${fr.totalSeats}", color = LavndrTextFaint, fontSize = 11.sp)
    }
    Spacer(modifier = Modifier.height(6.dp))
    LinearProgressIndicator(
      progress = { progress },
      modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(100.dp)),
      color = Color(0xFF34D399), trackColor = LavndrGlassBorder
    )
  }
  Spacer(modifier = Modifier.height(16.dp))
  if (done) {
    Text("اكتمل الدفع ✓", color = Color(0xFF6EE7B7), fontSize = 14.sp)
  } else {
    Button(
      onClick = { error = null; onPay { msg -> error = msg } },
      colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6EE7B7), contentColor = Color(0xFF07241A)),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) { Text("ادفع $" + fr.nextAmountUsd.toString().removeSuffix(".0"), fontWeight = FontWeight.Black, fontSize = 16.sp) }
  }
  error?.let { Text(it, color = LavndrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
  RefundNote()
}

@Composable
private fun MembershipActiveSection(status: SubscriptionStatus, userEmail: String?) {
  val uriHandler = LocalUriHandler.current
  Text("✅", fontSize = 40.sp)
  Spacer(modifier = Modifier.height(12.dp))
  Text("عضويتك مفعّلة — ${tierNameAr(status.tier)}", color = LavndrGold, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
  Text("شكرًا لانضمامك. سنوافيك بالخطوات التالية عبر البريد/واتساب.", color = LavndrTextDim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
  TextButton(onClick = { uriHandler.openUri(helpWhatsAppUrl(status.tier, userEmail)) }) {
    Text("تحتاج مساعدة؟", color = LavndrTextFaint, fontSize = 12.sp)
  }
}

@Composable
private fun AwaitingOtpSection(
  status: SubscriptionStatus,
  userEmail: String?,
  onSubmitOtp: (otp: String, txnRef: String) -> Unit
) {
  val uriHandler = LocalUriHandler.current
  var otp by remember { mutableStateOf("") }
  var txnRef by remember { mutableStateOf("") }
  val tierName = tierNameAr(status.tier)

  GateSteps(3)
  Text(
    text = tierName,
    color = LavndrGold,
    fontSize = 15.sp,
    fontWeight = FontWeight.ExtraBold,
    modifier = Modifier.padding(bottom = 4.dp)
  )
  Text(
    text = "$" + (status.amount?.toString()?.removeSuffix(".0") ?: ""),
    color = LavndrText,
    fontSize = 26.sp,
    fontWeight = FontWeight.Black,
    modifier = Modifier.padding(bottom = 14.dp)
  )
  Text(
    text = "١. حوّل المبلغ إلى الحساب أدناه.\n٢. أرسلنا رمز التحقق إلى إيميلك — أدخله مع رقم/مرجع المعاملة من إشعار البنك.",
    color = LavndrTextDim,
    fontSize = 12.sp,
    lineHeight = 20.sp,
    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
  )
  status.bank?.let { BankCard(it) }

  OutlinedTextField(
    value = otp,
    onValueChange = { otp = it },
    placeholder = { Text("رمز التحقق (من الإيميل)") },
    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    singleLine = true,
    colors = OutlinedTextFieldDefaults.colors(
      focusedBorderColor = LavndrGold,
      unfocusedBorderColor = LavndrGlassBorder,
      focusedTextColor = LavndrText,
      unfocusedTextColor = LavndrText
    ),
    shape = RoundedCornerShape(10.dp),
    modifier = Modifier.fillMaxWidth()
  )
  Spacer(modifier = Modifier.height(10.dp))
  OutlinedTextField(
    value = txnRef,
    onValueChange = { txnRef = it },
    placeholder = { Text("رقم/مرجع المعاملة البنكية") },
    colors = OutlinedTextFieldDefaults.colors(
      focusedBorderColor = LavndrGold,
      unfocusedBorderColor = LavndrGlassBorder,
      focusedTextColor = LavndrText,
      unfocusedTextColor = LavndrText
    ),
    shape = RoundedCornerShape(10.dp),
    modifier = Modifier.fillMaxWidth()
  )
  Spacer(modifier = Modifier.height(16.dp))
  Button(
    onClick = { onSubmitOtp(otp, txnRef) },
    enabled = otp.isNotBlank() && txnRef.isNotBlank(),
    colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
    shape = RoundedCornerShape(10.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Text("تأكيد الدفع", fontWeight = FontWeight.Bold)
  }
  RefundNote()
  // مساعدة ثانوية فقط — الاشتراك نفسه يبقى عبر هذا المسار المباشر وليس واتساب
  TextButton(onClick = { uriHandler.openUri(helpWhatsAppUrl(status.tier, userEmail)) }) {
    Text("تحتاج مساعدة؟", color = LavndrTextFaint, fontSize = 11.sp)
  }
}

@Composable
private fun AwaitingReviewSection(onRefreshStatus: () -> Unit) {
  GateSteps(4)
  Text(text = "⏳", fontSize = 40.sp)
  Spacer(modifier = Modifier.height(12.dp))
  Text(
    text = "وصلنا تأكيدك — نراجع التحويل الآن",
    color = LavndrGold,
    fontSize = 15.sp,
    fontWeight = FontWeight.Bold
  )
  Text(
    text = "يتفعّل اشتراكك تلقائيًا بعد اعتماد التحويل، وعادةً خلال ساعات قليلة. لا تحتاج لفعل أي شيء الآن — ويمكنك إغلاق هذه الصفحة والعودة لاحقًا.",
    color = LavndrTextDim,
    fontSize = 12.sp,
    textAlign = TextAlign.Center,
    modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
  )
  OutlinedButton(onClick = onRefreshStatus) {
    Text("تحقق من الحالة", color = LavndrTextDim)
  }
  RefundNote()
}

// ✅ جديد: قائمة الانتظار — السوق لسه في طور التكوين (أقل من 120 نشاط فعلي).
// رسالة خفيفة ومطمئنة، بدون أي إجراء مطلوب من المشترك، وشفافة بعرض التقدم
// الفعلي (كام نشاط جاهز من أصل الهدف) بدل "استنى" من غير أي سياق.
@Composable
private fun WaitlistedSection(
  status: SubscriptionStatus,
  onRefreshStatus: () -> Unit,
  onPrepay: (tier: String, country: String, onError: (String) -> Unit) -> Unit
) {
  var busy by remember { mutableStateOf(false) }
  var err by remember { mutableStateOf<String?>(null) }
  val ready = status.readyCount ?: 0
  val target = status.targetCount ?: 120
  val progress = if (target > 0) (ready.toFloat() / target.toFloat()).coerceIn(0f, 1f) else 0f
  Text(text = "📝", fontSize = 40.sp)
  Spacer(modifier = Modifier.height(12.dp))
  Text(
    text = "تم حفظ طلبك بنجاح ✓",
    color = LavndrGold,
    fontSize = 15.sp,
    fontWeight = FontWeight.Bold
  )
  Text(
    text = "السوق لسه في طور التكوين — إنت مسجّل في قائمة الانتظار لباقة ${tierNameAr(status.tier)}.\n" +
      "بمجرد ما نخلّص بناء المؤشر بالـ$target نشاط كامل، هنتواصل معاك فورًا لتكمّل اشتراكك وتستمتع بالباقة.",
    color = LavndrTextDim,
    fontSize = 12.sp,
    textAlign = TextAlign.Center,
    lineHeight = 18.sp,
    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
  )
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
      .padding(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("تقدّم بناء السوق", color = LavndrTextFaint, fontSize = 11.sp)
      Text("$ready / $target نشاط", color = LavndrTextFaint, fontSize = 11.sp)
    }
    Spacer(modifier = Modifier.height(6.dp))
    LinearProgressIndicator(
      progress = { progress },
      modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(100.dp)),
      color = LavndrGold,
      trackColor = LavndrGlassBorder
    )
  }
  Spacer(modifier = Modifier.height(16.dp))
  Text(
    "كن من الأوائل — ابدأ إجراءات الدفع الآن لتضمن مقعدك، وسيُفعَّل اشتراكك فور اكتمال السوق.",
    color = LavndrGold, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp,
    modifier = Modifier.padding(bottom = 10.dp)
  )
  Button(
    onClick = {
      busy = true; err = null
      onPrepay(status.tier ?: "", status.country ?: "") { m -> err = m; busy = false }
    },
    enabled = !busy && !status.tier.isNullOrBlank(),
    colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
    shape = RoundedCornerShape(10.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Text(if (busy) "جارٍ الإرسال..." else "اشترك الآن — تابع للدفع", fontWeight = FontWeight.Bold)
  }
  err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
  Spacer(modifier = Modifier.height(8.dp))
  OutlinedButton(onClick = onRefreshStatus) {
    Text("تحقق تاني", color = LavndrTextDim)
  }
}

// نافذة اختيار الاشتراك لمن له أكثر من اشتراك (تظهر بعد الدخول)
@Composable
fun SubscriptionChooserDialog(
  items: List<MySubscriptionItem>,
  onPick: (MySubscriptionItem) -> Unit,
  onDismiss: () -> Unit
) {
  androidx.compose.ui.window.Dialog(
    onDismissRequest = onDismiss,
    properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Column(
      modifier = Modifier.fillMaxSize().background(LavndrVoid).verticalScroll(rememberScrollState()).padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(40.dp))
      SubscriptionChooser(items, onPick)
    }
  }
}

package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusinessEntitlement
import com.example.data.model.BusinessItem
import com.example.data.model.BusinessPortalInfo
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun BusinessPortalScreen(
  portalInfo: BusinessPortalInfo,
  currentUserEmail: String,
  onToggleAutoAccept: (sheetId: String, enabled: Boolean) -> Unit,
  onSubmitAgreement: (sheetId: String, link: String) -> Unit = { _, _ -> },
  onRequestCash: (sheetId: String) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    item {
      OutlinedButton(
        onClick = { uriHandler.openUri("https://omssolutionorders-bit.github.io/agreement.pdf") },
        modifier = Modifier.fillMaxWidth()
      ) { Text("📄 اتفاقية «لاڤندرز لإدارة البزنسات» — تحميل PDF للتعبئة والتوقيع", color = LavndrGold, fontSize = 12.sp) }
    }
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "بورتال البزنس",
          color = LavndrGold,
          fontSize = 11.sp,
          letterSpacing = 4.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "إدارة النشاط التجاري والاستحقاقات",
          color = LavndrText,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "الحساب: $currentUserEmail",
          color = LavndrTextDim,
          fontSize = 11.sp
        )
      }
    }

    if (!portalInfo.linked || portalInfo.businesses.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(text = "🏪", fontSize = 36.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "حسابك غير مربوط بنشاط تجاري حالياً",
              color = LavndrText,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "تواصل مع الأدمن لربط إيميلك ($currentUserEmail) بالـ SheetID الخاص بنشاطك من لوحة التحكم.",
              color = LavndrTextDim,
              fontSize = 12.sp,
              textAlign = TextAlign.Center
            )
          }
        }
      }
    } else {
      items(portalInfo.businesses) { biz ->
        BusinessItemCard(
          biz = biz,
          onToggleAutoAccept = { enabled -> onToggleAutoAccept(biz.sheetId, enabled) },
          onSubmitAgreement = { link -> onSubmitAgreement(biz.sheetId, link) },
          onRequestCash = { onRequestCash(biz.sheetId) }
        )
      }
    }
  }
}

@Composable
private fun BusinessItemCard(
  biz: BusinessItem,
  onToggleAutoAccept: (Boolean) -> Unit,
  onSubmitAgreement: (String) -> Unit = {},
  onRequestCash: () -> Unit = {}
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = biz.name,
            color = LavndrGold,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${biz.ticker ?: biz.sheetId} ${if (biz.closed) "• (مغلق)" else ""}",
            color = if (biz.closed) LavndrRed else LavndrTextDim,
            fontSize = 11.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrVoid)
        ) {
          Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "${biz.orders}", color = LavndrGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(text = "إجمالي الطلبات", color = LavndrTextDim, fontSize = 10.sp)
          }
        }
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrVoid)
        ) {
          Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "${String.format(Locale.US, "%.2f", biz.weight)}%",
              color = LavndrEmerald,
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold
            )
            Text(text = "الوزن في المؤشر", color = LavndrTextDim, fontSize = 10.sp)
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Auto-Accept toggle
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = LavndrVoid)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(text = "القبول التلقائي للاستحقاقات", color = LavndrText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(
              text = "لو مفعل، أي استحقاق جديد ينتقل تلقائياً لمرحلة (بانتظار شيك الضمان)",
              color = LavndrTextDim,
              fontSize = 10.sp
            )
          }
          Switch(
            checked = biz.autoAccept,
            onCheckedChange = onToggleAutoAccept,
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = LavndrEmerald,
              uncheckedThumbColor = LavndrTextDim,
              uncheckedTrackColor = LavndrVoid
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
      RequestsSection(biz = biz, onSubmitAgreement = onSubmitAgreement, onRequestCash = onRequestCash)

      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = "سجل الاستحقاقات المالية",
        color = LavndrGold,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 8.dp)
      )

      if (biz.entitlements.isEmpty()) {
        Text(
          text = "لا توجد استحقاقات مسجلة بعد",
          color = LavndrTextFaint,
          fontSize = 11.sp,
          modifier = Modifier.padding(vertical = 8.dp)
        )
      } else {
        biz.entitlements.forEach { ent ->
          EntitlementRow(ent = ent)
          if (ent != biz.entitlements.last()) {
            Spacer(modifier = Modifier.height(6.dp))
          }
        }
      }
    }
  }
}

@Composable
private fun EntitlementRow(ent: BusinessEntitlement) {
  val (statusText, statusBg, statusColor) = when (ent.status) {
    "available" -> Triple("متاح — بانتظار تواصل الأدمن", LavndrAmberDim, LavndrAmber)
    "accepted_awaiting_guarantee" -> Triple("بانتظار استلام شيك الضمان", LavndrGoldDim, LavndrGold)
    "completed" -> Triple("✓ مكتمل وجاهز للتحويل", LavndrEmeraldDim, LavndrEmerald)
    else -> Triple(ent.status, LavndrGlassBorder, LavndrTextDim)
  }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = LavndrVoid)
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "$${String.format(Locale.US, "%.2f", ent.entitlement)}",
          color = LavndrText,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold
        )
        Surface(color = statusBg, shape = RoundedCornerShape(100.dp)) {
          Text(
            text = statusText,
            color = statusColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "${ent.date} • طلبات وقتها: ${ent.orders}",
        color = LavndrTextDim,
        fontSize = 10.sp
      )

      if (ent.status == "accepted_awaiting_guarantee") {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "شيك الضمان المطلوب: $${String.format(Locale.US, "%.2f", ent.guaranteeAmount)} = مساهمة $${ent.entitlement} + نمو $${ent.growthAmount} (36% × ${ent.orders} طلب × $4.275)",
          color = LavndrGold,
          fontSize = 10.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }
  }
}


@Composable
private fun RequestsSection(
  biz: BusinessItem,
  onSubmitAgreement: (String) -> Unit,
  onRequestCash: () -> Unit
) {
  val req = biz.requests
  var link by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf("") }
  val agText = when (req.agreement?.status) {
    "submitted" -> "الاتفاقية الموقعة: ⏳ قيد المراجعة"
    "received" -> "الاتفاقية الموقعة: ✅ تم الاستلام"
    "rejected" -> "الاتفاقية الموقعة: ❌ غير مقبولة — أعد الرفع"
    else -> "لم ترفع الاتفاقية الموقعة بعد"
  }
  Text("الاتفاقية والكاش التشغيلي", color = LavndrGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
  Text(
    "بياناتك تُقيَّم بنقاط المؤشر وتتحرك مع إجمالي الطلبات. طلب الكاش اختياري: تسدّد 36% من جملة طلباتك المعتمدة نقداً (الطلب = 4.275\$)، ويُصرف لك بعد اكتمال الأطواق الثلاثة: المالي والضماني والمستندي.",
    color = LavndrTextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
  )
  Text(agText, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
  if (!req.agreementReceived) {
    OutlinedTextField(
      value = link, onValueChange = { link = it },
      label = { Text("رابط الاتفاقية الموقعة (Drive)") },
      singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
    )
    OutlinedButton(
      onClick = { onSubmitAgreement(link.trim()); link = "" },
      enabled = link.trim().startsWith("https://"),
      modifier = Modifier.padding(top = 6.dp)
    ) { Text("رفع الرابط", color = LavndrGold) }
  }
  Text("سداد 36% الحالي: \$${String.format(Locale.US, "%.2f", req.m.due36)} لعدد ${req.m.orders} طلب", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
  OutlinedButton(onClick = onRequestCash, modifier = Modifier.padding(top = 6.dp)) {
    Text("طلب كاش تشغيلي من الصندوق", color = LavndrGold)
  }
  req.cash.forEach { c ->
    val st = when (c.status) { "pending" -> "⏳ بانتظار قرار الإدارة"; "approved" -> "✅ مقبول"; "rejected" -> "❌ غير مقبول"; else -> c.status }
    val amt = c.approvedAmount?.toString()?.takeIf { it.isNotBlank() }?.let { " — \$" + it } ?: ""
    val hint = if (c.status == "approved" && amt.isBlank()) " (تظهر القيمة بعد استلام اتفاقيتك الموقعة)" else ""
    Text("طلب كاش: $st$amt$hint", color = LavndrTextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
  }
}

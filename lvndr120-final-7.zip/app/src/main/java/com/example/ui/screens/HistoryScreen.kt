package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MonthlySnapshot
import com.example.ui.theme.*

@Composable
fun HistoryScreen(
  snapshots: List<MonthlySnapshot>,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "الأرشيف الشهري",
          color = LavndrGold,
          fontSize = 11.sp,
          letterSpacing = 4.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "لقطات الإغلاق (يوم 21)",
          color = LavndrText,
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "التقارير المعتمدة الموثقة شهرياً في يوم 21 لكل المشاركين",
          color = LavndrTextDim,
          fontSize = 11.sp,
          textAlign = TextAlign.Center
        )
      }
    }

    if (snapshots.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "لا توجد لقطات شهرية محفوظة بعد",
              color = LavndrTextFaint,
              fontSize = 13.sp
            )
          }
        }
      }
    } else {
      items(snapshots) { snap ->
        SnapshotCard(snap = snap)
      }
    }
  }
}

@Composable
private fun SnapshotCard(snap: MonthlySnapshot) {
  val premDouble = snap.premium.toDoubleOrNull() ?: 0.0
  val isPremPos = premDouble >= 0.0

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = LavndrSurfaceElevated)
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Column {
          Text(
            text = snap.month,
            color = LavndrGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
          )
          Text(
            text = "$${snap.NAV}",
            color = LavndrGold,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(text = "Premium / Discount", color = LavndrTextFaint, fontSize = 10.sp)
          Text(
            text = "${if (isPremPos) "+" else ""}${snap.premium}%",
            color = if (isPremPos) LavndrEmerald else LavndrRed,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "Top 5: ${snap.top5}",
        color = LavndrTextDim,
        fontSize = 11.sp
      )

      Spacer(modifier = Modifier.height(12.dp))
      Divider(color = LavndrGlassBorder)
      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "صافي الطلبات", color = LavndrTextFaint, fontSize = 10.sp)
          Text(text = "${snap.netOrders}", color = LavndrText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "الوحدات", color = LavndrTextFaint, fontSize = 10.sp)
          Text(text = "${snap.netUnits}", color = LavndrText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "المكونات", color = LavndrTextFaint, fontSize = 10.sp)
          Text(text = "${snap.components}", color = LavndrText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

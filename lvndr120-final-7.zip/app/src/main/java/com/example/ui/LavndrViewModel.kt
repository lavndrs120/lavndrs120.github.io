package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.alerts.PriceAlertConfig
import com.example.data.alerts.PriceAlertManager
import com.example.data.model.*
import com.example.data.repository.LavndrRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LavndrViewModel(application: Application) : AndroidViewModel(application) {
  private val repository = LavndrRepository(application.applicationContext)
  private val priceAlertManager = PriceAlertManager(application.applicationContext)
  private val _priceAlertConfig = MutableStateFlow(priceAlertManager.getAlertConfig())
  val priceAlertConfig: StateFlow<PriceAlertConfig> = _priceAlertConfig

  init {
    viewModelScope.launch {
      data.collect { d ->
        val nav = d.index.NAV.toDoubleOrNull() ?: 0.0
        if (nav > 0.0) {
          checkPriceAlerts(nav)
        }
      }
    }
  }

  fun savePriceAlert(config: PriceAlertConfig) {
    priceAlertManager.saveAlertConfig(config)
    _priceAlertConfig.value = config
  }

  fun checkPriceAlerts(currentNav: Double) {
    val notified = priceAlertManager.checkAndNotify(currentNav)
    if (notified) {
      _priceAlertConfig.value = priceAlertManager.getAlertConfig()
    }
  }

  // ─── الجلسة ───
  val isLoggedIn: StateFlow<Boolean> = repository.isLoggedIn
  val isSigningIn: StateFlow<Boolean> = repository.isSigningIn
  val loginErrorMessage: StateFlow<String?> = repository.loginErrorMessage
  val currentUserEmail: StateFlow<String> = repository.currentUserEmail
  val currentRole: StateFlow<UserRole> = repository.currentRole
  val termsText: StateFlow<String> = repository.termsText
  val bankDetails: StateFlow<BankDetails> = repository.bankDetails
  val lastActionError: StateFlow<String?> = repository.lastActionError

  // ─── البيانات الحية ───
  val data: StateFlow<LavndrData> = repository.data
  val participantInfo: StateFlow<ParticipantInfo?> = repository.participantInfo
  val businessPortal: StateFlow<BusinessPortalInfo> = repository.businessPortal
  val subscriptionStatus: StateFlow<SubscriptionStatus> = repository.subscriptionStatus
  val needsSubscription: StateFlow<Boolean> = repository.needsSubscription
  val mySubscriptions: StateFlow<List<com.example.data.model.MySubscriptionItem>> = repository.mySubscriptions
  val selectedMonth: StateFlow<String?> = repository.selectedMonth
  val monthlyHistory: StateFlow<List<HistoryPoint>> = repository.monthlyHistory

  val isSyncing: StateFlow<Boolean> = repository.isSyncing
  val isOnline: StateFlow<Boolean> = repository.isOnline
  val lastSyncTime: StateFlow<String> = repository.lastSyncTime
  val syncErrorMessage: StateFlow<String?> = repository.syncErrorMessage

  // ─── إعدادات الأمان البيومتري ───


  // ─── طابور العمليات المؤجلة (Pending Offline Queue) ───
  val pendingActionsCount: StateFlow<Int> = repository.pendingActionsCount
  val pendingActionsList = repository.pendingActionsList
  fun flushPendingOfflineActions(onComplete: (Int) -> Unit = {}) {
    viewModelScope.launch {
      val count = repository.flushPendingOfflineActions()
      onComplete(count)
    }
  }

  // ─── الأدمن ───
  val pendingPayments: StateFlow<List<PendingPayment>> = repository.pendingPayments
  val pendingSubscriptions: StateFlow<List<PendingSubscription>> = repository.pendingSubscriptions
  val adminParticipants: StateFlow<List<ParticipantAdminItem>> = repository.adminParticipants
  val adminBusinesses: StateFlow<List<BusinessAdminItem>> = repository.adminBusinesses
  val adminEntitlements: StateFlow<List<BusinessEntitlement>> = repository.adminEntitlements
  val auditLogs: StateFlow<List<AuditLogItem>> = repository.auditLogs
  val apEarnings: StateFlow<List<ApEarning>> = repository.apEarnings
  val workerUrl: StateFlow<String> = repository.workerUrl

  fun signInWithGoogle(activityContext: android.content.Context) = repository.signInWithGoogle(activityContext)
  fun signOut() = repository.signOut()
  fun clearLoginError() = repository.clearLoginError()
  fun clearLastActionError() = repository.clearLastActionError()
  fun refreshNow() = repository.refreshNow()
  fun setWorkerUrl(url: String) = repository.setWorkerUrl(url)
  fun selectMonth(month: String?) = repository.selectMonth(month)

  // ✅ كل الدوال دي بقت suspend/تُطلق داخل viewModelScope وتستقبل النتيجة الفعلية
  // عبر callback، بدل ما ترجع Map وهمي فورًا. الـ UI بيمرّر onResult لعرض رسالة
  // الخطأ أو الانتقال للشاشة التالية بناءً على النتيجة الحقيقية من السيرفر.

  fun buyShare(marketRow: Int? = null, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.buyShare(marketRow)) }
  }

  fun submitPaymentVerification(otp: String, txnRef: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.submitPaymentVerification(otp, txnRef)) }
  }

  fun sellShare(onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.sellShare()) }
  }

  fun selectSubscription(tier: String?, country: String?) {
    viewModelScope.launch { repository.selectSubscription(tier, country) }
  }

  fun prepaySubscription(tier: String, country: String = "", onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.prepaySubscription(tier, country)) }
  }

  fun subscribe(tier: String, country: String = "", onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.subscribe(tier, country)) }
  }

  fun payFranchise(onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.payFranchise()) }
  }

  fun submitSubscriptionVerification(otp: String, txnRef: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.submitSubscriptionVerification(otp, txnRef)) }
  }

  // ✅ جديد: دليل الـ120 نشاط — حصري لمشترك باقة ماقما
  val magmaDirectory: StateFlow<MagmaDirectoryResponse> = repository.magmaDirectory
  fun loadMagmaDirectory() {
    viewModelScope.launch { repository.loadMagmaDirectory() }
  }
  fun markMagmaBusinessViewed(sheetId: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.markMagmaBusinessViewed(sheetId)) }
  }

  fun loadSavedTab(onResult: (String?) -> Unit) {
    viewModelScope.launch { onResult(repository.fetchSavedTab()) }
  }

  fun saveTab(screen: String, space: String) {
    viewModelScope.launch { repository.saveTab(screen, space) }
  }

  fun loadTermsFor(tier: String) {
    viewModelScope.launch { repository.loadTermsFor(tier) }
  }

  fun acceptTerms(tier: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.acceptTerms(tier)) }
  }
  fun decidePayment(row: Int, decision: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.decidePayment(row, decision)) }
  }

  fun decideSubscription(row: Int, decision: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.decideSubscription(row, decision)) }
  }

  fun linkBusiness(sheetId: String, email: String, name: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.linkBusinessToEmail(sheetId, email, name)) }
  }

  fun toggleAutoAccept(sheetId: String, enabled: Boolean, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.toggleBusinessAutoAccept(sheetId, enabled)) }
  }

  fun submitAgreement(sheetId: String, link: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.submitAgreementLink(sheetId, link)) }
  }

  fun requestCash(sheetId: String, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.requestCash(sheetId)) }
  }

  fun toggleClosed(sheetId: String, closed: Boolean, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.toggleBusinessClosed(sheetId, closed)) }
  }

  fun acceptEntitlement(row: Int, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.acceptBusinessEntitlement(row)) }
  }

  fun confirmGuarantee(row: Int, onResult: (ActionResult) -> Unit = {}) {
    viewModelScope.launch { onResult(repository.confirmGuaranteeReceived(row)) }
  }
}

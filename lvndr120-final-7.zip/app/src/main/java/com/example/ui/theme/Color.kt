package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val LavndrVoid = Color(0xFF04040A)
val LavndrSurface = Color(0xFF0C0C14)
val LavndrSurfaceElevated = Color(0xFF141420)
val LavndrGlass = Color(0x0AFFFFFF)
val LavndrGlassBorder = Color(0x14FFFFFF)
val LavndrGlassBorderBright = Color(0x2EFFFFFF)

val LavndrGold = Color(0xFFC9A84C)
val LavndrGoldLight = Color(0xFFF0D080)
val LavndrGoldDim = Color(0x26C9A84C)
val LavndrGoldGlow = Color(0x4DC9A84C)

val LavndrEmerald = Color(0xFF10B981)
val LavndrEmeraldDim = Color(0x2610B981)
val LavndrRed = Color(0xFFF43F5E)
val LavndrRedDim = Color(0x26F43F5E)

val LavndrSapphire = Color(0xFF3B82F6)
val LavndrSapphireDim = Color(0x263B82F6)
val LavndrAmethyst = Color(0xFF8B5CF6)
val LavndrAmethystDim = Color(0x268B5CF6)
val LavndrAmber = Color(0xFFF59E0B)
val LavndrAmberDim = Color(0x26F59E0B)

val LavndrText = Color(0xE6FFFFFF)
val LavndrTextDim = Color(0x80FFFFFF)
val LavndrTextFaint = Color(0x38FFFFFF)

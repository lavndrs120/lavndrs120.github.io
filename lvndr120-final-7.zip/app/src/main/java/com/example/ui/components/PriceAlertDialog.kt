package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.alerts.PriceAlertConfig
import com.example.ui.theme.*
import com.example.util.NotificationSoundManager
import com.example.util.NotificationSoundType
import java.util.Locale

@Composable
fun PriceAlertDialog(
  currentNav: Double,
  initialConfig: PriceAlertConfig,
  onSaveConfig: (PriceAlertConfig) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var isEnabled by remember { mutableStateOf(initialConfig.isEnabled) }
  var isSoundEnabled by remember { mutableStateOf(initialConfig.isSoundEnabled) }
  var targetNavText by remember { mutableStateOf(String.format(Locale.US, "%.1f", initialConfig.targetNav)) }
  var alertWhenAbove by remember { mutableStateOf(initialConfig.alertWhenAbove) }

  val targetNavVal = targetNavText.toDoubleOrNull() ?: currentNav
  val diff = targetNavVal - currentNav

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = LavndrSurfaceElevated,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "🔔 تنبيهات أسعار المؤشر والـ NAV",
            color = LavndrGold,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "إشعار فوري عند وصول المؤشر لرقمك المستهدف",
            color = LavndrTextDim,
            fontSize = 11.sp
          )
        }
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        // Toggle Switch
        Surface(
          color = LavndrSurface,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, LavndrGlassBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "تفعيل تنبيه الهدف",
                color = LavndrText,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
              )
              Text(
                text = if (isEnabled) "التنبيه يعمل بالخلفية" else "التنبيه متوقف",
                color = if (isEnabled) LavndrEmerald else LavndrTextDim,
                fontSize = 10.sp
              )
            }
            Switch(
              checked = isEnabled,
              onCheckedChange = { isEnabled = it },
              colors = SwitchDefaults.colors(
                checkedThumbColor = LavndrVoid,
                checkedTrackColor = LavndrEmerald,
                uncheckedThumbColor = LavndrTextDim,
                uncheckedTrackColor = LavndrSurface
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Target NAV Field
        Text(
          text = "السعر المستهدف ($):",
          color = LavndrText,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
          value = targetNavText,
          onValueChange = { targetNavText = it },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("target_nav_input"),
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = LavndrGold,
            unfocusedBorderColor = LavndrGlassBorder,
            focusedTextColor = LavndrText,
            unfocusedTextColor = LavndrText
          ),
          leadingIcon = { Text("$", color = LavndrGold, fontWeight = FontWeight.Bold) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Condition Selection
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = alertWhenAbove,
            onClick = { alertWhenAbove = true },
            label = { Text("▲ عند الصعود (≥)", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = LavndrEmeraldDim,
              selectedLabelColor = LavndrEmerald
            ),
            modifier = Modifier.weight(1f)
          )
          FilterChip(
            selected = !alertWhenAbove,
            onClick = { alertWhenAbove = false },
            label = { Text("▼ عند الهبوط (≤)", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = LavndrRedDim,
              selectedLabelColor = LavndrRed
            ),
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Delta indicator
        Surface(
          color = LavndrVoid,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "السعر الحالي: $${currentNav}",
              color = LavndrTextDim,
              fontSize = 11.sp
            )
            val deltaText = if (diff >= 0) "+$${String.format(Locale.US, "%.1f", diff)}" else "-$${String.format(Locale.US, "%.1f", -diff)}"
            Text(
              text = "الفارق: $deltaText",
              color = if (diff >= 0) LavndrEmerald else LavndrGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Sound Alert Option & Test
        Surface(
          color = LavndrSurface,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, LavndrGlassBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Text(
                  text = if (isSoundEnabled) "🔔" else "🔕",
                  fontSize = 16.sp
                )
                Column {
                  Text(
                    text = "التنبيه الصوتي المباشر",
                    color = LavndrText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                  Text(
                    text = if (isSoundEnabled) "نغمة استثمارية عند تحقق الهدف" else "صامت بدون صوت",
                    color = if (isSoundEnabled) LavndrEmerald else LavndrTextDim,
                    fontSize = 10.sp
                  )
                }
              }
              Switch(
                checked = isSoundEnabled,
                onCheckedChange = { isSoundEnabled = it },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = LavndrVoid,
                  checkedTrackColor = LavndrGold,
                  uncheckedThumbColor = LavndrTextDim,
                  uncheckedTrackColor = LavndrSurface
                )
              )
            }

            if (isSoundEnabled) {
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedButton(
                onClick = {
                  NotificationSoundManager.play(context, NotificationSoundType.PRICE_TARGET)
                },
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, LavndrGold.copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = LavndrGold),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("test_price_sound_button")
              ) {
                Text("🔊 تجربة نغمة التنبيه الآن", fontSize = 11.sp, fontWeight = FontWeight.Medium)
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val parsedNav = targetNavText.toDoubleOrNull() ?: currentNav
          onSaveConfig(
            PriceAlertConfig(
              isEnabled = isEnabled,
              targetNav = parsedNav,
              alertWhenAbove = alertWhenAbove,
              hasTriggered = false,
              isSoundEnabled = isSoundEnabled
            )
          )
          onDismiss()
        },
        colors = ButtonDefaults.buttonColors(containerColor = LavndrGold, contentColor = LavndrVoid),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.testTag("save_price_alert_button")
      ) {
        Text("حفظ التنبيه", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("إلغاء", color = LavndrTextDim)
      }
    }
  )
}

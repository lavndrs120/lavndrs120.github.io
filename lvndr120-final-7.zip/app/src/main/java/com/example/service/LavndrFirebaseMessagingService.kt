package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.util.NotificationSoundManager
import com.example.util.NotificationSoundType
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class LavndrFirebaseMessagingService : FirebaseMessagingService() {

  companion object {
    private const val TAG = "LavndrFCM"
    const val CHANNEL_PAYMENTS_ID = "lavndr_payments_channel"
    const val CHANNEL_MARKET_ID = "lavndr_market_channel"
  }

  override fun onNewToken(token: String) {
    super.onNewToken(token)
    Log.d(TAG, "Refreshed FCM registration token: $token")
    // حفظ التوكن محلياً أو إرساله للـ Backend Cloudflare Worker
    val prefs = getSharedPreferences("lavndr_production_prefs", Context.MODE_PRIVATE)
    prefs.edit().putString("fcm_token", token).apply()
  }

  override fun onMessageReceived(remoteMessage: RemoteMessage) {
    super.onMessageReceived(remoteMessage)
    Log.d(TAG, "From: ${remoteMessage.from}")

    val data = remoteMessage.data
    val notification = remoteMessage.notification

    val type = data["type"] ?: "market_update" // "payment_confirmation" or "market_update"
    val title = notification?.title ?: data["title"] ?: when (type) {
      "payment_confirmation" -> "تأكيد العملية المالية"
      else -> "تحديث السوق - LAVNDR120"
    }

    val body = notification?.body ?: data["body"] ?: when (type) {
      "payment_confirmation" -> "تم تأكيد طلبك وإيداع الحصص الاستثمارية بنجاح."
      else -> "تغير ملحوظ في قيمة المؤشر أو تحديث جديد للأوزان."
    }

    // تشغيل التنبيه الصوتي فوراً
    val soundType = if (type == "payment_confirmation") {
      NotificationSoundType.PAYMENT_SUCCESS
    } else {
      NotificationSoundType.MARKET_ALERT
    }
    NotificationSoundManager.play(this, soundType)

    sendNotification(title, body, type)
  }

  private fun sendNotification(title: String, body: String, type: String) {
    val intent = Intent(this, MainActivity::class.java).apply {
      addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
      putExtra("notification_type", type)
    }

    val pendingIntent = PendingIntent.getActivity(
      this,
      System.currentTimeMillis().toInt(),
      intent,
      PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
    )

    val channelId = if (type == "payment_confirmation") CHANNEL_PAYMENTS_ID else CHANNEL_MARKET_ID

    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channelName = if (type == "payment_confirmation") "تأكيدات المدفوعات والحصص" else "تحديثات السوق والمؤشر"
      val importance = NotificationManager.IMPORTANCE_HIGH
      val audioAttributes = AudioAttributes.Builder()
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
        .build()

      val channel = NotificationChannel(channelId, channelName, importance).apply {
        description = if (type == "payment_confirmation") "إشعارات اعتماد تحويلات الحصص والـ OTP" else "إشعارات حركة أسعار المؤشر LAVNDR120"
        enableLights(true)
        enableVibration(true)
        setSound(soundUri, audioAttributes)
      }
      notificationManager.createNotificationChannel(channel)
    }

    val notificationBuilder = NotificationCompat.Builder(this, channelId)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setContentTitle(title)
      .setContentText(body)
      .setStyle(NotificationCompat.BigTextStyle().bigText(body))
      .setAutoCancel(true)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setSound(soundUri)
      .setDefaults(NotificationCompat.DEFAULT_ALL)
      .setContentIntent(pendingIntent)

    val notificationId = if (type == "payment_confirmation") 1001 else 1002
    notificationManager.notify(notificationId, notificationBuilder.build())
  }
}

// ─────────────────────────────────────────────
// LAVNDR120 — Cloudflare Worker (وسيط آمن بين الفرونت اند و GAS)
// ─────────────────────────────────────────────
const ALLOWED_ORIGIN = 'https://omssolutionorders-bit.github.io';

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin'
};

const RATE_LIMITS = {
  login:               { limit: 10, windowSeconds: 300 },
  verify_payment:      { limit: 8,  windowSeconds: 600 },
  verify_subscription: { limit: 8,  windowSeconds: 600 },
  buy:                 { limit: 5,  windowSeconds: 300 },
  sell:                { limit: 5,  windowSeconds: 300 },
  subscribe:           { limit: 5,  windowSeconds: 300 },
  franchise_pay:       { limit: 5,  windowSeconds: 300 },
  DEFAULT:             { limit: 60, windowSeconds: 60 }
};

async function checkRateLimit(env, ip, action) {
  if (!env.RATE_LIMIT_KV) return true;
  const cfg = Object.prototype.hasOwnProperty.call(RATE_LIMITS, action) ? RATE_LIMITS[action] : RATE_LIMITS.DEFAULT;
  const key = 'rl:' + action + ':' + ip;
  let count = 0;
  try {
    const current = await env.RATE_LIMIT_KV.get(key);
    count = current ? parseInt(current, 10) : 0;
  } catch (e) { return true; }
  if (count >= cfg.limit) return false;
  try {
    await env.RATE_LIMIT_KV.put(key, String(count + 1), { expirationTtl: cfg.windowSeconds });
  } catch (e) {}
  return true;
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const hasOrigin = origin !== '';
    const isAllowedOrigin = !hasOrigin || origin === ALLOWED_ORIGIN;

    const corsHeaders = {
      'Access-Control-Allow-Origin': hasOrigin ? (isAllowedOrigin ? origin : 'null') : '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400',
      'Vary': 'Origin',
      ...SECURITY_HEADERS
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (!isAllowedOrigin) {
      return new Response(JSON.stringify({ error: 'Origin not allowed' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const contentLength = parseInt(request.headers.get('Content-Length') || '0', 10);
    if (request.method === 'POST' && contentLength > 10240) {
      return new Response(JSON.stringify({ error: 'الطلب كبير جداً' }), {
        status: 413,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const gasUrl = env.GAS_URL;
    const apiKey = env.GAS_API_KEY;
    if (!gasUrl || !apiKey) {
      return new Response(JSON.stringify({ error: 'Worker not configured — راجع GAS_URL/GAS_API_KEY' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const incomingUrl = new URL(request.url);

    let bodyText = '';
    let bodyObj = {};
    let action = incomingUrl.searchParams.get('action') || '';
    if (request.method === 'POST') {
      bodyText = await request.text();
      try { bodyObj = JSON.parse(bodyText || '{}'); } catch (e) {}
      action = bodyObj.action || action;
    }

    const clientIp = request.headers.get('CF-Connecting-IP') || 'unknown';
    const allowed = await checkRateLimit(env, clientIp, action || 'DEFAULT');
    if (!allowed) {
      return new Response(JSON.stringify({ error: 'محاولات كتيرة جداً — حاول بعد شوية', code: 429 }), {
        status: 429,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const target = new URL(gasUrl);
    incomingUrl.searchParams.forEach((v, k) => target.searchParams.set(k, v));
    target.searchParams.set('key', apiKey);

    let gasResponse;
    try {
      if (request.method === 'GET') {
        gasResponse = await fetch(target.toString(), { redirect: 'follow' });
      } else if (request.method === 'POST') {
        gasResponse = await fetch(target.toString(), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(bodyObj),
          redirect: 'follow'
        });
      } else {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), {
          status: 405,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }
    } catch (e) {
      return new Response(JSON.stringify({ error: 'Upstream fetch failed: ' + e.message }), {
        status: 502,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const text = await gasResponse.text();
    return new Response(text, {
      status: gasResponse.status,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
};
